cmake_minimum_required(VERSION 3.16)
project(PS5X VERSION 0.1.0 LANGUAGES CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)
if(NOT CMAKE_BUILD_TYPE AND NOT CMAKE_CONFIGURATION_TYPES)
  set(CMAKE_BUILD_TYPE Release)
endif()

option(PS5X_BUILD_TESTS "Build the test suites" ON)
option(PS5X_BUILD_GUI "Build the Win32 GUI (PS5X.exe). Windows only" OFF)
option(PS5X_ENABLE_VULKAN "Enable the Vulkan device probe (needs the Vulkan SDK) - untested" OFF)

# The CPU core uses GCC/Clang extensions (__int128, __builtin_*). Plain MSVC cl.exe is not supported.
if(MSVC AND NOT CMAKE_CXX_COMPILER_ID MATCHES "Clang")
  message(FATAL_ERROR "PS5X needs GCC or Clang (MinGW-w64, MSYS2, or clang-cl). Plain MSVC cl.exe is unsupported.")
endif()
if(PS5X_BUILD_GUI AND NOT WIN32)
  message(WARNING "PS5X_BUILD_GUI is only meaningful on Windows; the GUI target will not be created.")
endif()

# Every executable is linked statically on MinGW so the portable package needs no MinGW runtime DLLs.
function(ps5x_static_link tgt)
  if(MINGW)
    target_link_options(${tgt} PRIVATE -static)
  endif()
endfunction()

# ---- core library (everything except the program entry points) ----
file(GLOB_RECURSE PS5X_CORE_SRC CONFIGURE_DEPENDS ${CMAKE_SOURCE_DIR}/src/*.cpp)
list(FILTER PS5X_CORE_SRC EXCLUDE REGEX ".*/src/(frontend|gui)/.*")

add_library(ps5x_core STATIC ${PS5X_CORE_SRC})
target_include_directories(ps5x_core PUBLIC ${CMAKE_SOURCE_DIR}/src)
if(NOT MSVC)
  target_compile_options(ps5x_core PUBLIC -Wall -Wextra)
endif()
if(WIN32)
  # NOMINMAX / LEAN_AND_MEAN keep windows.h from breaking std::min/max and bloating includes.
  # XInput is loaded at runtime (src/input/input.cpp): nothing is linked for it.
  target_compile_definitions(ps5x_core PUBLIC NOMINMAX WIN32_LEAN_AND_MEAN)
endif()
if(PS5X_ENABLE_VULKAN)
  find_package(Vulkan REQUIRED)
  target_compile_definitions(ps5x_core PUBLIC PS5X_HAS_VULKAN)
  target_link_libraries(ps5x_core PUBLIC Vulkan::Vulkan)
endif()

# ---- command-line tools ----
add_executable(ps5x src/frontend/main.cpp)
target_link_libraries(ps5x PRIVATE ps5x_core)
ps5x_static_link(ps5x)
if(WIN32)
  # ps5x-cli.exe: cannot collide (Windows is case-insensitive) with the GUI's PS5X.exe
  set_target_properties(ps5x PROPERTIES OUTPUT_NAME ps5x-cli)
endif()

add_executable(ps5x_preflight src/frontend/preflight_main.cpp)
target_link_libraries(ps5x_preflight PRIVATE ps5x_core)
ps5x_static_link(ps5x_preflight)

# ---- tests (ctest) ----
function(ps5x_add_test tgt src)
  add_executable(${tgt} ${src})
  target_link_libraries(${tgt} PRIVATE ps5x_core)
  ps5x_static_link(${tgt})
  add_test(NAME ${tgt} COMMAND ${tgt})
endfunction()

if(PS5X_BUILD_TESTS)
  enable_testing()
  ps5x_add_test(ps5x_tests tests/test_main.cpp)
  ps5x_add_test(ps5x_preflight_tests tests/test_preflight.cpp)
  ps5x_add_test(ps5x_compat_tests tests/test_compat.cpp)
  ps5x_add_test(ps5x_cpu_ext_tests tests/test_cpu_ext.cpp)
endif()

# ---- Windows GUI: PS5X.exe ----
if(WIN32 AND PS5X_BUILD_GUI)
  add_executable(ps5x_gui WIN32 src/gui/win32_gui.cpp)
  set_target_properties(ps5x_gui PROPERTIES OUTPUT_NAME PS5X)
  target_link_libraries(ps5x_gui PRIVATE ps5x_core user32 gdi32 comdlg32 shell32 ole32)
  ps5x_static_link(ps5x_gui)
endif()
