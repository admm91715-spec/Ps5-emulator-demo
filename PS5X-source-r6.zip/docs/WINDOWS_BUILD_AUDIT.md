# Windows pipeline audit (what was found, fixed, and what is still unverified)

## Found and fixed
| # | Problem | Fix |
|---|---|---|
| 1 | CMake linked `xinput`; MinGW may bind to `xinput1_3.dll`, absent on a clean Windows 10 | XInput is now loaded at runtime (`xinput1_4`/`1_3`/`9_1_0`); nothing linked; hot-plug via polling |
| 2 | `ps5x_preflight` and its test were not linked `-static` (would need MinGW DLLs) | one `ps5x_static_link()` helper applied to every executable |
| 3 | No `NOMINMAX`/`WIN32_LEAN_AND_MEAN` (windows.h macro clashes) | defined for the core on Windows; guarded in the GUI |
| 4 | No `.gitattributes`: Windows checkout can convert `sh` scripts to CRLF and break packaging | `.gitattributes` (LF for scripts/yml, CRLF for .bat) |
| 5 | GUI `continue-on-error` could hide a failed GUI build | explicit Report step + hard Gate: job goes red; package named `...CLI-ONLY.zip`; manual `allow_cli_only` override |
| 6 | Package script accepted any file (a Linux ELF could be zipped as "exe") | `check_windows_pe.sh` requires MZ + PE signature + machine 0x8664 for every binary; Linux binaries refused (exit 3) |
| 7 | Required DLLs: none handled; DLLs would be ignored in a subfolder | fallback copies imported non-system DLLs from `$MINGW_PREFIX/bin` next to the exes + `dll_report.txt` (flags unknown imports) |
| 8 | No test of the *packaged* binaries | `smoke_test.sh` runs against the extracted package in CI; `Smoke_Test.bat` ships for the user's PC |
| 9 | `.bat` files had LF endings; README not CRLF | converted at packaging time |
| 10 | printf format attribute wrong for MinGW (`%zu`, `%llu`) | `gnu_printf` on MinGW |
| 11 | GUI: int-to-HMENU casts, missing `<cstdio>`, cursor not restored, misleading indentation; XInput mapping style | fixed; mapping rewritten table-driven |
| 12 | CLI/GUI names would collide case-insensitively | CLI is `ps5x-cli.exe`, GUI `PS5X.exe` |

## Verified on Linux in this environment
* All 4 test suites pass (33 + 6 + compat/regress + 52 CPU scenarios); `smoke_test.sh` passes against the Linux build.
* Package script: refuses Linux binaries; accepts only crafted valid-PE fixtures; CLI-only variant has no `PS5X.exe` and says so; layout-only mode is labelled NOT-WINDOWS.
* Workflow YAML parses; all `steps.<id>` references resolve; CMake file passes a structural lint (no CMake available to run it).
* GUI and the Windows XInput branch **type-check against hand-written stub Windows headers**. That catches C++ mistakes in our code only; it does not prove the real Win32/MinGW headers agree.

## NOT verified (needs the Windows runner)
Real MinGW compilation of everything, the Windows run of the tests, the GUI compile/link/launch, static-link result (`dll_report.txt`),
and every Windows-specific behaviour (paths, XInput, file dialogs). Until a green run exists, no Windows build is claimed.
