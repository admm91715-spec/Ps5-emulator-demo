# Commercial-title gap analysis (r5)

Scope note: facts about PS5 hardware/software below are general public knowledge and the documentation of existing PS5 emulator
projects. They were **not verified against a real console or title here**. Nothing in this document claims any commercial game
(GTA VI, Astro Bot, ...) runs or will run; their real requirements are unknown until tested on a working emulator with legally
owned copies.

## 1. Actual state of PS5X (measured, not aspirational)
| Subsystem | Lines | State |
|---|---|---|
| CPU interpreter | ~600 | Integer x86-64 base: ALU, mul/div, shifts/rotates, bit ops (bt*, bsf/bsr, tzcnt/lzcnt/popcnt), string ops with rep/repe/repne, cmpxchg/xadd, push/pop/call/ret, setcc/cmov. **No SSE/AVX/x87, no FS/GS TLS, no cpuid/rdtsc, no 32-bit address override, no real multithreading.** Unsupported opcodes stop loudly. |
| Memory | ~130 | Region map with R/W/X permissions and exact fault reporting. Single-region accesses only, 4 KiB pages, no host-address mapping. |
| Loader | ~90 | Plain ELF64 only, no relocations, no dynamic linking, no module (PRX/SPRX) system. Encrypted retail containers are recognised and refused (deliberately, no decryption). |
| Kernel | ~100 | 5 FreeBSD-ABI syscalls + a PS5X-private test ABI. No threads, files, sync primitives, or any Sony library. |
| GPU | ~90 | Software framebuffer with 3 commands. No command processor, shader support, or Vulkan renderer (device probe only, untested). |
| Audio / Input | ~200 | Ring buffer + WAV writer; keyboard map + XInput polling (untested on Windows). No live device output. |
| Compat DB / regression / GUI / CI | ~700 | Real and tested on Linux; GUI + Windows CI unverified until a Windows run exists. |

## 2. The main architectural conclusion
Real console emulators for x86-64 consoles do **not** interpret the guest CPU. The PS5 CPU is x86-64, so they run guest code
**natively on the host**, at fixed guest addresses, and reimplement the system libraries the game imports (HLE), bridging calling
conventions (guest uses System V ABI; Windows x64 differs) with thunks. An interpreter is orders of magnitude too slow for
modern titles. Consequence for PS5X: the interpreter should stay only as a *reference oracle* (differential testing, debugging,
instruction-level diagnostics), and further ISA work on it has sharply diminishing value for commercial titles.

## 3. Obstacles ranked by how much they block commercial titles
1. **System-library HLE** (largest): kernel/libc/threads/mutexes/semaphores, memory (direct/flexible), file system, video-out,
   audio-out, pad, save data, user/system services, timing; hundreds of imported functions, many undocumented. Needs a module/linking system.
2. **GPU stack**: PS5 command-buffer processing, resource and state tracking, GPU/CPU synchronisation, and an RDNA-class shader
   recompiler (to SPIR-V) feeding a Vulkan backend; plus shader caching and frame pacing. Second-largest, and performance-critical.
3. **Native execution runtime**: fixed-address reservations on Windows, TLS, exception/fault handling, ABI thunks, patching of
   syscall/unsupported-instruction sites, executable-memory management, host CPU feature checks (AVX2/FMA/BMI2).
4. **Executable access**: retail content is encrypted/signed. PS5X will not decrypt it or bundle keys; any real use needs content
   you are legally entitled to in an unprotected form, which is outside this project.
5. **Threading, synchronisation, timing**: correct pthread-like semantics, scheduling, TSC/clock behaviour, determinism problems.
6. **Memory model**: 16 KiB pages, unified CPU/GPU memory and aliasing, large allocations.
7. **Audio, input, storage**: comparatively tractable (live audio device, DualSense/XInput, virtual FS, save data).
8. **Per-title QA**: compatibility is earned title by title; the evidence-gated database already exists for recording it.

## 4. Practical route
Obstacles 1-3 are exactly what KytyPS5 and SharpEmu are working on (see FOUNDATION_EVALUATION.md). Duplicating them in PS5X would
cost years and end behind them. The highest-leverage use of effort is contributing there, with PS5X's compat database,
regression harness and preflight tooling as supporting infrastructure.

## 5. Next PS5X milestone (not started)
"Native runtime v0": map the existing ELF loader's segments at their fixed addresses in the host process, patch `syscall`
sites to HLE thunks, run guest code natively on an x86-64 host, and use the interpreter as the oracle for differential tests.
It proves the execution model (obstacle 3) on controlled programs; it does not by itself run any commercial title.
