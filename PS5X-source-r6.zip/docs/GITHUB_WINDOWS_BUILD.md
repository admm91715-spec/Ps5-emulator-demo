# Getting a real Windows build: GitHub steps

Status: **no Windows build of this project has been verified yet.** The workflow `.github/workflows/windows.yml` was written
and statically checked, but it has never run on a Windows runner. The first run is the first real verification; expect that
it may need fixes. Do not treat any package as working until the run summary says so (see "Reading the result").

## 1. Prepare
1. Make a free account at github.com. Install Git for Windows (git-scm.com) or use the GitHub Desktop app.
2. Create an **empty** repository (no README/licence/.gitignore - the project already has them). Private is fine; Actions minutes are free for public repos and included in a quota for private ones.
3. Do not add game files, firmware, keys or dumps to the repository. Ever.

## 2. Upload the project (command line)
Unzip `PS5X-source-r6.zip` so that the **folder containing `CMakeLists.txt` and `.github/`** is the repository root, then in that folder:
```
git init -b main
git add .
git status          # confirm .github/workflows/windows.yml is listed; no .zip/.exe files
git commit -m "PS5X: initial import"
git remote add origin https://github.com/<your-user>/<your-repo>.git
git push -u origin main
```
(`.gitattributes` forces LF endings for scripts and CRLF for .bat files; it prevents Windows checkout from breaking `scripts/*.sh`.)
GitHub Desktop alternative: File > Add local repository > publish repository. The hidden `.github` folder must be included.

## 3. Trigger the workflow
* Pushing to `main` (or `master`) starts it automatically. Or: **Actions** tab > "windows-build" > **Run workflow**.
* If Actions are disabled on a fork/new repo, click "I understand my workflows, go ahead and enable them" in the Actions tab.
* Manual runs offer `allow_cli_only` (default off). Leave it off to make a missing GUI a hard failure.

## 4. Reading the result
Open the run, then the **Summary** page (it has a table written by the "Report" step):
| Row | Good | Meaning if not |
|---|---|---|
| Core build, ctest (3 suites), smoke test of packaged CLI | success | the code or toolchain failed on Windows; read the failing step's log |
| GUI PS5X.exe | **BUILT** | `UNAVAILABLE`: the GUI failed to compile/link; the job is forced RED and the artifact is named `PS5X-Windows-CLI-ONLY.zip` |
| GUI launch smoke test | started and stayed alive 6 s | warning only (hosted runners may not allow windows); test it on your PC |
A package is a full build only if the job is **green** and the artifact is named `PS5X-Ultimate-Windows.zip`.

## 5. Download and test on your own PC
Run page > **Artifacts** > download (it is a ZIP containing the release ZIP) > extract the inner `PS5X-Ultimate-Windows.zip` to a normal folder (not Program Files) >
double-click `Smoke_Test.bat` (prints PASS/FAIL) > double-click `Launch.bat` (GUI). `Dependencies\dll_report.txt` lists every DLL the programs import.
Windows SmartScreen may warn because the exe is not code-signed; only proceed for a build from your own run.

## 6. If it fails
Open the failing step, copy the compiler/linker error text and fix or report it. Typical first-run issues: a Win32 declaration mismatch in
`src/gui/win32_gui.cpp`, a missing include under MinGW, or a test that behaves differently on Windows paths.
