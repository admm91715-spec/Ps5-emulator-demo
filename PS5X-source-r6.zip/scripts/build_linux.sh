#!/bin/sh
# Dependency-free build (needs only g++ >= 9 or clang++). Used to verify this project in CI-less environments.
set -e
cd "$(dirname "$0")/.."
mkdir -p build
CORE=$(find src -name '*.cpp' ! -path 'src/frontend/*' ! -path 'src/gui/*')
CXX=${CXX:-g++}
$CXX -std=c++17 -O2 -Wall -Wextra -Isrc $CORE src/frontend/main.cpp -o build/ps5x
$CXX -std=c++17 -O1 -g -Wall -Wextra -Isrc $CORE tests/test_main.cpp -o build/ps5x_tests
echo "built build/ps5x and build/ps5x_tests"
$CXX -std=c++17 -O2 -Wall -Wextra -Isrc $CORE src/frontend/preflight_main.cpp -o build/ps5x_preflight
$CXX -std=c++17 -O1 -g -Wall -Wextra -Isrc $CORE tests/test_preflight.cpp -o build/ps5x_preflight_tests
echo "built build/ps5x_preflight and build/ps5x_preflight_tests"
$CXX -std=c++17 -O1 -g -Wall -Wextra -Isrc $CORE tests/test_compat.cpp -o build/ps5x_compat_tests
echo "built build/ps5x_compat_tests"
$CXX -std=c++17 -O1 -g -Wall -Wextra -Isrc $CORE tests/test_cpu_ext.cpp -o build/ps5x_cpu_ext_tests
echo "built build/ps5x_cpu_ext_tests"
