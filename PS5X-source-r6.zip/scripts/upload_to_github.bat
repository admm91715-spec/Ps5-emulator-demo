@echo off
rem One-click helper: uploads this project folder to YOUR EMPTY GitHub repository so GitHub builds PS5X.exe for you.
rem Needs Git for Windows (https://git-scm.com/download/win). Not tested by the author.
setlocal
where git >nul 2>nul || (echo Install Git for Windows first: https://git-scm.com/download/win & pause & exit /b 1)
cd /d "%~dp0\.."
echo Create an EMPTY repository on github.com first (no README), then paste its URL below.
set /p URL=Repository URL (https://github.com/USER/REPO.git): 
if "%URL%"=="" (echo No URL given & pause & exit /b 1)
git init -b main
git add .
git -c user.name=ps5x -c user.email=ps5x@users.noreply.github.com commit -m "PS5X"
git remote remove origin >nul 2>nul
git remote add origin %URL%
git push -u origin main
echo.
echo Done. Open your repository on GitHub, click the Actions tab, then windows-build.
echo When it finishes (green), download the artifact at the bottom of the run page.
pause
