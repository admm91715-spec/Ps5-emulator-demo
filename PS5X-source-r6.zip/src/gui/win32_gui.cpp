// PS5X native Windows GUI (Win32 API, ANSI). NOT compiled or run by the author: no Windows toolchain was available.
// It is built by CI (.github/workflows/windows.yml) as a separate, optional target. Everything it shows comes from the
// real backend: GameLibrary + CompatDb + Emulator (loader/CPU/kernel/software GPU).
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <commdlg.h>
#include <shellapi.h>
#include <shlobj.h>
#include <cstdio>
#include <cstdlib>
#include <string>
#include <vector>
#include "common/config.h"
#include "common/log.h"
#include "compat/compat_db.h"
#include "core/app_paths.h"
#include "core/emulator.h"
#include "storage/library.h"
#include <filesystem>
using namespace ps5x;
namespace fs = std::filesystem;

enum { ID_LIST = 100, ID_ADDFILE, ID_ADDDIR, ID_SCAN, ID_REMOVE, ID_RUN, ID_LOGS, ID_CONFIG, ID_INFO };
static AppPaths g_paths; static Config g_cfg; static GameLibrary g_lib; static CompatDb g_compat;
static HWND g_list, g_info, g_main; static std::vector<uint32_t> g_fb; static int g_fbW = 0, g_fbH = 0; static RECT g_canvas = {0, 0, 0, 0};

static std::string CRLF(const std::string& s) { std::string o; for (char c : s) { if (c == '\n') o += "\r\n"; else o += c; } return o; }
static void SetInfo(const std::string& s) { SetWindowTextA(g_info, CRLF(s).c_str()); }
static std::string BrowseFolder(HWND h) {
    BROWSEINFOA bi = {}; bi.hwndOwner = h; bi.lpszTitle = "Select a folder"; bi.ulFlags = BIF_RETURNONLYFSDIRS | BIF_NEWDIALOGSTYLE;
    LPITEMIDLIST pidl = SHBrowseForFolderA(&bi); if (!pidl) return ""; char buf[MAX_PATH] = ""; std::string r;
    if (SHGetPathFromIDListA(pidl, buf)) { r = buf; }
    CoTaskMemFree(pidl);
    return r;
}
static std::string BrowseFile(HWND h) {
    char buf[MAX_PATH] = ""; OPENFILENAMEA o = {}; o.lStructSize = sizeof o; o.hwndOwner = h; o.lpstrFilter = "All files\0*.*\0"; o.lpstrFile = buf; o.nMaxFile = MAX_PATH;
    o.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST; return GetOpenFileNameA(&o) ? std::string(buf) : std::string();
}
static void SaveLib() { std::string e; if (!g_lib.Save(g_paths.Library(), &e)) SetInfo("Could not save library: " + e); }
static void Refresh() {
    SendMessageA(g_list, LB_RESETCONTENT, 0, 0);
    for (auto& e : g_lib.Entries()) {
        std::string row = e.title + "   [" + CompatName(e.compat) + " | tested: " + CompatLevelName(g_compat.LevelFor(e.titleId)) + "]";
        SendMessageA(g_list, LB_ADDSTRING, 0, (LPARAM)row.c_str());
    }
}
static const GameEntry* Selected() {
    int i = (int)SendMessageA(g_list, LB_GETCURSEL, 0, 0); if (i < 0 || i >= (int)g_lib.Entries().size()) return nullptr; return &g_lib.Entries()[i];
}
static void ShowDetails() {
    const GameEntry* e = Selected(); if (!e) return;
    std::string s = e->title + "\n" + e->path + "\nformat: " + FormatName(e->format) + "\nloader status: " + CompatName(e->compat) + "\n" + e->note + "\n";
    if (auto* c = g_compat.Find(e->titleId)) s += "\nTested: " + std::string(CompatLevelName(c->level)) + " on emulator " + c->emulatorVersion + " (" + c->date + ")\nIssues: " + c->issues + "\n";
    else s += "\nCompatibility: Not Tested (no evidence recorded)\n";
    SetInfo(s);
}
static void RunSelected() {
    const GameEntry* e = Selected(); if (!e) { SetInfo("Select a library entry first."); return; }
    if (e->compat != CompatStatus::LoadsOnly) { SetInfo("Cannot run: " + e->note + "\n\nPS5X only executes plain x86-64 ELF programs; commercial PS5 titles are unsupported by this build. Use KytyPS5 or SharpEmu for real titles (see Documentation)."); return; }
    SetCursor(LoadCursor(nullptr, IDC_WAIT));
    Emulator emu(g_cfg); std::string err;
    if (!emu.LoadFile(e->path, err)) { SetCursor(LoadCursor(nullptr, IDC_ARROW)); SetInfo("Load failed: " + err); return; }
    RunReport r = emu.Run(100000000ull);   // GUI thread: capped so the window cannot hang for long
    std::string s = "Run of " + e->title + "\n";
    if (!r.stdoutText.empty()) s += "--- guest stdout ---\n" + r.stdoutText + "--------------------\n";
    s += std::string("stop reason: ") + (r.exited ? "guest exit code " + std::to_string(r.exitCode) : std::string(StopReasonName(r.reason))) + "\n";
    if (!r.error.empty()) s += "detail: " + r.error + "\n";
    char b[160]; snprintf(b, sizeof b, "instructions: %llu in %.4f s (%.2f MIPS, measured)\nframes presented: %llu\nFPS display: not available (no real-time loop yet)\n", (unsigned long long)r.instructions, r.seconds, r.mips, (unsigned long long)r.frames);
    s += b; SetInfo(s);
    SetCursor(LoadCursor(nullptr, IDC_ARROW));
    g_fb = emu.gpu->Framebuffer(); g_fbW = (int)emu.gpu->Width(); g_fbH = (int)emu.gpu->Height(); InvalidateRect(g_main, &g_canvas, TRUE);
}
static void Layout(int w, int h) {
    int lw = w * 4 / 10, top = 40, bh = 28;
    const int ids[] = {ID_ADDFILE, ID_ADDDIR, ID_SCAN, ID_REMOVE, ID_RUN, ID_LOGS, ID_CONFIG};
    int x = 6; for (int id : ids) { MoveWindow(GetDlgItem(g_main, id), x, 6, 96, bh, TRUE); x += 100; }
    MoveWindow(g_list, 6, top, lw - 12, h / 2 - top, TRUE);
    MoveWindow(g_info, 6, h / 2 + 6, lw - 12, h - h / 2 - 12, TRUE);
    g_canvas = {lw + 6, top, w - 6, h - 6};
}
static LRESULT CALLBACK WndProc(HWND h, UINT m, WPARAM wp, LPARAM lp) {
    switch (m) {
    case WM_CREATE: {
        g_main = h; HFONT f = (HFONT)GetStockObject(DEFAULT_GUI_FONT);
        struct B { int id; const char* t; } bs[] = {{ID_ADDFILE, "Add game file..."}, {ID_ADDDIR, "Add game folder..."}, {ID_SCAN, "Scan games folder..."}, {ID_REMOVE, "Remove"}, {ID_RUN, "Run"}, {ID_LOGS, "Show log"}, {ID_CONFIG, "Edit config"}};
        for (auto& b : bs) { HWND c = CreateWindowExA(0, "BUTTON", b.t, WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON, 0, 0, 10, 10, h, (HMENU)(INT_PTR)b.id, nullptr, nullptr); SendMessageA(c, WM_SETFONT, (WPARAM)f, TRUE); }
        g_list = CreateWindowExA(WS_EX_CLIENTEDGE, "LISTBOX", "", WS_CHILD | WS_VISIBLE | WS_VSCROLL | LBS_NOTIFY | LBS_NOINTEGRALHEIGHT, 0, 0, 10, 10, h, (HMENU)(INT_PTR)ID_LIST, nullptr, nullptr);
        g_info = CreateWindowExA(WS_EX_CLIENTEDGE, "EDIT", "", WS_CHILD | WS_VISIBLE | WS_VSCROLL | ES_MULTILINE | ES_READONLY | ES_AUTOVSCROLL, 0, 0, 10, 10, h, (HMENU)(INT_PTR)ID_INFO, nullptr, nullptr);
        SendMessageA(g_list, WM_SETFONT, (WPARAM)f, TRUE); SendMessageA(g_info, WM_SETFONT, (WPARAM)f, TRUE);
        Refresh(); SetInfo("PS5X " + std::string(kVersion) + "\nExperimental foundation: it executes plain x86-64 ELF programs only.\nCommercial PS5 titles are NOT supported; the library lists them as Unsupported.\nSelect a game and press Run (or double-click it).\nFullscreen, controller UI and live audio: not implemented.");
        return 0; }
    case WM_SIZE: Layout(LOWORD(lp), HIWORD(lp)); return 0;
    case WM_COMMAND:
        switch (LOWORD(wp)) {
        case ID_LIST:
            if (HIWORD(wp) == LBN_SELCHANGE) { ShowDetails(); }
            else if (HIWORD(wp) == LBN_DBLCLK) { RunSelected(); }   // double-click a game to launch it, like other emulator frontends
            break;
        case ID_ADDFILE: { std::string p = BrowseFile(h); if (!p.empty()) { g_lib.Add(p); SaveLib(); Refresh(); } break; }
        case ID_ADDDIR: { std::string p = BrowseFolder(h); if (!p.empty()) { g_lib.Add(p); SaveLib(); Refresh(); } break; }
        case ID_SCAN: { std::string p = BrowseFolder(h); if (!p.empty()) { int n = g_lib.Scan(p); SaveLib(); Refresh(); SetInfo("Scan added " + std::to_string(n) + " entr" + (n == 1 ? "y" : "ies")); } break; }
        case ID_REMOVE: if (auto* e = Selected()) { std::string p = e->path; g_lib.Remove(p); SaveLib(); Refresh(); } break;
        case ID_RUN: RunSelected(); break;
        case ID_LOGS: { std::string s; for (auto& l : Logger::Get().Recent()) s += l + "\n"; SetInfo(s.empty() ? "(log empty this session; file: " + g_paths.LogFile() + ")" : s); break; }
        case ID_CONFIG: { std::error_code ec; if (!fs::exists(g_paths.Config())) g_cfg.Save(g_paths.Config()); ShellExecuteA(h, "open", "notepad.exe", g_paths.Config().c_str(), nullptr, SW_SHOW); break; }
        }
        return 0;
    case WM_PAINT: {
        PAINTSTRUCT ps; HDC dc = BeginPaint(h, &ps); int cw = g_canvas.right - g_canvas.left, ch = g_canvas.bottom - g_canvas.top;
        FillRect(dc, &g_canvas, (HBRUSH)GetStockObject(BLACK_BRUSH));
        if (!g_fb.empty() && cw > 0 && ch > 0) {
            BITMAPINFO bi = {}; bi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER); bi.bmiHeader.biWidth = g_fbW; bi.bmiHeader.biHeight = -g_fbH; bi.bmiHeader.biPlanes = 1; bi.bmiHeader.biBitCount = 32; bi.bmiHeader.biCompression = BI_RGB;
            int dw = cw, dh = cw * g_fbH / g_fbW; if (dh > ch) { dh = ch; dw = ch * g_fbW / g_fbH; }
            SetStretchBltMode(dc, COLORONCOLOR); StretchDIBits(dc, g_canvas.left, g_canvas.top, dw, dh, 0, 0, g_fbW, g_fbH, g_fb.data(), &bi, DIB_RGB_COLORS, SRCCOPY);
        }
        EndPaint(h, &ps); return 0; }
    case WM_DESTROY: PostQuitMessage(0); return 0;
    }
    return DefWindowProcA(h, m, wp, lp);
}
int WINAPI WinMain(HINSTANCE inst, HINSTANCE, LPSTR, int show) {
    int i = 1; std::string err; if (!ParseAppPaths(__argc, __argv, i, g_paths, err)) { MessageBoxA(nullptr, err.c_str(), "PS5X", MB_ICONERROR); return 2; }
    std::error_code ec; fs::create_directories(g_paths.data, ec); fs::create_directories(g_paths.logs.empty() ? g_paths.data : g_paths.logs, ec);
    g_cfg = Config::Defaults(); if (fs::exists(g_paths.Config())) g_cfg.Load(g_paths.Config(), &err);
    Logger::Get().SetConsole(false); Logger::Get().OpenFile(g_paths.LogFile());
    if (fs::exists(g_paths.Library())) g_lib.Load(g_paths.Library());
    std::vector<std::string> cerr; if (fs::exists(g_paths.Compat())) g_compat.Load(g_paths.Compat(), &cerr);
    CoInitialize(nullptr);
    WNDCLASSA wc = {}; wc.lpfnWndProc = WndProc; wc.hInstance = inst; wc.hCursor = LoadCursor(nullptr, IDC_ARROW); wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1); wc.lpszClassName = "PS5XMain";
    RegisterClassA(&wc);
    HWND w = CreateWindowExA(0, "PS5XMain", "PS5X - experimental foundation", WS_OVERLAPPEDWINDOW | WS_VISIBLE, CW_USEDEFAULT, CW_USEDEFAULT, 1100, 640, nullptr, nullptr, inst, nullptr);
    if (!w) return 1;
    ShowWindow(w, show);
    if (!cerr.empty()) { std::string m = "Compatibility database problems (rejected entries not loaded):\n"; for (auto& c : cerr) m += c + "\n"; MessageBoxA(w, m.c_str(), "PS5X", MB_ICONWARNING); }
    MSG msg; while (GetMessageA(&msg, nullptr, 0, 0) > 0) { TranslateMessage(&msg); DispatchMessageA(&msg); }
    CoUninitialize(); return (int)msg.wParam;
}
