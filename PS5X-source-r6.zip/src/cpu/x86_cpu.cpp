#include "cpu/x86_cpu.h"
#include "common/log.h"
#include <cstdio>
#include <cstring>
namespace ps5x {
const char* StopReasonName(StopReason r) {
    switch (r) {
        case StopReason::Running: return "running"; case StopReason::Syscall: return "syscall";
        case StopReason::Halt: return "halt"; case StopReason::Breakpoint: return "breakpoint";
        case StopReason::MemoryFault: return "memory-fault"; case StopReason::UndefinedOpcode: return "undefined-opcode"; case StopReason::DivideError: return "divide-error";
        case StopReason::StepLimit: return "step-limit";
    }
    return "?";
}
static inline uint64_t MaskOf(int size) { return size == 8 ? ~0ull : ((1ull << (size * 8)) - 1); }
static inline uint64_t SignBit(int size) { return 1ull << (size * 8 - 1); }
static inline int64_t SExt(uint64_t v, int size) {
    if (size == 8) return (int64_t)v;
    uint64_t m = SignBit(size); v &= MaskOf(size);
    return (int64_t)((v ^ m) - m);
}

uint8_t X86Cpu::Fetch8() {
    uint8_t v = 0;
    if (!mem_.Read(ip_, &v, 1, PERM_X)) { fault_ = true; faultAddr = ip_; }
    ip_ += 1; return v;
}
uint16_t X86Cpu::Fetch16() { uint16_t v = Fetch8(); v |= (uint16_t)Fetch8() << 8; return v; }
uint32_t X86Cpu::Fetch32() { uint32_t v = Fetch16(); v |= (uint32_t)Fetch16() << 16; return v; }
uint64_t X86Cpu::Fetch64() { uint64_t v = Fetch32(); v |= (uint64_t)Fetch32() << 32; return v; }

uint64_t X86Cpu::MemRead(uint64_t addr, int size) {
    uint64_t v = 0;
    if (!mem_.Read(addr, &v, size)) { fault_ = true; faultAddr = addr; return 0; }
    return v;  // host is little-endian x86/ARM64-LE
}
void X86Cpu::MemWrite(uint64_t addr, int size, uint64_t v) {
    if (!mem_.Write(addr, &v, size)) { fault_ = true; faultAddr = addr; }
}
bool X86Cpu::Push(uint64_t v) {
    st.gpr[RSP] -= 8;
    if (!mem_.Write(st.gpr[RSP], &v, 8)) { st.gpr[RSP] += 8; fault_ = true; faultAddr = st.gpr[RSP]; return false; }
    return true;
}
bool X86Cpu::Pop(uint64_t& v) {
    if (!mem_.Read(st.gpr[RSP], &v, 8)) { fault_ = true; faultAddr = st.gpr[RSP]; return false; }
    st.gpr[RSP] += 8; return true;
}

uint64_t X86Cpu::GetReg(int idx, int size) const {
    switch (size) {
        case 1: if (!rex_ && idx >= 4 && idx < 8) return (st.gpr[idx - 4] >> 8) & 0xff; return st.gpr[idx] & 0xff;
        case 2: return st.gpr[idx] & 0xffff;
        case 4: return st.gpr[idx] & 0xffffffffull;
        default: return st.gpr[idx];
    }
}
void X86Cpu::SetReg(int idx, int size, uint64_t v) {
    switch (size) {
        case 1:
            if (!rex_ && idx >= 4 && idx < 8) st.gpr[idx - 4] = (st.gpr[idx - 4] & ~0xff00ull) | ((v & 0xff) << 8);
            else st.gpr[idx] = (st.gpr[idx] & ~0xffull) | (v & 0xff);
            break;
        case 2: st.gpr[idx] = (st.gpr[idx] & ~0xffffull) | (v & 0xffff); break;
        case 4: st.gpr[idx] = v & 0xffffffffull; break;   // 32-bit writes zero-extend
        default: st.gpr[idx] = v;
    }
}

int X86Cpu::PeekModRMReg() {
    uint8_t b = 0; mem_.Read(ip_, &b, 1, PERM_X); return (b >> 3) & 7;
}
X86Cpu::ModRM X86Cpu::DecodeModRM(int immBytes) {
    ModRM m; uint8_t b = Fetch8();
    m.mod = b >> 6; m.reg = ((b >> 3) & 7) | (R_ ? 8 : 0); int rm = b & 7;
    if (m.mod == 3) { m.isReg = true; m.rm = rm | (B_ ? 8 : 0); return m; }
    uint64_t addr = 0; bool ripRel = false;
    if (rm == 4) {
        uint8_t sib = Fetch8(); int scale = sib >> 6; int idx = ((sib >> 3) & 7) | (X_ ? 8 : 0); int base = sib & 7;
        if (base == 5 && m.mod == 0) addr = (uint64_t)(int64_t)(int32_t)Fetch32();
        else addr = st.gpr[base | (B_ ? 8 : 0)];
        if (idx != 4) addr += st.gpr[idx] << scale;
    } else if (rm == 5 && m.mod == 0) {
        addr = (uint64_t)(int64_t)(int32_t)Fetch32(); ripRel = true;
    } else addr = st.gpr[rm | (B_ ? 8 : 0)];
    if (m.mod == 1) addr += (uint64_t)(int64_t)(int8_t)Fetch8();
    else if (m.mod == 2) addr += (uint64_t)(int64_t)(int32_t)Fetch32();
    if (ripRel) addr += ip_ + immBytes;   // relative to end of whole instruction
    m.addr = addr; return m;
}
uint64_t X86Cpu::ReadOp(const ModRM& m, int size) { return m.isReg ? GetReg(m.rm, size) : MemRead(m.addr, size); }
void X86Cpu::WriteOp(const ModRM& m, int size, uint64_t v) { if (m.isReg) SetReg(m.rm, size, v); else MemWrite(m.addr, size, v); }

void X86Cpu::SetSZP(uint64_t r, int size) {
    r &= MaskOf(size);
    uint64_t f = st.rflags & ~(FLAG_ZF | FLAG_SF | FLAG_PF);
    if (r == 0) f |= FLAG_ZF;
    if (r & SignBit(size)) f |= FLAG_SF;
    if (!(__builtin_popcount((unsigned)(r & 0xff)) & 1)) f |= FLAG_PF;
    st.rflags = f;
}
// op: 0 add,1 or,2 adc,3 sbb,4 and,5 sub,6 xor,7 cmp. Returns result (caller stores unless cmp).
uint64_t X86Cpu::Alu(int op, uint64_t a, uint64_t b, int size) {
    uint64_t mask = MaskOf(size), sb = SignBit(size); a &= mask; b &= mask;
    unsigned cin = ((op == 2 || op == 3) && (st.rflags & FLAG_CF)) ? 1 : 0;
    uint64_t r = 0; bool cf = false, of = false;
    switch (op) {
        case 0: case 2: {
            unsigned __int128 s = (unsigned __int128)a + b + cin; r = (uint64_t)s & mask;
            cf = (s >> (size * 8)) & 1; of = (~(a ^ b) & (a ^ r) & sb) != 0; break; }
        case 3: case 5: case 7: {
            r = (a - b - cin) & mask; cf = (unsigned __int128)a < (unsigned __int128)b + cin;
            of = ((a ^ b) & (a ^ r) & sb) != 0; break; }
        case 1: r = a | b; break;
        case 4: r = a & b; break;
        case 6: r = a ^ b; break;
    }
    st.rflags &= ~(FLAG_CF | FLAG_OF);
    if (cf) st.rflags |= FLAG_CF;
    if (of) st.rflags |= FLAG_OF;
    SetSZP(r, size);
    return r;
}
// op: 4 shl, 5 shr, 7 sar. Counts >= operand width are only partially modelled (documented limitation).
uint64_t X86Cpu::Shift(int op, uint64_t a, unsigned count, int size) {
    count &= (size == 8) ? 63 : 31;
    if (count == 0) return a;
    unsigned bits = size * 8; uint64_t mask = MaskOf(size); a &= mask; uint64_t r = 0; bool cf = false, of = false;
    if (count > bits) count = bits;   // over-shift: clamp
    switch (op) {
        case 4: r = count >= 64 ? 0 : (a << count) & mask; cf = (a >> (bits - count)) & 1; of = ((r & SignBit(size)) != 0) != cf; break;
        case 5: r = count >= 64 ? 0 : a >> count; cf = (a >> (count - 1)) & 1; of = (a & SignBit(size)) != 0; break;
        case 7: { int64_t s = SExt(a, size); r = (uint64_t)(s >> (count >= 64 ? 63 : count)) & mask; cf = ((uint64_t)s >> (count - 1)) & 1; break; }
        default: return a;
    }
    st.rflags &= ~(FLAG_CF | FLAG_OF);
    if (cf) st.rflags |= FLAG_CF;
    if (of && count == 1) st.rflags |= FLAG_OF;
    SetSZP(r, size);
    return r;
}
bool X86Cpu::Cond(int cc) const {
    bool cf = st.rflags & FLAG_CF, zf = st.rflags & FLAG_ZF, sf = st.rflags & FLAG_SF, of = st.rflags & FLAG_OF, pf = st.rflags & FLAG_PF;
    bool r = false;
    switch (cc >> 1) {
        case 0: r = of; break; case 1: r = cf; break; case 2: r = zf; break; case 3: r = cf || zf; break;
        case 4: r = sf; break; case 5: r = pf; break; case 6: r = sf != of; break; case 7: r = zf || (sf != of); break;
    }
    return (cc & 1) ? !r : r;
}
StopReason X86Cpu::Undef(const char* what) {
    char b[160]; snprintf(b, sizeof b, "unsupported instruction (%s) at rip=0x%llx", what, (unsigned long long)st.rip);
    lastError = b; return StopReason::UndefinedOpcode;
}

uint64_t X86Cpu::Rotate(int op, uint64_t a, unsigned count, int size) {   // op 0 rol, 1 ror
    count &= (size == 8) ? 63 : 31; if (count == 0) return a;
    const unsigned bits = size * 8; const uint64_t mask = MaskOf(size); a &= mask; const unsigned c = count % bits;
    uint64_t r = a;
    if (c) r = (op == 0) ? (((a << c) | (a >> (bits - c))) & mask) : (((a >> c) | (a << (bits - c))) & mask);
    const bool cf = op == 0 ? (r & 1) : ((r >> (bits - 1)) & 1);
    const bool msb = (r >> (bits - 1)) & 1;
    const bool of = op == 0 ? (msb != cf) : (msb != (bool)((r >> (bits - 2)) & 1));
    st.rflags &= ~(FLAG_CF | FLAG_OF);
    if (cf) st.rflags |= FLAG_CF;
    if (of && count == 1) st.rflags |= FLAG_OF;
    return r;
}
bool X86Cpu::MulDiv(int r, const ModRM& m, int sz) {
    typedef unsigned __int128 U; typedef __int128 S;
    const unsigned bits = sz * 8; const uint64_t mask = MaskOf(sz);
    const uint64_t src = ReadOp(m, sz) & mask;
    if (fault_) return true;
    if (r == 4 || r == 5) {                                   // mul / imul (one operand)
        U p; bool ovf;
        if (r == 4) { p = (U)(GetReg(RAX, sz) & mask) * src; ovf = (p >> bits) != 0; }
        else { S ps = (S)SExt(GetReg(RAX, sz), sz) * (S)SExt(src, sz); p = (U)ps; ovf = ps != (S)SExt((uint64_t)p & mask, sz); }
        if (sz == 1) SetReg(RAX, 2, (uint64_t)p & 0xffff);
        else { SetReg(RAX, sz, (uint64_t)p & mask); SetReg(RDX, sz, (uint64_t)(p >> bits) & mask); }
        st.rflags &= ~(FLAG_CF | FLAG_OF); if (ovf) st.rflags |= FLAG_CF | FLAG_OF;
        return true;
    }
    if (src == 0) return false;                                // #DE: divide by zero
    const unsigned tb = sz == 1 ? 16 : bits * 2;
    const U dv = sz == 1 ? (U)(st.gpr[RAX] & 0xffff) : (((U)(GetReg(RDX, sz) & mask) << bits) | (GetReg(RAX, sz) & mask));
    U q, rem;
    if (r == 6) { q = dv / src; rem = dv % src; if (q > mask) return false; }
    else {
        S sdv = (S)dv; if (tb < 128) sdv = (S)(dv << (128 - tb)) >> (128 - tb);
        const S sd = (S)SExt(src, sz); S sq, sr;
        if (sd == -1) { if (tb == 128 && dv == ((U)1 << 127)) return false; sq = -sdv; sr = 0; }
        else { sq = sdv / sd; sr = sdv % sd; }
        const S lo = -((S)1 << (bits - 1)), hi = ((S)1 << (bits - 1)) - 1;
        if (sq < lo || sq > hi) return false;                 // #DE: quotient overflow
        q = (U)sq; rem = (U)sr;
    }
    if (sz == 1) st.gpr[RAX] = (st.gpr[RAX] & ~0xffffull) | (((uint64_t)rem & 0xff) << 8) | ((uint64_t)q & 0xff);
    else { SetReg(RAX, sz, (uint64_t)q & mask); SetReg(RDX, sz, (uint64_t)rem & mask); }
    return true;
}

StopReason X86Cpu::Step() {
    fault_ = false; ip_ = st.rip;
    const uint64_t start = st.rip;
    rex_ = W_ = R_ = X_ = B_ = op16_ = rep_ = repne_ = false;
    uint8_t op = Fetch8();
    for (;;) {                                  // legacy prefixes we model
        if (fault_) break;
        if (op == 0x66) { op16_ = true; op = Fetch8(); continue; }
        if (op == 0xf3) { rep_ = true; op = Fetch8(); continue; }
        if (op == 0xf2) { repne_ = true; op = Fetch8(); continue; }
        if (op == 0xf0) { op = Fetch8(); continue; }   // LOCK: interpreter is single-threaded, so RMW is trivially atomic
        break;
    }
    if (!fault_ && op >= 0x40 && op <= 0x4f) {
        rex_ = true; W_ = op & 8; R_ = op & 4; X_ = op & 2; B_ = op & 1; op = Fetch8();
    }
    const int osz = W_ ? 8 : (op16_ ? 2 : 4);
    StopReason result = StopReason::Running;
    auto immv = [&](int size) -> uint64_t {      // immediate for opsize, sign-extended to 64
        if (size == 1) return (uint64_t)(int64_t)(int8_t)Fetch8();
        if (size == 2) return (uint64_t)(int64_t)(int16_t)Fetch16();
        return (uint64_t)(int64_t)(int32_t)Fetch32(); };
    const int imm32n = (osz == 2) ? 2 : 4;
    auto bitop = [&](int g, const ModRM& m, uint64_t idx, int sz) {   // g: 4 bt, 5 bts, 6 btr, 7 btc
        const unsigned bit = (unsigned)(idx & (sz * 8 - 1)); const uint64_t v = ReadOp(m, sz); if (fault_) return;
        uint64_t nv = v; if (g == 5) nv |= 1ull << bit; else if (g == 6) nv &= ~(1ull << bit); else if (g == 7) nv ^= 1ull << bit;
        if (g != 4) WriteOp(m, sz, nv);
        st.rflags = (st.rflags & ~FLAG_CF) | (((v >> bit) & 1) ? (uint64_t)FLAG_CF : 0ull); };

    if (op <= 0x3f && (op & 7) <= 5 && (op & 0xf8) != 0x0f && op != 0x0f) {
        int alu = op >> 3, form = op & 7;
        if (form <= 3) {
            int sz = (form & 1) ? osz : 1; ModRM m = DecodeModRM(0);
            if (!fault_) {
                if (form < 2) { uint64_t r = Alu(alu, ReadOp(m, sz), GetReg(m.reg, sz), sz); if (alu != 7) WriteOp(m, sz, r); }
                else { uint64_t r = Alu(alu, GetReg(m.reg, sz), ReadOp(m, sz), sz); if (alu != 7) SetReg(m.reg, sz, r); }
            }
        } else {
            int sz = form == 4 ? 1 : osz; uint64_t imm = immv(sz == 8 ? 4 : sz);
            if (!fault_) { uint64_t r = Alu(alu, GetReg(RAX, sz), imm, sz); if (alu != 7) SetReg(RAX, sz, r); }
        }
    } else if (op >= 0x50 && op <= 0x57) { Push(st.gpr[(op & 7) | (B_ ? 8 : 0)]);
    } else if (op >= 0x58 && op <= 0x5f) { uint64_t v; if (Pop(v)) st.gpr[(op & 7) | (B_ ? 8 : 0)] = v;
    } else if (op == 0x63) { ModRM m = DecodeModRM(0); if (!fault_) SetReg(m.reg, osz, (uint64_t)SExt(ReadOp(m, 4), 4));
    } else if (op == 0x68) { uint64_t v = immv(4); if (!fault_) Push(v);
    } else if (op == 0x6a) { uint64_t v = immv(1); if (!fault_) Push(v);
    } else if (op >= 0x70 && op <= 0x7f) { int8_t d = (int8_t)Fetch8(); if (!fault_ && Cond(op & 15)) ip_ += d;
    } else if (op == 0x80 || op == 0x81 || op == 0x83) {
        int sz = op == 0x80 ? 1 : osz; int immn = (op == 0x81) ? imm32n : 1;
        ModRM m = DecodeModRM(immn); uint64_t imm = immv(op == 0x81 ? (sz == 2 ? 2 : 4) : 1);
        if (!fault_) { int a = m.reg & 7; uint64_t r = Alu(a, ReadOp(m, sz), imm, sz); if (a != 7) WriteOp(m, sz, r); }
    } else if (op == 0x84 || op == 0x85) {
        int sz = op == 0x84 ? 1 : osz; ModRM m = DecodeModRM(0);
        if (!fault_) Alu(4, ReadOp(m, sz), GetReg(m.reg, sz), sz);
    } else if (op == 0x86 || op == 0x87) {
        int sz = op == 0x86 ? 1 : osz; ModRM m = DecodeModRM(0);
        if (!fault_) { uint64_t a = ReadOp(m, sz), b = GetReg(m.reg, sz); WriteOp(m, sz, b); SetReg(m.reg, sz, a); }
    } else if (op >= 0x88 && op <= 0x8b) {
        int sz = (op & 1) ? osz : 1; ModRM m = DecodeModRM(0);
        if (!fault_) { if (op < 0x8a) WriteOp(m, sz, GetReg(m.reg, sz)); else SetReg(m.reg, sz, ReadOp(m, sz)); }
    } else if (op == 0x8d) { ModRM m = DecodeModRM(0);
        if (!fault_) { if (m.isReg) return Undef("lea reg,reg"); SetReg(m.reg, osz, m.addr); }
    } else if (op == 0x90) { /* nop */
    } else if (op == 0xa8 || op == 0xa9) {
        int sz = op == 0xa8 ? 1 : osz; uint64_t imm = immv(sz == 8 ? 4 : sz);
        if (!fault_) Alu(4, GetReg(RAX, sz), imm, sz);
    } else if (op >= 0xb0 && op <= 0xb7) { uint64_t v = Fetch8(); if (!fault_) SetReg((op & 7) | (B_ ? 8 : 0), 1, v);
    } else if (op >= 0xb8 && op <= 0xbf) {
        int r = (op & 7) | (B_ ? 8 : 0);
        if (W_) { uint64_t v = Fetch64(); if (!fault_) st.gpr[r] = v; }
        else if (op16_) { uint64_t v = Fetch16(); if (!fault_) SetReg(r, 2, v); }
        else { uint64_t v = Fetch32(); if (!fault_) SetReg(r, 4, v); }
    } else if (op == 0xc0 || op == 0xc1 || op == 0xd0 || op == 0xd1 || op == 0xd2 || op == 0xd3) {
        int sz = (op & 1) ? osz : 1; bool imm8 = op <= 0xc1; ModRM m = DecodeModRM(imm8 ? 1 : 0);
        unsigned cnt = imm8 ? Fetch8() : ((op & 2) ? (unsigned)(st.gpr[RCX] & 0xff) : 1u);
        int a = m.reg & 7;
        if (!fault_) { if (a == 4 || a == 5 || a == 7) WriteOp(m, sz, Shift(a, ReadOp(m, sz), cnt, sz));
            else if (a == 0 || a == 1) WriteOp(m, sz, Rotate(a, ReadOp(m, sz), cnt, sz));
            else return Undef("rcl/rcr/sal-alias"); }
    } else if (op == 0xc3) { uint64_t v; if (Pop(v)) ip_ = v;
    } else if (op == 0xc6 || op == 0xc7) {
        int sz = op == 0xc6 ? 1 : osz; int immn = sz == 1 ? 1 : imm32n; ModRM m = DecodeModRM(immn);
        uint64_t imm = immv(sz == 1 ? 1 : (sz == 2 ? 2 : 4));
        if (!fault_) { if ((m.reg & 7) != 0) return Undef("c6/c7 /n"); WriteOp(m, sz, imm); }
    } else if (op == 0xcc) { st.rip = ip_; lastError = "int3"; return StopReason::Breakpoint;
    } else if (op == 0xe8) { int32_t d = (int32_t)Fetch32(); if (!fault_ && Push(ip_)) ip_ += d;
    } else if (op == 0xe9) { int32_t d = (int32_t)Fetch32(); if (!fault_) ip_ += d;
    } else if (op == 0xeb) { int8_t d = (int8_t)Fetch8(); if (!fault_) ip_ += d;
    } else if (op == 0xf4) { st.rip = ip_; lastError = "hlt"; return StopReason::Halt;
    } else if (op == 0xf6 || op == 0xf7) {
        int sz = op == 0xf6 ? 1 : osz; int r = PeekModRMReg();
        int immn = (r <= 1) ? (sz == 1 ? 1 : imm32n) : 0; ModRM m = DecodeModRM(immn);
        if (fault_) { /* fallthrough to fault handling */ }
        else if (r <= 1) { uint64_t imm = immv(sz == 1 ? 1 : (sz == 2 ? 2 : 4)); if (!fault_) Alu(4, ReadOp(m, sz), imm, sz); }
        else if (r == 2) WriteOp(m, sz, ~ReadOp(m, sz));
        else if (r == 3) { uint64_t a = ReadOp(m, sz); uint64_t res = Alu(5, 0, a, sz); WriteOp(m, sz, res); }
        else if (!MulDiv(r, m, sz)) { st.rip = start; lastError = "divide error (#DE) at rip=" + std::to_string(start); return StopReason::DivideError; }
    } else if (op == 0xfe || op == 0xff) {
        int sz = op == 0xfe ? 1 : osz; int r = PeekModRMReg(); ModRM m = DecodeModRM(0);
        if (!fault_) {
            if (r == 0 || r == 1) { uint64_t cf = st.rflags & FLAG_CF; uint64_t v = Alu(r == 0 ? 0 : 5, ReadOp(m, sz), 1, sz);
                st.rflags = (st.rflags & ~FLAG_CF) | cf; WriteOp(m, sz, v); }
            else if (op == 0xff && r == 2) { uint64_t t = ReadOp(m, 8); if (!fault_ && Push(ip_)) ip_ = t; }
            else if (op == 0xff && r == 4) { uint64_t t = ReadOp(m, 8); if (!fault_) ip_ = t; }
            else if (op == 0xff && r == 6) { uint64_t t = ReadOp(m, 8); if (!fault_) Push(t); }
            else return Undef("fe/ff /n");
        }
    } else if (op == 0x69 || op == 0x6b) {                       // imul r, r/m, imm
        int immn = op == 0x6b ? 1 : imm32n; ModRM m = DecodeModRM(immn); uint64_t imm = immv(op == 0x6b ? 1 : (osz == 2 ? 2 : 4));
        if (!fault_) {
            __int128 p = (__int128)SExt(ReadOp(m, osz), osz) * SExt(imm, osz); uint64_t r = (uint64_t)p & MaskOf(osz);
            SetReg(m.reg, osz, r); st.rflags &= ~(FLAG_CF | FLAG_OF); if ((__int128)SExt(r, osz) != p) st.rflags |= FLAG_CF | FLAG_OF;
        }
    } else if (op >= 0x91 && op <= 0x97) { int r = (op & 7) | (B_ ? 8 : 0); uint64_t a = GetReg(RAX, osz), b = GetReg(r, osz); SetReg(RAX, osz, b); SetReg(r, osz, a);
    } else if (op == 0x98) {                                     // cbw / cwde / cdqe
        if (W_) st.gpr[RAX] = (uint64_t)SExt(st.gpr[RAX], 4); else if (op16_) SetReg(RAX, 2, (uint64_t)SExt(st.gpr[RAX], 1)); else SetReg(RAX, 4, (uint64_t)SExt(st.gpr[RAX], 2));
    } else if (op == 0x99) { SetReg(RDX, osz, SExt(GetReg(RAX, osz), osz) < 0 ? ~0ull : 0);   // cwd / cdq / cqo
    } else if (op == 0x9c) { Push(st.rflags | 2);
    } else if (op == 0x9d) { uint64_t v; if (Pop(v)) st.rflags = (v & (FLAG_CF | FLAG_PF | FLAG_ZF | FLAG_SF | FLAG_DF | FLAG_OF)) | 2;
    } else if (op == 0x9e) { st.rflags = (st.rflags & ~0xd5ull) | (((st.gpr[RAX] >> 8) & 0xff) & 0xd5);   // sahf (SF ZF AF PF CF)
    } else if (op == 0x9f) { st.gpr[RAX] = (st.gpr[RAX] & ~0xff00ull) | ((((st.rflags & 0xd5) | 2)) << 8);  // lahf
    } else if (op == 0xc9) { st.gpr[RSP] = st.gpr[RBP]; uint64_t v; if (Pop(v)) st.gpr[RBP] = v;   // leave
    } else if (op == 0xf5) { st.rflags ^= FLAG_CF;
    } else if (op == 0xf8) { st.rflags &= ~FLAG_CF;
    } else if (op == 0xf9) { st.rflags |= FLAG_CF;
    } else if (op == 0xfc) { st.rflags &= ~FLAG_DF;
    } else if (op == 0xfd) { st.rflags |= FLAG_DF;
    } else if ((op >= 0xa4 && op <= 0xa7) || (op >= 0xaa && op <= 0xaf)) {   // movs cmps stos lods scas (+rep/repe/repne)
        const int sz = (op & 1) ? osz : 1; const int64_t d = (st.rflags & FLAG_DF) ? -(int64_t)sz : (int64_t)sz;
        const bool repAny = rep_ || repne_; const int kind = op & 0xfe;
        while (!fault_) {
            if (repAny && st.gpr[RCX] == 0) break;
            switch (kind) {
                case 0xa4: { uint64_t v = MemRead(st.gpr[RSI], sz); if (!fault_) MemWrite(st.gpr[RDI], sz, v); if (!fault_) { st.gpr[RSI] += d; st.gpr[RDI] += d; } break; }
                case 0xa6: { uint64_t a = MemRead(st.gpr[RSI], sz), b = MemRead(st.gpr[RDI], sz); if (!fault_) { Alu(7, a, b, sz); st.gpr[RSI] += d; st.gpr[RDI] += d; } break; }
                case 0xaa: MemWrite(st.gpr[RDI], sz, GetReg(RAX, sz)); if (!fault_) st.gpr[RDI] += d; break;
                case 0xac: { uint64_t v = MemRead(st.gpr[RSI], sz); if (!fault_) { SetReg(RAX, sz, v); st.gpr[RSI] += d; } break; }
                case 0xae: { uint64_t b = MemRead(st.gpr[RDI], sz); if (!fault_) { Alu(7, GetReg(RAX, sz), b, sz); st.gpr[RDI] += d; } break; }
            }
            if (fault_ || !repAny) break;
            --st.gpr[RCX];
            if (kind == 0xa6 || kind == 0xae) { const bool zf = st.rflags & FLAG_ZF; if ((rep_ && !zf) || (repne_ && zf)) break; }
        }
    } else if (op == 0x0f) {
        uint8_t o2 = Fetch8();
        if (fault_) { }
        else if (o2 == 0x05) { st.gpr[RCX] = ip_; st.gpr[R11] = st.rflags; result = StopReason::Syscall; }
        else if (o2 == 0x0b) { return Undef("ud2"); }
        else if (o2 == 0x1f) { DecodeModRM(0); }  // multi-byte nop
        else if (o2 >= 0x40 && o2 <= 0x4f) { ModRM m = DecodeModRM(0); if (!fault_) { uint64_t v = ReadOp(m, osz); if (Cond(o2 & 15)) SetReg(m.reg, osz, v); else if (osz == 4) SetReg(m.reg, 4, GetReg(m.reg, 4)); } }
        else if (o2 >= 0x80 && o2 <= 0x8f) { int32_t d = (int32_t)Fetch32(); if (!fault_ && Cond(o2 & 15)) ip_ += d; }
        else if (o2 >= 0x90 && o2 <= 0x9f) { ModRM m = DecodeModRM(0); if (!fault_) WriteOp(m, 1, Cond(o2 & 15) ? 1 : 0); }
        else if (o2 == 0xaf) {
            ModRM m = DecodeModRM(0);
            if (!fault_) {
                int64_t a = SExt(GetReg(m.reg, osz), osz), b = SExt(ReadOp(m, osz), osz);
                __int128 p = (__int128)a * b; uint64_t r = (uint64_t)p & MaskOf(osz);
                bool ovf = (__int128)SExt(r, osz) != p;
                SetReg(m.reg, osz, r); st.rflags &= ~(FLAG_CF | FLAG_OF); if (ovf) st.rflags |= FLAG_CF | FLAG_OF;
            }
        }
        else if (o2 == 0xb6 || o2 == 0xb7 || o2 == 0xbe || o2 == 0xbf) {
            int ssz = (o2 & 1) ? 2 : 1; ModRM m = DecodeModRM(0);
            if (!fault_) { uint64_t v = ReadOp(m, ssz); SetReg(m.reg, osz, o2 < 0xb8 ? v : (uint64_t)SExt(v, ssz)); }
        }
        else if (o2 == 0xa3 || o2 == 0xab || o2 == 0xb3 || o2 == 0xbb) {
            ModRM m = DecodeModRM(0);
            if (!fault_) { if (!m.isReg) return Undef("bt/bts/btr/btc [mem], reg (bit-string addressing)"); bitop(o2 == 0xa3 ? 4 : o2 == 0xab ? 5 : o2 == 0xb3 ? 6 : 7, m, GetReg(m.reg, osz), osz); }
        }
        else if (o2 == 0xba) { ModRM m = DecodeModRM(1); uint64_t imm = Fetch8(); int g = m.reg & 7; if (!fault_) { if (g < 4) return Undef("0f ba /0-3"); bitop(g, m, imm, osz); } }
        else if (o2 == 0xbc || o2 == 0xbd) {
            ModRM m = DecodeModRM(0);
            if (!fault_) {
                const uint64_t src = ReadOp(m, osz) & MaskOf(osz); const unsigned bits = osz * 8;
                if (rep_) {                                       // tzcnt / lzcnt (BMI1 / ABM)
                    uint64_t r; bool cf = false;
                    if (src == 0) { r = bits; cf = true; } else r = (o2 == 0xbc) ? (uint64_t)__builtin_ctzll(src) : (uint64_t)(bits - 1 - (63 - __builtin_clzll(src)));
                    SetReg(m.reg, osz, r); st.rflags &= ~(FLAG_CF | FLAG_ZF | FLAG_SF | FLAG_PF | FLAG_OF);
                    if (cf) { st.rflags |= FLAG_CF; }
                    if (r == 0) { st.rflags |= FLAG_ZF; }
                } else if (src == 0) st.rflags |= FLAG_ZF;       // bsf / bsr: destination unchanged
                else { st.rflags &= ~FLAG_ZF; SetReg(m.reg, osz, o2 == 0xbc ? (uint64_t)__builtin_ctzll(src) : (uint64_t)(63 - __builtin_clzll(src))); }
            }
        }
        else if (o2 == 0xb8 && rep_) {                            // popcnt
            ModRM m = DecodeModRM(0);
            if (!fault_) { uint64_t v = ReadOp(m, osz) & MaskOf(osz); SetReg(m.reg, osz, (uint64_t)__builtin_popcountll(v));
                st.rflags &= ~(FLAG_CF | FLAG_ZF | FLAG_SF | FLAG_PF | FLAG_OF); if (!v) st.rflags |= FLAG_ZF; }
        }
        else if (o2 == 0xb0 || o2 == 0xb1) {                      // cmpxchg
            int sz = o2 == 0xb0 ? 1 : osz; ModRM m = DecodeModRM(0);
            if (!fault_) { uint64_t dst = ReadOp(m, sz), acc = GetReg(RAX, sz); Alu(7, acc, dst, sz);
                if (!fault_) { if ((acc & MaskOf(sz)) == (dst & MaskOf(sz))) WriteOp(m, sz, GetReg(m.reg, sz)); else SetReg(RAX, sz, dst); } }
        }
        else if (o2 == 0xc0 || o2 == 0xc1) {                      // xadd
            int sz = o2 == 0xc0 ? 1 : osz; ModRM m = DecodeModRM(0);
            if (!fault_) { uint64_t d = ReadOp(m, sz), s2 = GetReg(m.reg, sz); uint64_t sum = Alu(0, d, s2, sz); if (!fault_) { SetReg(m.reg, sz, d); WriteOp(m, sz, sum); } }
        }
        else if (o2 >= 0xc8 && o2 <= 0xcf) { int r = (o2 & 7) | (B_ ? 8 : 0); st.gpr[r] = W_ ? __builtin_bswap64(st.gpr[r]) : (uint64_t)__builtin_bswap32((uint32_t)st.gpr[r]); }
        else return Undef("0f xx");
    } else {
        char b[24]; snprintf(b, sizeof b, "opcode %02x", op); return Undef(b);
    }

    if (fault_) {
        char b[200]; snprintf(b, sizeof b, "guest memory fault at 0x%llx (%s) rip=0x%llx",
            (unsigned long long)faultAddr, mem_.LastFault().reason.c_str(), (unsigned long long)start);
        lastError = b; st.rip = start; return StopReason::MemoryFault;
    }
    st.rip = ip_; ++instructionCount;
    if (trace) PS5X_LOG(Trace, "rip=%llx rax=%llx rdi=%llx", (unsigned long long)start, (unsigned long long)st.gpr[RAX], (unsigned long long)st.gpr[RDI]);
    return result;
}
StopReason X86Cpu::Run(uint64_t maxInstr) {
    for (uint64_t i = 0; i < maxInstr; ++i) {
        StopReason r = Step();
        if (r != StopReason::Running) return r;
    }
    lastError = "instruction limit reached"; return StopReason::StepLimit;
}
}
