#pragma once
#include <cstdint>
#include <string>
#include "memory/guest_memory.h"
namespace ps5x {
enum : uint64_t { FLAG_CF = 1, FLAG_PF = 4, FLAG_ZF = 0x40, FLAG_SF = 0x80, FLAG_DF = 0x400, FLAG_OF = 0x800 };
enum Reg { RAX, RCX, RDX, RBX, RSP, RBP, RSI, RDI, R8, R9, R10, R11, R12, R13, R14, R15 };

enum class StopReason { Running, Syscall, Halt, Breakpoint, MemoryFault, UndefinedOpcode, DivideError, StepLimit };
const char* StopReasonName(StopReason r);

struct CpuState {
    uint64_t gpr[16] = {};
    uint64_t rip = 0;
    uint64_t rflags = 2;
};

// Interpreter for a documented SUBSET of x86-64 (integer core: ALU, mov/lea,
// push/pop, call/ret/jmp/jcc, shifts, movzx/movsx, imul, setcc/cmov, syscall).
// No SSE/AVX/x87, no segments, no division, no string ops, no atomics yet.
// Unsupported opcodes stop execution with StopReason::UndefinedOpcode (never skipped).
class X86Cpu {
public:
    explicit X86Cpu(GuestMemory& m) : mem_(m) {}
    CpuState st;
    uint64_t instructionCount = 0;
    uint64_t faultAddr = 0;      // valid after MemoryFault
    std::string lastError;       // human-readable cause of last non-Running stop
    bool trace = false;

    StopReason Step();                    // execute exactly one instruction
    StopReason Run(uint64_t maxInstr);    // run until Syscall/Halt/fault/limit
    bool Push(uint64_t v);
    bool Pop(uint64_t& v);
private:
    struct ModRM { uint8_t mod = 0; int reg = 0, rm = 0; bool isReg = false; uint64_t addr = 0; };
    // decode helpers (all operate on the current instruction cursor ip_)
    uint8_t Fetch8(); uint16_t Fetch16(); uint32_t Fetch32(); uint64_t Fetch64();
    ModRM DecodeModRM(int immBytes);
    int PeekModRMReg();
    uint64_t GetReg(int idx, int size) const;
    void SetReg(int idx, int size, uint64_t v);
    uint64_t ReadOp(const ModRM& m, int size);
    void WriteOp(const ModRM& m, int size, uint64_t v);
    uint64_t MemRead(uint64_t addr, int size);
    void MemWrite(uint64_t addr, int size, uint64_t v);
    uint64_t Alu(int op, uint64_t a, uint64_t b, int size);
    uint64_t Shift(int op, uint64_t a, unsigned count, int size);
    uint64_t Rotate(int op, uint64_t a, unsigned count, int size);
    bool MulDiv(int r, const ModRM& m, int sz);   // F6/F7 /4../7; false = #DE
    bool Cond(int cc) const;
    void SetSZP(uint64_t r, int size);
    StopReason Undef(const char* what);

    GuestMemory& mem_;
    uint64_t ip_ = 0;
    bool fault_ = false;
    bool rex_ = false, W_ = false, R_ = false, X_ = false, B_ = false, op16_ = false, rep_ = false, repne_ = false;
};
}
