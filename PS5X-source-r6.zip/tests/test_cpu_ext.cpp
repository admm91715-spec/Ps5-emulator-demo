// Tests for the extended integer ISA. Every expected value is computed by hand from the x86-64 manual semantics, not from this code.
#include <cstdio>
#include "cpu/x86_cpu.h"
#include "memory/guest_memory.h"
using namespace ps5x;
using Bytes = std::vector<uint8_t>;
static int bad = 0, g_scenarios = 0;
#define CHECK(c) do { if (!(c)) { printf("CHECK failed: %s (line %d)\n", #c, __LINE__); ++bad; } } while (0)
#define EQ(a, b) do { unsigned long long _a = (unsigned long long)(a), _b = (unsigned long long)(b); if (_a != _b) { printf("EQ failed line %d: %s = 0x%llx, expected 0x%llx\n", __LINE__, #a, _a, _b); ++bad; } } while (0)
struct Rig {
    GuestMemory mem; X86Cpu cpu{mem};
    explicit Rig(Bytes code, bool hlt = true) {
        ++g_scenarios;
        if (hlt) code.push_back(0xF4);
        mem.Map(0x1000, 0x1000, PERM_R | PERM_X, "code"); mem.Poke(0x1000, code.data(), code.size());
        mem.Map(0x20000, 0x1000, PERM_R | PERM_W, "stack"); cpu.st.rip = 0x1000; cpu.st.gpr[RSP] = 0x21000;
    }
    StopReason run() { return cpu.Run(100000); }
    uint64_t& r(int i) { return cpu.st.gpr[i]; }
    bool f(uint64_t m) { return cpu.st.rflags & m; }
    uint64_t rd(uint64_t a, int n) { uint64_t v = 0; mem.Read(a, &v, n); return v; }
};
int main() {
    { Rig t({0xB8, 0, 0, 0, 0x80, 0xB9, 4, 0, 0, 0, 0xF7, 0xE1}); t.run();                       // mul ecx: 0x80000000*4 = 0x2_00000000
      EQ(t.r(RDX), 2); EQ(t.r(RAX), 0); CHECK(t.f(FLAG_CF) && t.f(FLAG_OF)); }
    { Rig t({0x48, 0xC7, 0xC0, 0xFF, 0xFF, 0xFF, 0xFF, 0x48, 0xC7, 0xC1, 2, 0, 0, 0, 0x48, 0xF7, 0xE1}); t.run();   // mul rcx: (2^64-1)*2
      EQ(t.r(RDX), 1); EQ(t.r(RAX), 0xFFFFFFFFFFFFFFFEull); CHECK(t.f(FLAG_CF)); }
    { Rig t({0xB8, 0xFE, 0xFF, 0xFF, 0xFF, 0xB9, 3, 0, 0, 0, 0xF7, 0xE9}); t.run();             // imul ecx: -2*3 = -6
      EQ(t.r(RAX), 0xFFFFFFFAull); EQ(t.r(RDX), 0xFFFFFFFFull); CHECK(!t.f(FLAG_CF) && !t.f(FLAG_OF)); }
    { Rig t({0xB8, 6, 0, 0, 0, 0x6B, 0xC0, 7}); t.run(); EQ(t.r(RAX), 42); }                       // imul eax,eax,7
    { Rig t({0xB8, 6, 0, 0, 0, 0x69, 0xC0, 0xE8, 3, 0, 0}); t.run(); EQ(t.r(RAX), 6000); }          // imul eax,eax,1000
    { Rig t({0xB8, 100, 0, 0, 0, 0x31, 0xD2, 0xB9, 7, 0, 0, 0, 0xF7, 0xF1}); t.run(); EQ(t.r(RAX), 14); EQ(t.r(RDX), 2); }   // div ecx
    { Rig t({0xB8, 0x9C, 0xFF, 0xFF, 0xFF, 0x99, 0xB9, 7, 0, 0, 0, 0xF7, 0xF9}); t.run(); EQ(t.r(RAX), 0xFFFFFFF2ull); EQ(t.r(RDX), 0xFFFFFFFEull); }   // idiv: -100/7 = -14 r -2
    { Rig t({0xB8, 7, 1, 0, 0, 0xB1, 10, 0xF6, 0xF1}); t.run(); EQ(t.r(RAX) & 0xFFFF, 0x031A); }   // div cl: 263/10 = 26 r 3 (AL=0x1A, AH=3)
    { Rig t({0x48, 0xC7, 0xC2, 1, 0, 0, 0, 0x31, 0xC0, 0x48, 0xC7, 0xC1, 2, 0, 0, 0, 0x48, 0xF7, 0xF1}); t.run(); EQ(t.r(RAX), 0x8000000000000000ull); EQ(t.r(RDX), 0); }  // 2^64 / 2
    { Rig t({0xB8, 1, 0, 0, 0, 0x31, 0xC9, 0xF7, 0xF1}, false); CHECK(t.run() == StopReason::DivideError); EQ(t.cpu.st.rip, 0x1000 + 7); }   // div by zero, rip at faulting insn
    { Rig t({0x31, 0xC0, 0xBA, 1, 0, 0, 0, 0xB9, 1, 0, 0, 0, 0xF7, 0xF1}, false); CHECK(t.run() == StopReason::DivideError); }       // quotient 2^32 overflows
    { Rig t({0xB8, 0, 0, 0, 0x80, 0x99, 0xB9, 0xFF, 0xFF, 0xFF, 0xFF, 0xF7, 0xF9}, false); CHECK(t.run() == StopReason::DivideError); } // INT_MIN / -1
    // rotates
    { Rig t({0xB8, 1, 0, 0, 0x80, 0xD1, 0xC0}); t.run(); EQ(t.r(RAX), 3); CHECK(t.f(FLAG_CF)); }                                 // rol eax,1
    { Rig t({0xB8, 3, 0, 0, 0, 0xD1, 0xC8}); t.run(); EQ(t.r(RAX), 0x80000001ull); CHECK(t.f(FLAG_CF)); }                       // ror eax,1
    { Rig t({0xB8, 0x78, 0x56, 0x34, 0x12, 0xB1, 4, 0xD3, 0xC0}); t.run(); EQ(t.r(RAX), 0x23456781ull); }                       // rol eax,cl
    { Rig t({0xB0, 0x81, 0xD0, 0xC0}); t.run(); EQ(t.r(RAX) & 0xff, 3); CHECK(t.f(FLAG_CF)); }                                    // rol al,1
    // sign extension
    { Rig t({0xB8, 0, 0, 0, 0x80, 0x99}); t.run(); EQ(t.r(RDX), 0xFFFFFFFFull); }                                                // cdq
    { Rig t({0xB8, 0, 0, 0, 0x80, 0x48, 0x98}); t.run(); EQ(t.r(RAX), 0xFFFFFFFF80000000ull); }                                  // cdqe
    { Rig t({0x48, 0xC7, 0xC0, 0xFF, 0xFF, 0xFF, 0xFF, 0x48, 0x99}); t.run(); EQ(t.r(RDX), ~0ull); }                            // cqo
    // bit ops
    { Rig t({0xB8, 0x10, 0, 0, 0, 0x0F, 0xBA, 0xE0, 4}); t.run(); CHECK(t.f(FLAG_CF)); }                                          // bt eax,4
    { Rig t({0xB8, 0x10, 0, 0, 0, 0x0F, 0xBA, 0xE0, 3}); t.run(); CHECK(!t.f(FLAG_CF)); }
    { Rig t({0xB8, 0x10, 0, 0, 0, 0x0F, 0xBA, 0xE8, 0}); t.run(); EQ(t.r(RAX), 0x11); CHECK(!t.f(FLAG_CF)); }                   // bts eax,0
    { Rig t({0xB8, 0x10, 0, 0, 0, 0x0F, 0xBA, 0xF0, 4}); t.run(); EQ(t.r(RAX), 0); CHECK(t.f(FLAG_CF)); }                       // btr eax,4
    { Rig t({0xB8, 0x10, 0, 0, 0, 0x0F, 0xBA, 0xF8, 1}); t.run(); EQ(t.r(RAX), 0x12); }                                          // btc eax,1
    { Rig t({0xB9, 5, 0, 0, 0, 0xB8, 0x20, 0, 0, 0, 0x0F, 0xA3, 0xC8}); t.run(); CHECK(t.f(FLAG_CF)); }                          // bt eax,ecx
    { Rig t({0xB9, 0x50, 0, 0, 0, 0x0F, 0xBC, 0xC1}); t.run(); EQ(t.r(RAX), 4); CHECK(!t.f(FLAG_ZF)); }                          // bsf
    { Rig t({0xB9, 0x50, 0, 0, 0, 0x0F, 0xBD, 0xC1}); t.run(); EQ(t.r(RAX), 6); }                                                // bsr
    { Rig t({0xB8, 0x77, 0, 0, 0, 0x31, 0xC9, 0x0F, 0xBC, 0xC1}); t.run(); EQ(t.r(RAX), 0x77); CHECK(t.f(FLAG_ZF)); }            // bsf src=0: dest unchanged, ZF=1
    { Rig t({0xB9, 0x50, 0, 0, 0, 0xF3, 0x0F, 0xBD, 0xC1}); t.run(); EQ(t.r(RAX), 25); }                                        // lzcnt(0x50)=25
    { Rig t({0xB9, 0x50, 0, 0, 0, 0xF3, 0x0F, 0xBC, 0xC1}); t.run(); EQ(t.r(RAX), 4); }                                         // tzcnt(0x50)=4
    { Rig t({0x31, 0xC9, 0xF3, 0x0F, 0xBC, 0xC1}); t.run(); EQ(t.r(RAX), 32); CHECK(t.f(FLAG_CF)); }                              // tzcnt(0)=32, CF=1
    { Rig t({0xB9, 0x50, 0, 0, 0, 0xF3, 0x0F, 0xB8, 0xC1}); t.run(); EQ(t.r(RAX), 2); }                                         // popcnt
    { Rig t({0x48, 0xC7, 0xC1, 0xFF, 0xFF, 0xFF, 0xFF, 0xF3, 0x48, 0x0F, 0xB8, 0xC1}); t.run(); EQ(t.r(RAX), 64); }               // popcnt rcx(-1)=64
    { Rig t({0xB8, 0x44, 0x33, 0x22, 0x11, 0x0F, 0xC8}); t.run(); EQ(t.r(RAX), 0x44332211ull); }                                 // bswap eax
    { Rig t({0x48, 0xB8, 1, 2, 3, 4, 5, 6, 7, 8, 0x48, 0x0F, 0xC8}); t.run(); EQ(t.r(RAX), 0x0102030405060708ull); }              // bswap rax
    { Rig t({0xB8, 5, 0, 0, 0, 0xB9, 9, 0, 0, 0, 0x48, 0x91}); t.run(); EQ(t.r(RAX), 9); EQ(t.r(RCX), 5); }                       // xchg rax,rcx
    // flags / stack
    { Rig t({0xF9, 0x9C, 0x58}); t.run(); EQ(t.r(RAX) & 3, 3); }                                                                   // stc; pushf; pop rax -> CF|bit1
    { Rig t({0xB8, 0x41, 0, 0, 0, 0x50, 0x9D}); t.run(); CHECK(t.f(FLAG_CF) && t.f(FLAG_ZF)); }                                   // popf
    { Rig t({0xF9, 0xF5}); t.run(); CHECK(!t.f(FLAG_CF)); }                                                                        // stc; cmc
    { Rig t({0xF9, 0x9F}); t.run(); EQ((t.r(RAX) >> 8) & 0xff, 3); }                                                               // lahf
    { Rig t({0x55, 0x48, 0x89, 0xE5, 0x48, 0x83, 0xEC, 0x10, 0xC9}); t.r(RBP) = 0x1234; t.run(); EQ(t.r(RSP), 0x21000); EQ(t.r(RBP), 0x1234); }   // enter-style frame + leave
    // string ops
    { Rig t({0xBF, 0, 1, 2, 0, 0xB9, 16, 0, 0, 0, 0xB0, 0xAB, 0xF3, 0xAA}); t.run();                                              // rep stosb x16
      for (int i = 0; i < 16; ++i) { EQ(t.rd(0x20100 + i, 1), 0xAB); }
      EQ(t.rd(0x20110, 1), 0); EQ(t.r(RCX), 0); EQ(t.r(RDI), 0x20110); }
    { Rig t({0xBE, 0, 1, 2, 0, 0xBF, 0, 2, 2, 0, 0xB9, 2, 0, 0, 0, 0xF3, 0x48, 0xA5}); for (int i = 0; i < 16; ++i) { uint8_t b = (uint8_t)(i + 1); t.mem.Poke(0x20100 + i, &b, 1); }
      t.run(); for (int i = 0; i < 16; ++i) { EQ(t.rd(0x20200 + i, 1), i + 1); }
      EQ(t.r(RSI), 0x20110); }                                // rep movsq x2
    { Rig t({0xFD, 0xBF, 0x0F, 1, 2, 0, 0xB9, 4, 0, 0, 0, 0xB0, 0x5A, 0xF3, 0xAA}); t.run();                                      // std; rep stosb (backward)
      for (int i = 0; i < 4; ++i) { EQ(t.rd(0x2010F - i, 1), 0x5A); }
      EQ(t.rd(0x20110, 1), 0); EQ(t.rd(0x2010B, 1), 0); EQ(t.r(RDI), 0x2010B); }
    { Rig t({0xBF, 0, 3, 2, 0, 0xB9, 100, 0, 0, 0, 0xB0, 'd', 0xF2, 0xAE}); t.mem.Poke(0x20300, "abcdef", 7); t.run();               // repne scasb
      EQ(t.r(RDI), 0x20304); EQ(t.r(RCX), 96); CHECK(t.f(FLAG_ZF)); }
    { Rig t({0xBE, 0, 3, 2, 0, 0xBF, 0, 4, 2, 0, 0xB9, 10, 0, 0, 0, 0xF3, 0xA6}); t.mem.Poke(0x20300, "abcXef", 7); t.mem.Poke(0x20400, "abcYef", 7); t.run();   // repe cmpsb stops at mismatch
      EQ(t.r(RSI), 0x20304); EQ(t.r(RCX), 6); CHECK(!t.f(FLAG_ZF)); }
    { Rig t({0xBF, 0xF8, 0x0F, 2, 0, 0xB9, 64, 0, 0, 0, 0xB0, 1, 0xF3, 0xAA}, false); CHECK(t.run() == StopReason::MemoryFault);   // runs off the stack region: precise fault
      EQ(t.cpu.st.rip, 0x1000 + 12); CHECK(t.r(RCX) < 64); EQ(t.rd(0x20FF8, 1), 1); }
    // atomics (LOCK prefix accepted; interpreter is single-threaded)
    { Rig t({0xB8, 5, 0, 0, 0, 0xB9, 9, 0, 0, 0, 0xBA, 0, 4, 2, 0, 0xF0, 0x0F, 0xB1, 0x0A}); uint32_t v = 5; t.mem.Poke(0x20400, &v, 4); t.run();   // lock cmpxchg: equal
      EQ(t.rd(0x20400, 4), 9); CHECK(t.f(FLAG_ZF)); }
    { Rig t({0xB8, 7, 0, 0, 0, 0xB9, 9, 0, 0, 0, 0xBA, 0, 4, 2, 0, 0xF0, 0x0F, 0xB1, 0x0A}); uint32_t v = 5; t.mem.Poke(0x20400, &v, 4); t.run();   // not equal
      EQ(t.rd(0x20400, 4), 5); EQ(t.r(RAX), 5); CHECK(!t.f(FLAG_ZF)); }
    { Rig t({0xB9, 9, 0, 0, 0, 0xBA, 0, 4, 2, 0, 0xF0, 0x0F, 0xC1, 0x0A}); uint32_t v = 5; t.mem.Poke(0x20400, &v, 4); t.run(); EQ(t.rd(0x20400, 4), 14); EQ(t.r(RCX), 5); }   // lock xadd
    // regression: unsupported things must still stop loudly
    { Rig t({0xF3, 0x0F, 0x10, 0xC0}, false); CHECK(t.run() == StopReason::UndefinedOpcode); }                                      // movss (SSE) not implemented
    { Rig t({0x0F, 0xA3, 0x08}, false); CHECK(t.run() == StopReason::UndefinedOpcode); }                                            // bt [mem],reg not implemented
    printf(bad ? "cpu_ext tests FAILED (%d scenarios run)\n" : "cpu_ext tests passed (%d scenarios run)\n", g_scenarios); return bad;
}
