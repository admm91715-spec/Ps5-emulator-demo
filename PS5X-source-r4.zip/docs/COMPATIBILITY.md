# Compatibility

Statuses PS5X can assign (deliberately few, because it can justify few):

| Status | Meaning |
|---|---|
| Invalid | Missing, unreadable, empty, malformed, or unrecognised file |
| Unsupported | Recognised but cannot be loaded (e.g. signed/encrypted SELF, PKG, a game directory whose `eboot.bin` is one of these) |
| Loads only (not playable) | Plain x86-64 ELF accepted by the loader. Execution only works if it sticks to the implemented instruction subset and syscalls |

There is no "Boots / In-game / Playable" status because nothing qualifies. Those must only be added with evidence.

## Test log
| Software | Result |
|---|---|
| Built-in sample (`make-sample`) | Runs to exit(0), prints text, draws 4 rectangles; verified by automated test |
| Any commercial PS5 title | **Not tested. Expected: Unsupported** (encrypted container; PS5X does not decrypt) |
| GTA VI | Not tested, not supported |

No performance claims are made. The CLI prints throughput measured on the run itself; the sample is far too short to be a benchmark.
