# Compatibility database

File: `Compatibility/compat.db` (text, blocks separated by a blank line, `key: value`). Shipped **empty** on purpose.
Levels: Not Tested < Boots < Intro < Menu < In-Game < Playable < Stable.

The tool **refuses** (and the loader rejects + reports) entries that do not carry their evidence:
* Any level above Not Tested: `emulator_version`, `tester`, `date` (YYYY-MM-DD), `host` (CPU/GPU/driver), `evidence` (log/capture reference), `sessions >= 1`.
* Boots: boot = partial|yes. Intro: boot = yes. Menu: boot = yes and menu = partial|yes. In-Game: boot = yes, menu recorded, gameplay = partial|yes.
* Playable/Stable: gameplay = yes, a **measured** `performance` note with its method, graphics and audio assessed and not broken.
* Stable: at least 5 independent sessions.
* Not Tested entries cannot carry performance numbers.
Fields: title_id, name, exe_format, emulator_version, level, boot/menu/gameplay (unknown|no|partial|yes), graphics/audio (unknown|broken|partial|good), performance, issues, tester, date, host, evidence, sessions.

Commands: `ps5x-cli compat list | show ID | validate | set ID key=value ...` (e.g. `set PPSA00001 name="X" level=Boots boot=yes tester=me date=2026-11-22 emulator_version=0.1.0 host="rig" evidence=logs/run1.log sessions=1`).
The database records results from *whatever emulator you tested*; a record in it is not a claim that PS5X runs the title.

## Regression harness
`ps5x-cli regress manifest.txt`; line format: `name | path | expect_exit | expect_stdout_contains | expect_frame_fnv1a_hex_or_- | max_instructions`.
Each test runs the real load -> CPU -> kernel -> GPU pipeline; the frame hash is an FNV-1a over the software framebuffer.
