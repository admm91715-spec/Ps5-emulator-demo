# Foundation evaluation: which PS5 emulator should be the primary base?

Date of research: 2026-11-22. Method: web search + fetching GitHub pages (READMEs, wikis, release notes) and press coverage.
Limits: the build sandbox has **no network access** (`git ls-remote` fails: "Could not resolve host"), so no repository
could be cloned, read file-by-file, or built. Everything below about implementation comes from the projects' own
documentation and third-party reporting, i.e. it is **self-reported and unverified by me**. Compatibility claims are
mostly single-title reports from individual forks.

## Candidates

| Project | Language / license | What the evidence says | Verdict |
|---|---|---|---|
| **KytyPS5** (lineage: original Kyty by Vladimir M., MIT, "PS4 & PS5 emulator", early stage; KytyPS5 forks state GPL-2.0) | C++, Vulkan 1.3 renderer, CMake, clang-cl on Windows, Clang on Linux; Win/Linux/macOS (macOS via Rosetta+MoltenVK) | Most active public C++ effort found. Has CI badges for 3 OSes, a `kyty_tests` target, RDNA2 shader recompiler, a community compatibility site. Many forks; documented per-title progress is mostly Demon's Souls (self-reported 60+ fps on a high-end PC in one fork's notes). Windows packages need an AVX2/FMA/BMI2 CPU. | **Best primary base** |
| **SharpEmu** | C# (Avalonia UI), GPL-2.0 | Self-described experimental; reports (Sept 2026) of 12 of 55 tested titles reaching gameplay, 6 at 60 fps - self-reported, via press. Earlier press said "cannot run any games yet", so it moves fast. | Credible second option; different language/runtime from KytyPS5 so code cannot be shared |
| **AnyPS5** | Relinker/porting tool (converts executables to native binaries + replacement libraries), not a conventional emulator | Reported 1 title "Playable" (Oct 2026); ~50% of system functions implemented per its tracker. License not verified by me. | Different architecture; out of scope |
| shadPS4 | PS4 only | Mature but PS4. | Not a PS5 base |
| RPCSX | Research project | Not an emulator ready for use. | Reference only |

## Caveats you should know before investing
1. **Fragmented ecosystem.** GitHub metadata shows the network root is `KytyPS5/KytyPS5`, but I could only reach the organisation's website repo, not the root source repo. Forks (chenxiao07, modhollow, Jetsku, Supermedo, ceremony88, ...) call different repos "upstream". Several are title-specific (e.g. "Demon's Souls-only"). **Before contributing, identify the repository the maintainers actually merge into.**
2. **Licence.** GPL-2.0 per the projects' statements; I could not read the LICENSE files. Original Kyty was MIT; confirm the current repo's LICENSE and third-party notices before copying code. PS5X is MIT: PS5X code may flow into a GPL-2.0 project, not the reverse (without making PS5X GPL).
3. **Unofficial binaries.** Many forks ship prebuilt Windows zips. Prefer building a tagged source release yourself, or at least verify the published SHA256SUMS.
4. **Game files.** These emulators expect a game directory containing `eboot.bin` and `sce_sys` (or a `.zar` archive) from *your own* copy. Retail PS5 content is encrypted on the console; obtaining usable dumps involves console exploits and bypassing protections, which is legally risky in many jurisdictions and is something PS5X will not help with. Check the law where you live.
5. **Hardware.** KytyPS5 packages state AVX2/FMA/BMI2 CPU + Vulkan GPU; forks report 24-32 GB RAM and 8-12 GB+ VRAM for demanding titles. Shader pre-compilation is per-GPU/driver (reported 45 min-2 h+). No performance claim here is mine.

## Decision
Make KytyPS5 (the maintainers' real upstream) the primary foundation. Keep PS5X only as a small documented
test harness and the home of `ps5x_preflight`. Do **not** keep growing PS5X's toy CPU/GPU.

## Strategy
1. Identify the canonical upstream (see caveat 1), read LICENSE, pin a release tag.
2. Reproduce its build on a machine that can do it (docs/BUILD_KYTYPS5.md). Run its `kyty_tests`.
3. Contribute where hardware-free or low-risk work is valuable: build/CI reproducibility, test coverage, issue triage
   (the project reportedly has ~560 open issues), documentation, compatibility reports using its template.
4. With a legally owned title and suitable hardware: reproduce bugs, bisect regressions, test on AMD (one release says its RDNA2 fix was untested), submit small focused PRs.
5. Only claim compatibility from recorded evidence: exact release, game version, GPU/driver, what was verified.

## What was done in this step
- Added `ps5x_preflight`: checks CPU features (AVX2/FMA/BMI2), RAM, and game-folder layout (eboot.bin, sce_sys, param.json,
  path hazards the KytyPS5 docs mention) - useful for anyone about to use KytyPS5. Tested (6 check groups) and run here.
  It never decrypts or alters files and states plainly that layout checks are not compatibility claims.
- No KytyPS5 code was modified: impossible without network access.
