# Architecture

```
frontend (CLI) → core::Emulator ─┬─ loader  (ELF64 → GuestMemory regions)
                                 ├─ cpu     (X86Cpu interpreter, stops on syscall/halt/fault/undefined/limit)
                                 ├─ kernel  (syscall table; FreeBSD-style ABI + PS5X test ABI ≥ 0x1000)
                                 ├─ gpu     (GpuBackend: software framebuffer; Vulkan probe optional)
                                 ├─ audio   (AudioRing + WAV/null backends)
                                 ├─ input   (keyboard map → virtual pad; XInput on Windows)
                                 └─ storage (format identification, game library)
common: Logger (ring buffer + file), Config (INI, malformed lines are reported)
```

Run loop (`Emulator::Run`): `cpu.Run()` until it returns; on `Syscall` the kernel dispatches and execution resumes; any
other stop reason (memory fault, undefined opcode, limit) is reported to the user with rip and cause — never skipped.

Design rules: failures are loud; unsupported things are named as unsupported; compat status is derived, never hand-set.

Known simplifications: a memory access must be inside a single region; faults mid-instruction may leave partial register
state; shift counts ≥ operand width are clamped; `hlt` is not counted as a retired instruction; host must be little-endian.

PS5X test ABI (syscalls ≥ 0x1000) exists only to drive GPU/audio/input from guest code in tests. It is not a PS5 interface.
