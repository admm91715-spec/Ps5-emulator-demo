# Reproducible build path for KytyPS5 (not executed by me)

## Why it cannot be built in the PS5X sandbox
- No network: cannot reach github.com, so no clone and no submodules (`git submodule update --init --recursive`) or dependency downloads.
- Toolchain: only g++ is present; the project requires **Clang (clang-cl on Windows)**, CMake >= 3.22.1 and Ninja (none installed). `cl.exe` is rejected.
- Resources: 1 CPU core and ~3.9 GB RAM, which is unrealistic for a Vulkan emulator with statically linked FFmpeg.
- No GPU/Vulkan 1.3 device and no legally owned game files, so even a successful build could not be run or tested here.

## Recommended path (Windows 10/11 x64)
Prerequisites (from the KytyPS5 fork wiki I read): Git, CMake >= 3.22.1, Ninja, Python 3, Vulkan SDK, glslangValidator on PATH,
Visual Studio 2022 or Build Tools with "Desktop development with C++" and "C++ Clang tools for Windows". The optional Qt
launcher needs Qt 6.10.3 (MSVC 2022 64-bit). CPU needs AVX2/FMA/BMI2 to run the result.

Commands as documented by one fork (modhollow/KytyPS5, a Demon's Souls-only fork; **replace the repository and tag with the
maintainers' upstream after verifying it**, and read that repo's README, which is authoritative):
```
git -c core.autocrlf=false clone <UPSTREAM-URL> KytyPS5
cd KytyPS5
git checkout --detach <RELEASE-TAG>
git submodule update --init --recursive
cmake -S . -B _Build/windows -G Ninja -DCMAKE_BUILD_TYPE=Release -DCMAKE_C_COMPILER=clang-cl -DCMAKE_CXX_COMPILER=clang-cl -DKYTY_MARCH=x86-64-v3 -DCMAKE_PREFIX_PATH="<Qt 6.10.3 msvc2022_64>"
cmake --build _Build/windows --target kyty_emulator launcher kyty_shader_precompile
cmake --install _Build/windows --prefix _Build/windows/install
```
`core.autocrlf=false` matters: the shader-cache identity is computed from source files, so CRLF checkouts will not reuse release caches.
Linux (no Qt): the README documents a `_Build/linux-no-qt` tree; build with
`cmake --build _Build/linux-no-qt --target kyty_emulator kyty_tests --parallel` (configure flags: see the repo README; Clang required).

## Verify before trusting
1. `ps5x_preflight [game-dir]` (this repo) for host + folder layout.
2. Run `kyty_tests`, then `kyty_emulator --help` for the options your version supports.
3. Record: release/commit, game version, GPU + driver, what was observed. Do not infer compatibility from a successful launch.
