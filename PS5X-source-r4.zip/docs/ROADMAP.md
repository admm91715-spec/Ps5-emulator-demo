# Path toward real PS5 compatibility

Honest summary: this repository is step zero. Public PS5 emulation work already exists (KytyPS5 and SharpEmu, both
GPL-2.0; AnyPS5 takes a relinking approach). Contributing there is more productive than growing this foundation alone.

Missing pieces, roughly in order:
1. **Executable format**: PS5X handles plain ELF only. Real titles ship in signed containers; any support must stay within
   legal limits (user-owned content, no bundled keys/firmware, no DRM circumvention).
2. **CPU**: full Zen 2 user-mode ISA (SSE2–SSE4.2, AVX/AVX2, BMI, FMA, x87, mul/div, string ops, atomics, FS/GS TLS),
   or a JIT/recompiler; precise exceptions; a performance plan.
3. **Dynamic linking + HLE**: relocations, module loader, and reimplementation of the system libraries titles import
   (libkernel, memory, threads/sync, file system, audio, pad, video out, save data…). This is the largest body of work.
4. **GPU**: AMD GFX10/RDNA2 command-buffer (PM4) processing, resource/state tracking, RDNA2 shader → SPIR-V recompiler, Vulkan backend.
5. **Memory model**: 16 KiB pages, direct/flexible memory, guest↔host mapping at scale.
6. **Frontend**: GUI (library, settings, logs), real audio device output, controller UI.
7. **QA**: per-title compatibility database with recorded evidence; CI on Windows.
