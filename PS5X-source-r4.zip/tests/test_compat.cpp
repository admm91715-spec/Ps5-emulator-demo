#include <cstdio>
#include <filesystem>
#include <fstream>
#include "common/config.h"
#include "compat/compat_db.h"
#include "core/app_paths.h"
#include "core/emulator.h"
#include "core/regress.h"
namespace fs = std::filesystem; using namespace ps5x;
static int bad = 0;
#define CHECK(c) do { if (!(c)) { printf("CHECK failed: %s (line %d)\n", #c, __LINE__); ++bad; } } while (0)
static CompatEntry Evidence(CompatLevel l) {
    CompatEntry e; e.titleId = "TEST00001"; e.name = "Test Title"; e.level = l; e.emulatorVersion = "0.1.0"; e.tester = "qa"; e.date = "2026-11-22";
    e.host = "i7/RTX4070/551.23"; e.evidence = "logs/test00001-run1.log"; e.sessions = 1; return e;
}
static bool Refused(const CompatEntry& e) { return !ValidateCompat(e).empty(); }
int main() {
    // levels
    CompatLevel l; CHECK(ParseCompatLevel("in-game", l) && l == CompatLevel::InGame); CHECK(ParseCompatLevel("Not Tested", l) && l == CompatLevel::NotTested); CHECK(!ParseCompatLevel("great", l));
    // untested entry valid, evidence-free claims refused
    CompatEntry nt; nt.titleId = "X1"; nt.name = "n"; CHECK(!Refused(nt));
    CompatEntry noEv = Evidence(CompatLevel::Boots); noEv.boot = "yes"; noEv.evidence.clear(); CHECK(Refused(noEv));
    CompatEntry noTester = Evidence(CompatLevel::Boots); noTester.boot = "yes"; noTester.tester.clear(); CHECK(Refused(noTester));
    CompatEntry badDate = Evidence(CompatLevel::Boots); badDate.boot = "yes"; badDate.date = "yesterday"; CHECK(Refused(badDate));
    CompatEntry zeroSess = Evidence(CompatLevel::Boots); zeroSess.boot = "yes"; zeroSess.sessions = 0; CHECK(Refused(zeroSess));
    CompatEntry ntPerf = nt; ntPerf.performance = "60 fps"; CHECK(Refused(ntPerf));              // no fabricated numbers on untested titles
    // ladder consistency
    CompatEntry boots = Evidence(CompatLevel::Boots); boots.boot = "partial"; CHECK(!Refused(boots));
    CompatEntry intro = Evidence(CompatLevel::Intro); intro.boot = "partial"; CHECK(Refused(intro)); intro.boot = "yes"; CHECK(!Refused(intro));
    CompatEntry menu = Evidence(CompatLevel::Menu); menu.boot = "yes"; CHECK(Refused(menu)); menu.menu = "yes"; CHECK(!Refused(menu));
    CompatEntry ig = Evidence(CompatLevel::InGame); ig.boot = "yes"; ig.menu = "yes"; CHECK(Refused(ig)); ig.gameplay = "partial"; CHECK(!Refused(ig));
    CompatEntry pl = Evidence(CompatLevel::Playable); pl.boot = pl.menu = pl.gameplay = "yes"; CHECK(Refused(pl));      // needs perf + graphics/audio assessed
    pl.performance = "avg 41 fps over 60 s, built-in counter"; pl.graphics = "good"; pl.audio = "partial"; CHECK(!Refused(pl));
    pl.audio = "broken"; CHECK(Refused(pl)); pl.audio = "good";
    CompatEntry st = pl; st.level = CompatLevel::Stable; CHECK(Refused(st)); st.sessions = 5; CHECK(!Refused(st));
    CompatEntry badEnum = boots; badEnum.menu = "maybe"; CHECK(Refused(badEnum));
    CompatEntry badId = boots; badId.titleId = "a b"; CHECK(Refused(badId));
    // db: roundtrip, rejection, duplicates, unknown fields
    CompatDb db; std::vector<std::string> pr; CHECK(db.Upsert(pl, &pr)); CHECK(!db.Upsert(noEv, &pr)); CHECK(!pr.empty());
    CHECK(db.LevelFor("TEST00001") == CompatLevel::Playable); CHECK(db.LevelFor("nope") == CompatLevel::NotTested);
    std::string path = (fs::temp_directory_path() / "ps5x_compat_test.db").string(), e;
    CHECK(db.Save(path, &e)); CompatDb d2; std::vector<std::string> errs; CHECK(d2.Load(path, &errs)); CHECK(d2.Entries().size() == 1);
    CHECK(d2.Find("TEST00001")->performance == pl.performance); CHECK(d2.Find("TEST00001")->level == CompatLevel::Playable);
    CompatDb d3; errs.clear();
    CHECK(!d3.ParseText("title_id: A\nname: a\nlevel: Playable\n\ntitle_id: B\nname: b\n\ntitle_id: B\nname: dup\n\ntitle_id: C\nname: c\nbogus: 1\n", &errs));
    CHECK(d3.Entries().size() == 1 && d3.Find("B") != nullptr); CHECK(d3.Find("A") == nullptr); CHECK(d3.Find("C") == nullptr); CHECK(errs.size() >= 3);   // A rejected (no evidence), dup + unknown field reported
    CompatDb d4; errs.clear(); CHECK(!d4.ParseText("name: orphan\n", &errs)); CHECK(!d4.ParseText("garbage line\n", &errs));
    fs::remove(path);
    // app paths
    { const char* av[] = {"ps5x", "--data", "D", "--compat", "C.db", "--logs", "L", "run"}; int i = 1; AppPaths ap; std::string er;
      CHECK(ParseAppPaths(8, (char**)av, i, ap, er)); CHECK(i == 7); CHECK(ap.Compat() == "C.db" && ap.LogFile() == "L/ps5x.log" && ap.Config() == "D/config.ini");
      const char* bv[] = {"ps5x", "--data"}; i = 1; AppPaths bp; CHECK(!ParseAppPaths(2, (char**)bv, i, bp, er)); AppPaths dp; CHECK(dp.Compat() == "ps5x_data/compat.db"); }
    // regression harness runs the real pipeline
    fs::path dir = fs::temp_directory_path() / "ps5x_regress_test"; fs::remove_all(dir); fs::create_directories(dir);
    { auto b = BuildSampleElf(); std::ofstream(dir / "sample.elf", std::ios::binary).write((const char*)b.data(), b.size()); }
    Config cfg = Config::Defaults();
    auto probe = RunRegression("probe | sample.elf | 0 | Hello | - | 1000000\n", dir.string(), cfg);
    CHECK(probe.size() == 1 && probe[0].passed); uint64_t h = probe[0].frameHash; CHECK(h != 0);
    char hex[32]; snprintf(hex, sizeof hex, "%016llx", (unsigned long long)h);
    std::string good = std::string("# comment\nsample | sample.elf | 0 | Hello from PS5X | ") + hex + " | 1000000\n";
    auto r1 = RunRegression(good, dir.string(), cfg); CHECK(r1.size() == 1 && r1[0].passed);
    CHECK(!RunRegression("w1 | sample.elf | 3 | - | - | 1000000\n", dir.string(), cfg)[0].passed);                       // wrong exit code
    CHECK(!RunRegression("w2 | sample.elf | 0 | NOPE | - | 1000000\n", dir.string(), cfg)[0].passed);                    // wrong stdout
    CHECK(!RunRegression("w3 | sample.elf | 0 | - | deadbeefdeadbeef | 1000000\n", dir.string(), cfg)[0].passed);       // wrong frame hash
    CHECK(!RunRegression("w4 | sample.elf | 0 | - | - | 5\n", dir.string(), cfg)[0].passed);                              // instruction budget exhausted
    CHECK(!RunRegression("w5 | missing.elf | 0 | - | - | 100\n", dir.string(), cfg)[0].passed);                          // load failure
    CHECK(!RunRegression("only | three | fields\n", dir.string(), cfg)[0].passed);                                       // malformed
    fs::remove_all(dir);
    printf(bad ? "compat/regress tests FAILED\n" : "compat/regress tests passed\n"); return bad;
}
