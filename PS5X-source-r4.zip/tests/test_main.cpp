// Self-contained test runner (no external framework needed). Exit code = number of failed tests.
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <functional>
#include <vector>
#include "audio/audio.h"
#include "common/log.h"
#include "common/config.h"
#include "core/emulator.h"
#include "cpu/x86_cpu.h"
#include "gpu/gpu.h"
#include "input/input.h"
#include "kernel/kernel.h"
#include "loader/elf.h"
#include "memory/guest_memory.h"
#include "storage/format.h"
#include "storage/library.h"
namespace fs = std::filesystem;
using namespace ps5x;
using Bytes = std::vector<uint8_t>;

struct TestCase { const char* name; void (*fn)(); };
static std::vector<TestCase>& Registry() { static std::vector<TestCase> r; return r; }
static int g_failedChecks = 0;
struct TestReg { TestReg(const char* n, void (*f)()) { Registry().push_back({n, f}); } };
#define TEST(n) static void n(); static TestReg reg_##n(#n, n); static void n()
#define CHECK(c) do { if (!(c)) { printf("    CHECK failed: %s  (%s:%d)\n", #c, __FILE__, __LINE__); ++g_failedChecks; } } while (0)
#define CHECK_EQ(a, b) do { unsigned long long _a = (unsigned long long)(a), _b = (unsigned long long)(b); if (_a != _b) { \
    printf("    CHECK_EQ failed: %s == %s  (0x%llx vs 0x%llx) (%s:%d)\n", #a, #b, _a, _b, __FILE__, __LINE__); ++g_failedChecks; } } while (0)

// ---------- memory ----------
TEST(memory_map_and_access) {
    GuestMemory m; std::string e;
    CHECK(m.Map(0x1000, 0x2000, PERM_R | PERM_W, "a", &e));
    uint32_t v = 0xdeadbeef, o = 0;
    CHECK(m.Write(0x1ffc, &v, 4)); CHECK(m.Read(0x1ffc, &o, 4)); CHECK_EQ(o, v);
    CHECK(!m.Read(0x2ffd, &o, 4));                       // crosses end of region
    CHECK(!m.Read(0x0ff0, &o, 4)); CHECK(m.LastFault().reason == "unmapped address");
    CHECK(!m.Read(~0ull - 1, &o, 4));                    // wraparound must not pass
}
TEST(memory_rejects_bad_maps) {
    GuestMemory m; std::string e;
    CHECK(!m.Map(0x1000, 0, PERM_R, "z", &e));
    CHECK(!m.Map(0x1001, 0x1000, PERM_R, "u", &e));
    CHECK(!m.Map(~0ull - 0xfff, 0x2000, PERM_R, "w", &e));
    CHECK(m.Map(0x4000, 0x2000, PERM_R, "a", &e));
    CHECK(!m.Map(0x5000, 0x1000, PERM_R, "overlap-inside", &e));
    CHECK(!m.Map(0x3000, 0x2000, PERM_R, "overlap-front", &e));
    CHECK(!m.Map(0x5000, 0x4000, PERM_R, "overlap-back", &e));
    CHECK(m.Map(0x6000, 0x1000, PERM_R, "adjacent", &e));
    m.SetLimit(0x4000); CHECK(!m.Map(0x100000, 0x2000, PERM_R, "limit", &e)); CHECK(e.find("limit") != std::string::npos);
}
TEST(memory_permissions) {
    GuestMemory m; m.Map(0x1000, 0x1000, PERM_R | PERM_X, "rx"); uint8_t b = 1;
    CHECK(!m.Write(0x1000, &b, 1)); CHECK(m.LastFault().reason == "permission denied");
    CHECK(m.Poke(0x1000, &b, 1));                        // loader path ignores perms
    CHECK(m.Read(0x1000, &b, 1, PERM_X));
    m.Protect(0x1000, PERM_R); CHECK(!m.Read(0x1000, &b, 1, PERM_X));
}
TEST(memory_unmap_and_findfree) {
    GuestMemory m; m.Map(0x10000000, 0x1000, PERM_R, "a"); m.Map(0x10001000, 0x1000, PERM_R, "b");
    CHECK_EQ(m.FindFree(0x1000), 0x10002000);
    CHECK(!m.Unmap(0x10000000, 0x2000)); CHECK(m.Unmap(0x10000000, 0x1000));
    CHECK_EQ(m.FindFree(0x1000), 0x10000000); CHECK_EQ(m.TotalMapped(), 0x1000);
}
TEST(memory_cstring) {
    GuestMemory m; m.Map(0x1000, 0x1000, PERM_R | PERM_W, "a"); m.Poke(0x1000, "hi", 3);
    std::string s; CHECK(m.ReadCString(0x1000, s)); CHECK(s == "hi");
    GuestMemory n; n.Map(0x1000, 0x1000, PERM_R, "a"); std::vector<uint8_t> ff(0x1000, 'x'); n.Poke(0x1000, ff.data(), 0x1000);
    CHECK(!n.ReadCString(0x1000, s));                    // runs off region end without NUL
}

// ---------- config ----------
TEST(config_roundtrip_and_types) {
    Config c; CHECK(c.ParseText("[cpu]\nmax = 0x10\nflag = yes\n# comment\n[audio]\nrate=44100\n"));
    CHECK_EQ(c.GetInt("cpu.max"), 16); CHECK(c.GetBool("cpu.flag")); CHECK_EQ(c.GetInt("audio.rate"), 44100);
    CHECK_EQ(c.GetInt("missing", 7), 7); CHECK(!c.GetBool("missing", false));
    std::string p = (fs::temp_directory_path() / "ps5x_cfg_test.ini").string(), e;
    CHECK(c.Save(p, &e)); Config d; CHECK(d.Load(p, &e)); CHECK_EQ(d.GetInt("audio.rate"), 44100); CHECK(d.Get("cpu.flag") == "yes");
    fs::remove(p);
}
TEST(config_reports_malformed_lines) {
    Config c; CHECK(!c.ParseText("[ok]\nthis is wrong\n[broken\nk=v\n"));
    CHECK_EQ(c.Errors().size(), 2); CHECK(c.Get("ok.k") == "v");
    Config d; std::string e; CHECK(!d.Load("/nonexistent/path.ini", &e)); CHECK(!e.empty());
    Config f = Config::Defaults(); CHECK(f.Has("graphics.width")); CHECK(f.Has("input.map.cross"));
}

// ---------- CPU ----------
struct Rig {
    GuestMemory mem; X86Cpu cpu{mem};
    explicit Rig(Bytes code, bool addHlt = true) {
        if (addHlt) code.push_back(0xF4);
        mem.Map(0x1000, 0x1000, PERM_R | PERM_X, "code"); mem.Poke(0x1000, code.data(), code.size());
        mem.Map(0x20000, 0x1000, PERM_R | PERM_W, "stack");
        cpu.st.rip = 0x1000; cpu.st.gpr[RSP] = 0x21000;
    }
    StopReason run(uint64_t n = 100000) { return cpu.Run(n); }
    uint64_t& r(int i) { return cpu.st.gpr[i]; }
    bool flag(uint64_t f) { return cpu.st.rflags & f; }
};
TEST(cpu_mov_add_sub) {
    Rig t({0xB8, 5, 0, 0, 0, 0x83, 0xC0, 3});                       // mov eax,5; add eax,3
    CHECK(t.run() == StopReason::Halt); CHECK_EQ(t.r(RAX), 8); CHECK(!t.flag(FLAG_ZF));
    Rig u({0xB8, 5, 0, 0, 0, 0x83, 0xE8, 5});                       // sub eax,5
    u.run(); CHECK_EQ(u.r(RAX), 0); CHECK(u.flag(FLAG_ZF)); CHECK(!u.flag(FLAG_CF));
}
TEST(cpu_loop_sum_1_to_10) {
    Rig t({0x31, 0xC0, 0xB9, 10, 0, 0, 0, 0x01, 0xC8, 0xFF, 0xC9, 0x75, 0xFA});
    CHECK(t.run() == StopReason::Halt); CHECK_EQ(t.r(RAX), 55); CHECK_EQ(t.r(RCX), 0);
    CHECK_EQ(t.cpu.instructionCount, 2 + 10 * 3);                // xor,mov, 10*(add,dec,jnz); the stopping hlt is not counted
}
TEST(cpu_call_ret_push_pop) {
    Rig t({0xE8, 1, 0, 0, 0, 0xF4, 0xB8, 42, 0, 0, 0, 0xC3}, false);
    CHECK(t.run() == StopReason::Halt); CHECK_EQ(t.r(RAX), 42); CHECK_EQ(t.r(RSP), 0x21000); CHECK_EQ(t.cpu.st.rip, 0x1006);
    Rig u({0x48, 0xB8, 0x88, 0x77, 0x66, 0x55, 0x44, 0x33, 0x22, 0x11, 0x50, 0x5B});   // movabs rax; push rax; pop rbx
    u.run(); CHECK_EQ(u.r(RBX), 0x1122334455667788ull); CHECK_EQ(u.r(RSP), 0x21000);
}
TEST(cpu_rip_relative_lea) {
    Rig t({0x48, 0x8D, 0x05, 0, 0, 0, 0}); t.run(); CHECK_EQ(t.r(RAX), 0x1007);
}
TEST(cpu_flags_carry_overflow) {
    Rig a({0xB8, 0xFF, 0xFF, 0xFF, 0x7F, 0x83, 0xC0, 1}); a.run();   // 0x7fffffff + 1
    CHECK(a.flag(FLAG_OF)); CHECK(a.flag(FLAG_SF)); CHECK(!a.flag(FLAG_CF)); CHECK_EQ(a.r(RAX), 0x80000000ull);
    Rig b({0xB8, 0xFF, 0xFF, 0xFF, 0xFF, 0x83, 0xC0, 1}); b.run();   // 0xffffffff + 1
    CHECK(b.flag(FLAG_CF)); CHECK(b.flag(FLAG_ZF)); CHECK_EQ(b.r(RAX), 0);
    Rig c({0x48, 0xC7, 0xC0, 0xFF, 0xFF, 0xFF, 0xFF, 0x48, 0x83, 0xC0, 1}); c.run();   // 64-bit -1 + 1
    CHECK(c.flag(FLAG_CF)); CHECK(c.flag(FLAG_ZF)); CHECK_EQ(c.r(RAX), 0);
}
TEST(cpu_partial_register_semantics) {
    Rig a({0x48, 0xC7, 0xC0, 0xFF, 0xFF, 0xFF, 0xFF, 0xB8, 1, 0, 0, 0}); a.run();   // 32-bit write zero-extends
    CHECK_EQ(a.r(RAX), 1);
    Rig b({0xB4, 0x12}); b.run(); CHECK_EQ(b.r(RAX), 0x1200);                        // mov ah,0x12
    Rig c({0x41, 0xB8, 5, 0, 0, 0, 0x49, 0x83, 0xC0, 3}); c.run(); CHECK_EQ(c.r(R8), 8);   // REX regs
    Rig d({0x66, 0xB8, 0x34, 0x12}); d.r(RAX) = 0xAAAA0000; d.run(); CHECK_EQ(d.r(RAX), 0xAAAA1234ull);   // 16-bit keeps upper
}
TEST(cpu_shifts_ext_mul_setcc) {
    Rig a({0xBA, 1, 0, 0, 0, 0xC1, 0xE2, 4}); a.run(); CHECK_EQ(a.r(RDX), 16);                         // shl
    Rig b({0xBE, 0xF0, 0xFF, 0xFF, 0xFF, 0xC1, 0xFE, 2}); b.run(); CHECK_EQ(b.r(RSI), 0xFFFFFFFCull);  // sar
    Rig c({0xBE, 0xF0, 0xFF, 0xFF, 0xFF, 0xC1, 0xEE, 4}); c.run(); CHECK_EQ(c.r(RSI), 0x0FFFFFFFull);  // shr
    Rig d({0xB8, 0x80, 0xFF, 0xFF, 0xFF, 0x0F, 0xBE, 0xD8, 0x0F, 0xB6, 0xC8}); d.run();                // movsx ebx,al; movzx ecx,al
    CHECK_EQ(d.r(RBX), 0xFFFFFF80ull); CHECK_EQ(d.r(RCX), 0x80);
    Rig e({0xB8, 7, 0, 0, 0, 0xBF, 6, 0, 0, 0, 0x0F, 0xAF, 0xF8}); e.run(); CHECK_EQ(e.r(RDI), 42);   // imul edi,eax
    Rig f({0xB8, 7, 0, 0, 0, 0x83, 0xF8, 7, 0x0F, 0x94, 0xC3}); f.run(); CHECK_EQ(f.r(RBX) & 0xff, 1); // sete bl
    Rig g({0xB8, 7, 0, 0, 0, 0xBB, 9, 0, 0, 0, 0x83, 0xF8, 7, 0x0F, 0x44, 0xCB}); g.run(); CHECK_EQ(g.r(RCX), 9);  // cmove ecx,ebx
}
TEST(cpu_neg_not_test) {
    Rig a({0xB8, 5, 0, 0, 0, 0xF7, 0xD8}); a.run(); CHECK_EQ(a.r(RAX), 0xFFFFFFFBull); CHECK(a.flag(FLAG_CF));
    Rig b({0xB8, 5, 0, 0, 0, 0xF7, 0xD0}); b.run(); CHECK_EQ(b.r(RAX), 0xFFFFFFFAull);
    Rig c({0xB8, 4, 0, 0, 0, 0xA9, 3, 0, 0, 0}); c.run(); CHECK(c.flag(FLAG_ZF)); CHECK_EQ(c.r(RAX), 4);  // test eax,3
}
TEST(cpu_memory_operands) {
    // mov dword [rsp-8], 0x1234 ; mov ebx, [rsp-8]
    Rig a({0xC7, 0x44, 0x24, 0xF8, 0x34, 0x12, 0, 0, 0x8B, 0x5C, 0x24, 0xF8}); CHECK(a.run() == StopReason::Halt); CHECK_EQ(a.r(RBX), 0x1234);
}
TEST(cpu_faults_are_reported_not_ignored) {
    Rig a({0xC7, 0x05, 0, 0, 0, 0, 1, 0, 0, 0}, false);   // write into RX code page
    CHECK(a.run() == StopReason::MemoryFault); CHECK_EQ(a.cpu.st.rip, 0x1000); CHECK(!a.cpu.lastError.empty());
    Rig b({0x8B, 0x04, 0x25, 0, 0, 0, 0x09}, false);      // mov eax,[0x9000000]
    CHECK(b.run() == StopReason::MemoryFault); CHECK_EQ(b.cpu.faultAddr, 0x9000000);
    Rig c({0x06}, false);                                 // invalid in 64-bit mode
    CHECK(c.run() == StopReason::UndefinedOpcode); CHECK_EQ(c.cpu.st.rip, 0x1000);
    Rig d({0xF3, 0x0F, 0x10, 0xC0}, false);               // SSE: unsupported -> must stop loudly
    CHECK(d.run() == StopReason::UndefinedOpcode);
    GuestMemory m; X86Cpu cpu(m); cpu.st.rip = 0x5000;    // fetch from unmapped memory
    CHECK(cpu.Run(10) == StopReason::MemoryFault);
}
TEST(cpu_syscall_halt_limit) {
    Rig a({0x0F, 0x05}); CHECK(a.run() == StopReason::Syscall); CHECK_EQ(a.r(RCX), 0x1002);
    Rig b({0xEB, 0xFE}); CHECK(b.run(100) == StopReason::StepLimit); CHECK_EQ(b.cpu.instructionCount, 100);
    Rig c({0xCC}, false); CHECK(c.run() == StopReason::Breakpoint);
}

// ---------- loader ----------
TEST(elf_parses_sample) {
    Bytes f = BuildSampleElf(); ElfInfo i; std::string e;
    CHECK(ParseElf(f, i, e)); CHECK_EQ(i.entry, 0x400000 + 120); CHECK_EQ(i.loads.size(), 1);
    GuestMemory m; LoadedImage img; CHECK(LoadElf(m, f, img, e));
    CHECK(m.Regions().begin()->second.perm == (PERM_R | PERM_X));
    uint8_t b = 0; CHECK(m.Read(img.entry, &b, 1, PERM_X)); CHECK_EQ(b, 0xB8);
}
TEST(elf_rejects_malformed) {
    Bytes good = BuildSampleElf(); ElfInfo i; std::string e;
    auto bad = [&](const char* what, std::function<void(Bytes&)> mut, const char* expect) {
        Bytes f = good; mut(f); bool ok = ParseElf(f, i, e);
        if (ok || e.find(expect) == std::string::npos) { printf("    case '%s': ok=%d err='%s'\n", what, ok, e.c_str()); ++g_failedChecks; } };
    bad("truncated", [](Bytes& f) { f.resize(30); }, "too small");
    bad("magic", [](Bytes& f) { f[1] = 'X'; }, "magic");
    bad("32-bit", [](Bytes& f) { f[4] = 1; }, "64-bit");
    bad("machine", [](Bytes& f) { f[18] = 183; }, "x86-64");
    bad("type", [](Bytes& f) { f[16] = 1; }, "EXEC");
    bad("filesz>memsz", [](Bytes& f) { f[64 + 40] = 1; f[64 + 41] = 0; f[64 + 32] = 0xFF; }, "filesz");
    bad("segment outside file", [](Bytes& f) { f[64 + 8] = 0x80; f[64 + 9] = 0x0f; }, "outside");
    bad("entry not in segment", [](Bytes& f) { f[24] = 0; f[25] = 0; f[26] = 0x50; }, "entry");
    bad("null page", [](Bytes& f) { for (int k = 0; k < 8; ++k) f[64 + 16 + k] = 0; f[64 + 24] = 0; }, "");   // vaddr 0 -> rejected somewhere
}
TEST(elf_load_conflict_detected) {
    Bytes f = BuildSampleElf(); GuestMemory m; std::string e; m.Map(0x400000, 0x1000, PERM_R, "squatter");
    LoadedImage img; CHECK(!LoadElf(m, f, img, e)); CHECK(e.find("overlaps") != std::string::npos);
}

// ---------- format / library ----------
TEST(format_identification) {
    auto id = [](Bytes b) { return IdentifyBuffer(b, b.size()); };
    CHECK(id({0x4f, 0x15, 0x3d, 0x1d, 0, 0, 0, 0}).format == FileFormat::SelfPS4);
    FormatInfo s5 = id({0x54, 0x14, 0xf5, 0xee, 0, 0, 0, 0}); CHECK(s5.format == FileFormat::SelfPS5); CHECK(s5.compat == CompatStatus::Unsupported);
    CHECK(id({0x7f, 'C', 'N', 'T', 0}).format == FileFormat::Pkg);
    CHECK(id({1, 2, 3, 4}).compat == CompatStatus::Invalid);
    CHECK(IdentifyBuffer({}, 0).compat == CompatStatus::Invalid);
    Bytes s = BuildSampleElf(); FormatInfo e = IdentifyBuffer(s, s.size());
    CHECK(e.format == FileFormat::ElfX64); CHECK(e.compat == CompatStatus::LoadsOnly);
    s[18] = 183; CHECK(IdentifyBuffer(s, s.size()).compat == CompatStatus::Invalid);
    CHECK(std::string(CompatName(CompatStatus::LoadsOnly)).find("not playable") != std::string::npos);
}
TEST(storage_directory_and_library) {
    fs::path root = fs::temp_directory_path() / "ps5x_lib_test"; fs::remove_all(root);
    fs::create_directories(root / "GameA" / "sce_sys"); fs::create_directories(root / "Loose");
    { std::ofstream(root / "GameA" / "eboot.bin", std::ios::binary).write("\x54\x14\xf5\xee\0\0\0\0", 8); }
    { std::ofstream(root / "GameA" / "sce_sys" / "param.json") << "{\"titleId\": \"PPSA00000\", \"x\":1, \"titleName\" : \"Test Title\"}"; }
    { Bytes s = BuildSampleElf(); std::ofstream(root / "Loose" / "demo.elf", std::ios::binary).write((const char*)s.data(), s.size()); }
    FormatInfo d = IdentifyPath((root / "GameA").string());
    CHECK(d.title == "Test Title"); CHECK(d.titleId == "PPSA00000"); CHECK(d.compat == CompatStatus::Unsupported);
    GameLibrary lib; int n = lib.Scan(root.string()); CHECK_EQ(n, 2); CHECK_EQ(lib.Scan(root.string()), 0);   // dedupe
    std::string p = (root / "lib.txt").string(); CHECK(lib.Save(p)); GameLibrary l2; CHECK(l2.Load(p)); CHECK_EQ(l2.Entries().size(), 2);
    CHECK(lib.Remove((root / "Loose" / "demo.elf").string())); CHECK_EQ(lib.Entries().size(), 1);
    CHECK(IdentifyPath((root / "nope").string()).format == FileFormat::Missing);
    CHECK(IdentifyPath((root / "Loose").string()).compat == CompatStatus::Invalid);   // dir without eboot.bin
    fs::remove_all(root);
}

// ---------- kernel ----------
struct KRig {
    GuestMemory mem; X86Cpu cpu{mem}; AudioRing ring{1024}; Kernel k;
    KRig() : k(mem, cpu, KernelServices{nullptr, &ring, nullptr}) { mem.Map(0x1000, 0x1000, PERM_R | PERM_W, "data"); }
    void call(uint64_t n, uint64_t a0 = 0, uint64_t a1 = 0, uint64_t a2 = 0, uint64_t a3 = 0) {
        cpu.st.gpr[RAX] = n; cpu.st.gpr[RDI] = a0; cpu.st.gpr[RSI] = a1; cpu.st.gpr[RDX] = a2; cpu.st.gpr[R10] = a3; k.Dispatch(); }
    bool err() { return cpu.st.rflags & FLAG_CF; }
};
TEST(kernel_write_exit_getpid) {
    KRig t; t.mem.Poke(0x1000, "abc", 3);
    t.call(4, 1, 0x1000, 3); CHECK(!t.err()); CHECK_EQ(t.cpu.st.gpr[RAX], 3); CHECK(t.k.stdoutBuf == "abc");
    t.call(4, 2, 0x1000, 2); CHECK(t.k.stderrBuf == "ab");
    t.call(4, 9, 0x1000, 1); CHECK(t.err()); CHECK_EQ(t.cpu.st.gpr[RAX], 9);            // EBADF
    t.call(4, 1, 0x9000, 1); CHECK(t.err()); CHECK_EQ(t.cpu.st.gpr[RAX], 14);           // EFAULT
    t.call(20); CHECK_EQ(t.cpu.st.gpr[RAX], 1000);
    t.call(1, 7); CHECK(t.k.exited); CHECK_EQ(t.k.exitCode, 7);
}
TEST(kernel_unimplemented_is_reported) {
    KRig t; t.call(9999); CHECK(t.err()); CHECK_EQ(t.cpu.st.gpr[RAX], 78); t.call(9999); CHECK_EQ(t.k.unimplemented[9999], 2);
    t.call(0x1000); CHECK(t.err());   // gpu service absent -> ENOSYS, no crash
}
TEST(kernel_mmap_munmap) {
    KRig t; t.cpu.st.gpr[R8] = 0; t.cpu.st.gpr[RAX] = 477; t.cpu.st.gpr[RDI] = 0; t.cpu.st.gpr[RSI] = 5000; t.cpu.st.gpr[RDX] = 3; t.cpu.st.gpr[R10] = 0x1000;
    t.k.Dispatch(); CHECK(!t.err()); uint64_t a = t.cpu.st.gpr[RAX]; CHECK(a != 0 && a % 0x1000 == 0);
    uint32_t v = 77; CHECK(t.mem.Write(a + 4000, &v, 4));
    t.call(73, a, 5000); CHECK(!t.err()); CHECK(!t.mem.Read(a, &v, 4));
    t.cpu.st.gpr[R10] = 0; t.cpu.st.gpr[RAX] = 477; t.cpu.st.gpr[RSI] = 4096; t.k.Dispatch(); CHECK(t.err());   // file mappings unsupported
}
TEST(kernel_audio_syscall) {
    KRig t; int16_t s[4] = {1, 2, 3, 4}; t.mem.Poke(0x1000, s, 8);
    t.call(0x1003, 0x1000, 4); CHECK_EQ(t.cpu.st.gpr[RAX], 4); CHECK_EQ(t.ring.Size(), 4);
}

// ---------- gpu / audio / input ----------
TEST(gpu_software_rendering) {
    auto g = CreateSoftwareGpu(); std::string e; CHECK(!g->Init(0, 10, &e)); CHECK(g->Init(8, 4, &e));
    GpuCommand c{GpuCmdType::Clear}; c.color = 0xFF112233; g->Execute(c); CHECK_EQ(g->Framebuffer()[0], 0xFF112233);
    GpuCommand r{GpuCmdType::FillRect}; r.x = -2; r.y = 1; r.w = 4; r.h = 100; r.color = 0xFFABCDEF; g->Execute(r);   // clipped
    CHECK_EQ(g->Framebuffer()[1 * 8 + 0], 0xFFABCDEF); CHECK_EQ(g->Framebuffer()[1 * 8 + 1], 0xFFABCDEF);
    CHECK_EQ(g->Framebuffer()[1 * 8 + 2], 0xFF112233); CHECK_EQ(g->Framebuffer()[0], 0xFF112233); CHECK_EQ(g->Framebuffer()[3 * 8 + 1], 0xFFABCDEF);
    GpuCommand p{GpuCmdType::Present}; g->Execute(p); CHECK_EQ(g->frames, 1);
    std::string path = (fs::temp_directory_path() / "ps5x_t.ppm").string(); CHECK(WritePPM(*g, path, &e));
    CHECK_EQ(fs::file_size(path), std::string("P6\n8 4\n255\n").size() + 8 * 4 * 3); fs::remove(path);
    std::string rep; ProbeVulkan(rep); CHECK(!rep.empty());
}
TEST(audio_ring_and_wav) {
    AudioRing r(8); int16_t in[6] = {1, 2, 3, 4, 5, 6}, out[8] = {};
    CHECK_EQ(r.Push(in, 6), 6); CHECK_EQ(r.Push(in, 6), 2);       // capacity limit honoured
    CHECK_EQ(r.Pop(out, 4), 4); CHECK_EQ(out[3], 4); CHECK_EQ(r.Push(in, 4), 4);   // wraps
    CHECK_EQ(r.Pop(out, 8), 8); CHECK_EQ(out[0], 5); CHECK_EQ(out[6], 3);   // ring holds 5 6 1 2 1 2 3 4
    std::string path = (fs::temp_directory_path() / "ps5x_t.wav").string(), e;
    auto w = CreateAudioBackend("wav", path); CHECK(w->Open(48000, 2, &e));
    std::vector<int16_t> sine(480 * 2); double ph = 0; GenerateSine(sine.data(), 480, 2, 48000, 440, ph);
    int peak = 0; for (auto v : sine) peak = std::max(peak, (int)std::abs(v)); CHECK(peak > 10000 && peak <= 12000);
    w->Write(sine.data(), sine.size()); w->Close();
    std::ifstream f(path, std::ios::binary); char h[44]; f.read(h, 44);
    CHECK(!memcmp(h, "RIFF", 4) && !memcmp(h + 8, "WAVEfmt ", 8) && !memcmp(h + 36, "data", 4));
    uint32_t rate, dataLen; memcpy(&rate, h + 24, 4); memcpy(&dataLen, h + 40, 4); CHECK_EQ(rate, 48000); CHECK_EQ(dataLen, 480 * 2 * 2);
    CHECK_EQ(fs::file_size(path), 44 + 480 * 2 * 2); fs::remove(path);
    CHECK(CreateAudioBackend("bogus", "") == nullptr); CHECK(CreateAudioBackend("null", "") != nullptr);
}
TEST(input_mapping) {
    InputManager in; Config c = Config::Defaults(); std::vector<std::string> errs;
    CHECK(in.LoadMapping(c, &errs)); in.KeyEvent("Z", true); CHECK(in.State().buttons & BTN_CROSS);
    in.KeyEvent("Up", true); CHECK_EQ(in.State().buttons, BTN_CROSS | BTN_UP);
    in.KeyEvent("Z", false); CHECK_EQ(in.State().buttons, BTN_UP); in.KeyEvent("Q", true); CHECK_EQ(in.State().buttons, BTN_UP);
    c.Set("input.map.turbo", "T"); c.Set("input.map.l1", ""); errs.clear(); CHECK(!in.LoadMapping(c, &errs)); CHECK_EQ(errs.size(), 2);
    CHECK(!in.ListDevices().empty()); CHECK(!in.PollGamepad() || true);
}

// ---------- end to end ----------
TEST(e2e_sample_program_runs_through_pipeline) {
    Config c = Config::Defaults(); c.Set("graphics.width", "64"); c.Set("graphics.height", "32");
    Emulator emu(c); std::string e; CHECK(emu.LoadBuffer(BuildSampleElf(), e)); CHECK(e.empty());
    RunReport r = emu.Run();
    CHECK(r.started); CHECK(r.exited); CHECK_EQ(r.exitCode, 0); CHECK(r.error.empty());
    CHECK(r.stdoutText == "Hello from PS5X guest code\n"); CHECK_EQ(r.frames, 1); CHECK_EQ(r.syscalls, 8);
    const auto& fb = emu.gpu->Framebuffer();
    for (int rect = 0; rect < 4; ++rect) {
        CHECK_EQ(fb[10 * 64 + rect * 16], 0xFF00FF00); CHECK_EQ(fb[10 * 64 + rect * 16 + 11], 0xFF00FF00);
        CHECK_EQ(fb[10 * 64 + rect * 16 + 12], 0xFF202020); CHECK_EQ(fb[7 * 64 + rect * 16], 0xFF202020); CHECK_EQ(fb[20 * 64 + rect * 16], 0xFF202020);
    }
    CHECK(!emu.LoadBuffer(BuildSampleElf(), e));   // double-load refused
}
TEST(e2e_reports_guest_failures) {
    Config c = Config::Defaults(); c.Set("graphics.width", "16"); c.Set("graphics.height", "16");
    Bytes elf = BuildSampleElf(); elf[120] = 0x06;                 // corrupt first instruction
    Emulator emu(c); std::string e; CHECK(emu.LoadBuffer(elf, e));
    RunReport r = emu.Run(); CHECK(!r.exited); CHECK(r.reason == StopReason::UndefinedOpcode); CHECK(!r.error.empty());
    Emulator e2(c); CHECK(e2.LoadBuffer(BuildSampleElf(), e)); RunReport r2 = e2.Run(5); CHECK(r2.reason == StopReason::StepLimit);
    Emulator e3(c); CHECK(!e3.Run().started);
    Emulator e4(c); Bytes junk(64, 0); CHECK(!e4.LoadBuffer(junk, e)); CHECK(!e.empty());
}
TEST(e2e_loadfile_refuses_unsupported_formats) {
    fs::path p = fs::temp_directory_path() / "ps5x_fake.self";
    { std::ofstream(p, std::ios::binary).write("\x54\x14\xf5\xee\0\0\0\0", 8); }
    Emulator emu(Config::Defaults()); std::string e; CHECK(!emu.LoadFile(p.string(), e)); CHECK(e.find("decrypt") != std::string::npos);
    fs::remove(p);
}

int main(int argc, char** argv) {
    Logger::Get().SetConsole(false);
    const char* filter = argc > 1 ? argv[1] : nullptr; int failed = 0, ran = 0;
    for (auto& t : Registry()) {
        if (filter && !strstr(t.name, filter)) continue;
        int before = g_failedChecks; t.fn(); ++ran;
        bool ok = g_failedChecks == before; failed += !ok; printf("[%s] %s\n", ok ? " OK " : "FAIL", t.name);
    }
    printf("\n%d test(s) run, %d failed\n", ran, failed);
    return failed;
}
