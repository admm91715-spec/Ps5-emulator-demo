#include <cstdio>
#include <filesystem>
#include <fstream>
#include "preflight/preflight.h"
namespace fs = std::filesystem; using namespace ps5x;
static int bad = 0;
#define CHECK(c) do { if (!(c)) { printf("CHECK failed: %s (line %d)\n", #c, __LINE__); ++bad; } } while (0)
static const Check* Find(const std::vector<Check>& v, const char* n) { for (auto& c : v) if (c.name == n) return &c; return nullptr; }
int main() {
    fs::path root = fs::temp_directory_path() / "ps5x_pf_test"; fs::remove_all(root); fs::create_directories(root / "g" / "sce_sys"); fs::create_directories(root / "empty");
    { std::ofstream(root / "g" / "eboot.bin", std::ios::binary).write("\x54\x14\xf5\xee\0\0\0\0", 8); }
    { std::ofstream(root / "g" / "sce_sys" / "param.json") << "{\"titleId\":\"PPSA01341\",\"titleName\":\"X\"}"; }
    auto ok = CheckGamePath((root / "g").string());
    CHECK(!HasFailure(ok)); CHECK(Find(ok, "param.json") && Find(ok, "param.json")->detail.find("PPSA01341") != std::string::npos);
    CHECK(Find(ok, "eboot.bin format")->detail.find("does not decrypt") != std::string::npos);
    auto bad1 = CheckGamePath((root / "empty").string()); CHECK(HasFailure(bad1)); CHECK(Find(bad1, "eboot.bin")->status == CheckStatus::Fail);
    CHECK(HasFailure(CheckGamePath((root / "missing").string())));
    { std::ofstream(root / "a.zar") << "x"; } CHECK(!HasFailure(CheckGamePath((root / "a.zar").string())));
    { std::ofstream(root / "a.bin") << "x"; } CHECK(HasFailure(CheckGamePath((root / "a.bin").string())));
    fs::create_directories(root / "we[ird]"); CHECK(Find(CheckGamePath((root / "we[ird]").string()), "Path characters") != nullptr);
    auto h = CheckHost(); CHECK(!h.empty()); CHECK(Find(h, "Vulkan 1.3 GPU/driver") != nullptr);
    fs::remove_all(root); printf(bad ? "preflight tests FAILED\n" : "preflight tests passed (6 groups)\n"); return bad;
}
