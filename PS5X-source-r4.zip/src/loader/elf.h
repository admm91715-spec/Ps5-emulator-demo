#pragma once
#include <cstdint>
#include <string>
#include <vector>
#include "memory/guest_memory.h"
namespace ps5x {
struct ElfSegment { uint64_t vaddr = 0, memsz = 0, filesz = 0, offset = 0; uint32_t flags = 0; };
struct ElfInfo {
    uint16_t type = 0, machine = 0;
    uint64_t entry = 0;
    std::vector<ElfSegment> loads;
    bool hasDynamic = false, hasInterp = false;
    std::vector<std::string> warnings;
};
constexpr uint64_t kDynBase = 0x400000;
// Validate and parse a plain ELF64 x86-64 image. Returns false and fills err on malformed input.
bool ParseElf(const std::vector<uint8_t>& file, ElfInfo& out, std::string& err);
struct LoadedImage { uint64_t entry = 0, base = 0; std::vector<std::string> warnings; };
// Map PT_LOAD segments into guest memory. No relocation processing, no dynamic linking.
bool LoadElf(GuestMemory& mem, const std::vector<uint8_t>& file, LoadedImage& out, std::string& err);
}
