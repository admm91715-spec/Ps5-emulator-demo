#include "loader/elf.h"
#include <cstring>
namespace ps5x {
#pragma pack(push, 1)
struct Ehdr { uint8_t ident[16]; uint16_t type, machine; uint32_t version; uint64_t entry, phoff, shoff; uint32_t flags;
              uint16_t ehsize, phentsize, phnum, shentsize, shnum, shstrndx; };
struct Phdr { uint32_t type, flags; uint64_t offset, vaddr, paddr, filesz, memsz, align; };
#pragma pack(pop)
static_assert(sizeof(Ehdr) == 64 && sizeof(Phdr) == 56, "ELF struct layout");
static const uint32_t PT_LOAD = 1, PT_DYNAMIC = 2, PT_INTERP = 3;

bool ParseElf(const std::vector<uint8_t>& f, ElfInfo& out, std::string& err) {
    out = ElfInfo();
    if (f.size() < sizeof(Ehdr)) { err = "file too small for an ELF header"; return false; }
    Ehdr h; memcpy(&h, f.data(), sizeof h);
    if (memcmp(h.ident, "\x7f""ELF", 4) != 0) { err = "not an ELF file (bad magic)"; return false; }
    if (h.ident[4] != 2) { err = "not a 64-bit ELF"; return false; }
    if (h.ident[5] != 1) { err = "not little-endian"; return false; }
    if (h.machine != 62) { err = "ELF machine is not x86-64 (e_machine=" + std::to_string(h.machine) + ")"; return false; }
    if (h.type != 2 && h.type != 3) { err = "ELF type is neither EXEC nor DYN (e_type=" + std::to_string(h.type) + ")"; return false; }
    if (h.phentsize != sizeof(Phdr)) { err = "unexpected program header entry size"; return false; }
    if (h.phnum == 0 || h.phnum > 128) { err = "program header count out of range"; return false; }
    if (h.phoff > f.size() || (uint64_t)h.phnum * sizeof(Phdr) > f.size() - h.phoff) { err = "program headers lie outside the file"; return false; }
    out.type = h.type; out.machine = h.machine;
    const uint64_t bias = h.type == 3 ? kDynBase : 0;
    out.entry = h.entry + bias;
    for (unsigned i = 0; i < h.phnum; ++i) {
        Phdr p; memcpy(&p, f.data() + h.phoff + i * sizeof(Phdr), sizeof p);
        if (p.type == PT_DYNAMIC) out.hasDynamic = true;
        if (p.type == PT_INTERP) out.hasInterp = true;
        if (p.type != PT_LOAD) continue;
        if (p.memsz == 0) continue;
        if (p.filesz > p.memsz) { err = "PT_LOAD " + std::to_string(i) + ": filesz > memsz"; return false; }
        if (p.offset > f.size() || p.filesz > f.size() - p.offset) { err = "PT_LOAD " + std::to_string(i) + ": file data outside file"; return false; }
        if (p.vaddr + bias < p.vaddr || p.vaddr + bias + p.memsz < p.vaddr + bias) { err = "PT_LOAD " + std::to_string(i) + ": address overflow"; return false; }
        if (p.vaddr + bias == 0 || p.vaddr + bias < 0x10000) { err = "PT_LOAD " + std::to_string(i) + ": maps the null page region"; return false; }
        ElfSegment s; s.vaddr = p.vaddr + bias; s.memsz = p.memsz; s.filesz = p.filesz; s.offset = p.offset; s.flags = p.flags;
        out.loads.push_back(s);
    }
    if (out.loads.empty()) { err = "no loadable segments"; return false; }
    bool entryOk = false;
    for (auto& s : out.loads) if (out.entry >= s.vaddr && out.entry < s.vaddr + s.memsz && (s.flags & 1)) entryOk = true;
    if (!entryOk) { err = "entry point is not inside an executable segment"; return false; }
    if (out.hasInterp) out.warnings.push_back("PT_INTERP present: dynamic linking is not supported");
    if (out.hasDynamic) out.warnings.push_back("PT_DYNAMIC present: relocations are NOT applied, imports unresolved");
    return true;
}

bool LoadElf(GuestMemory& mem, const std::vector<uint8_t>& file, LoadedImage& out, std::string& err) {
    ElfInfo info;
    if (!ParseElf(file, info, err)) return false;
    out = LoadedImage(); out.entry = info.entry; out.warnings = info.warnings;
    out.base = info.type == 3 ? kDynBase : 0;
    for (size_t i = 0; i < info.loads.size(); ++i) {
        const ElfSegment& s = info.loads[i];
        uint64_t base = s.vaddr & ~(kPageSize - 1);
        uint64_t end = (s.vaddr + s.memsz + kPageSize - 1) & ~(kPageSize - 1);
        uint8_t perm = ((s.flags & 4) ? PERM_R : 0) | ((s.flags & 2) ? PERM_W : 0) | ((s.flags & 1) ? PERM_X : 0);
        std::string e;
        if (!mem.Map(base, end - base, perm, "seg" + std::to_string(i), &e)) { err = "cannot map segment " + std::to_string(i) + ": " + e; return false; }
        if (s.filesz && !mem.Poke(s.vaddr, file.data() + s.offset, s.filesz)) { err = "failed to copy segment " + std::to_string(i); return false; }
    }
    return true;
}
}
