#pragma once
#include <cstdint>
#include <map>
#include <string>
#include <vector>
namespace ps5x {
enum Perm : uint8_t { PERM_NONE = 0, PERM_R = 1, PERM_W = 2, PERM_X = 4 };
constexpr uint64_t kPageSize = 0x1000;

struct MemFault { uint64_t addr = 0; uint8_t need = 0; std::string reason; };

// Flat guest address space made of non-overlapping page-aligned regions.
// An access must lie entirely inside ONE region (cross-region accesses fault).
// Backing store is host memory (std::vector); no host page-table tricks yet.
class GuestMemory {
public:
    struct Region { uint64_t base = 0, size = 0; uint8_t perm = 0; std::string name; std::vector<uint8_t> data; };

    void SetLimit(uint64_t bytes) { limit_ = bytes; }
    bool Map(uint64_t base, uint64_t size, uint8_t perm, const std::string& name, std::string* err = nullptr);
    bool Unmap(uint64_t base, uint64_t size);          // must match a region exactly
    bool Protect(uint64_t base, uint8_t perm);          // by region base
    uint64_t FindFree(uint64_t size, uint64_t hint = 0x10000000ull) const;  // 0 if none

    bool Read(uint64_t addr, void* dst, size_t n, uint8_t need = PERM_R);
    bool Write(uint64_t addr, const void* src, size_t n);
    bool Poke(uint64_t addr, const void* src, size_t n);  // loader use: ignores permissions
    bool ReadCString(uint64_t addr, std::string& out, size_t maxLen = 4096);

    const MemFault& LastFault() const { return fault_; }
    uint64_t TotalMapped() const { return total_; }
    const std::map<uint64_t, Region>& Regions() const { return regions_; }
    std::string DumpMap() const;
private:
    Region* Find(uint64_t addr, size_t n);
    bool Fail(uint64_t addr, uint8_t need, const char* why);
    std::map<uint64_t, Region> regions_;
    uint64_t total_ = 0, limit_ = 1ull << 30;
    MemFault fault_;
};
}
