#include "memory/guest_memory.h"
#include <cstdio>
#include <cstring>
namespace ps5x {
bool GuestMemory::Fail(uint64_t addr, uint8_t need, const char* why) {
    fault_.addr = addr; fault_.need = need; fault_.reason = why; return false;
}
bool GuestMemory::Map(uint64_t base, uint64_t size, uint8_t perm, const std::string& name, std::string* err) {
    auto bad = [&](const std::string& m) { if (err) *err = m; return false; };
    if (size == 0) return bad("zero-sized mapping");
    if (base % kPageSize || size % kPageSize) return bad("mapping not page aligned");
    if (base + size < base) return bad("mapping wraps address space");
    if (total_ + size > limit_) return bad("guest memory limit exceeded");
    auto next = regions_.lower_bound(base);
    if (next != regions_.end() && next->first < base + size) return bad("overlaps region '" + next->second.name + "'");
    if (next != regions_.begin()) {
        auto prev = std::prev(next);
        if (prev->second.base + prev->second.size > base) return bad("overlaps region '" + prev->second.name + "'");
    }
    Region r; r.base = base; r.size = size; r.perm = perm; r.name = name;
    r.data.assign(size, 0);
    regions_[base] = std::move(r);
    total_ += size;
    return true;
}
bool GuestMemory::Unmap(uint64_t base, uint64_t size) {
    auto it = regions_.find(base);
    if (it == regions_.end() || it->second.size != size) return false;
    total_ -= size; regions_.erase(it); return true;
}
bool GuestMemory::Protect(uint64_t base, uint8_t perm) {
    auto it = regions_.find(base);
    if (it == regions_.end()) return false;
    it->second.perm = perm; return true;
}
uint64_t GuestMemory::FindFree(uint64_t size, uint64_t hint) const {
    uint64_t cand = (hint + kPageSize - 1) & ~(kPageSize - 1);
    for (auto& kv : regions_) {
        const Region& r = kv.second;
        if (r.base + r.size <= cand) continue;
        if (r.base >= cand + size) break;
        cand = r.base + r.size;
    }
    return cand + size < cand ? 0 : cand;
}
GuestMemory::Region* GuestMemory::Find(uint64_t addr, size_t n) {
    auto it = regions_.upper_bound(addr);
    if (it == regions_.begin()) return nullptr;
    --it;
    Region& r = it->second;
    uint64_t off = addr - r.base;
    if (off >= r.size || n > r.size - off) return nullptr;
    return &r;
}
bool GuestMemory::Read(uint64_t addr, void* dst, size_t n, uint8_t need) {
    Region* r = Find(addr, n);
    if (!r) return Fail(addr, need, "unmapped address");
    if (!(r->perm & need)) return Fail(addr, need, "permission denied");
    memcpy(dst, r->data.data() + (addr - r->base), n); return true;
}
bool GuestMemory::Write(uint64_t addr, const void* src, size_t n) {
    Region* r = Find(addr, n);
    if (!r) return Fail(addr, PERM_W, "unmapped address");
    if (!(r->perm & PERM_W)) return Fail(addr, PERM_W, "permission denied");
    memcpy(r->data.data() + (addr - r->base), src, n); return true;
}
bool GuestMemory::Poke(uint64_t addr, const void* src, size_t n) {
    Region* r = Find(addr, n);
    if (!r) return Fail(addr, PERM_W, "unmapped address");
    memcpy(r->data.data() + (addr - r->base), src, n); return true;
}
bool GuestMemory::ReadCString(uint64_t addr, std::string& out, size_t maxLen) {
    out.clear();
    for (size_t i = 0; i < maxLen; ++i) {
        char c; if (!Read(addr + i, &c, 1)) return false;
        if (!c) return true;
        out.push_back(c);
    }
    return Fail(addr, PERM_R, "string too long");
}
std::string GuestMemory::DumpMap() const {
    std::string s; char b[160];
    for (auto& kv : regions_) {
        const Region& r = kv.second;
        snprintf(b, sizeof b, "%016llx-%016llx %c%c%c %s\n", (unsigned long long)r.base,
                 (unsigned long long)(r.base + r.size), (r.perm & 1) ? 'r' : '-', (r.perm & 2) ? 'w' : '-',
                 (r.perm & 4) ? 'x' : '-', r.name.c_str());
        s += b;
    }
    return s;
}
}
