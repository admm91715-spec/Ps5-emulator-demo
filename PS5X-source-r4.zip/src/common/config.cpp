#include "common/config.h"
#include <cstdlib>
#include <fstream>
#include <sstream>
namespace ps5x {
std::string Trim(const std::string& s) {
    size_t a = s.find_first_not_of(" \t\r\n"), b = s.find_last_not_of(" \t\r\n");
    return a == std::string::npos ? "" : s.substr(a, b - a + 1);
}
Config Config::Defaults() {
    Config c;
    c.Set("cpu.max_instructions", "2000000000");
    c.Set("cpu.trace", "false");
    c.Set("memory.max_mb", "1024");
    c.Set("graphics.backend", "software");
    c.Set("graphics.width", "1280");
    c.Set("graphics.height", "720");
    c.Set("audio.backend", "wav");
    c.Set("audio.sample_rate", "48000");
    c.Set("audio.channels", "2");
    c.Set("input.map.cross", "Z");
    c.Set("input.map.circle", "X");
    c.Set("input.map.square", "A");
    c.Set("input.map.triangle", "S");
    c.Set("input.map.up", "Up");
    c.Set("input.map.down", "Down");
    c.Set("input.map.left", "Left");
    c.Set("input.map.right", "Right");
    c.Set("input.map.options", "Return");
    c.Set("paths.data", "ps5x_data");
    c.Set("log.level", "info");
    return c;
}
bool Config::ParseText(const std::string& text) {
    std::istringstream in(text);
    std::string line, section;
    int n = 0;
    bool ok = true;
    while (std::getline(in, line)) {
        ++n;
        line = Trim(line);
        if (line.empty() || line[0] == '#' || line[0] == ';') continue;
        if (line[0] == '[') {
            if (line.back() != ']' || line.size() < 3) {
                errors_.push_back("line " + std::to_string(n) + ": malformed section header");
                ok = false; continue;
            }
            section = Trim(line.substr(1, line.size() - 2));
            continue;
        }
        size_t eq = line.find('=');
        if (eq == std::string::npos || eq == 0) {
            errors_.push_back("line " + std::to_string(n) + ": expected key = value");
            ok = false; continue;
        }
        std::string k = Trim(line.substr(0, eq)), v = Trim(line.substr(eq + 1));
        values_[section.empty() ? k : section + "." + k] = v;
    }
    return ok;
}
bool Config::Load(const std::string& path, std::string* err) {
    std::ifstream f(path);
    if (!f) { if (err) *err = "cannot open " + path; return false; }
    std::stringstream ss; ss << f.rdbuf();
    bool ok = ParseText(ss.str());
    if (!ok && err) { *err = path + ": " + errors_.front(); }
    return ok;
}
bool Config::Save(const std::string& path, std::string* err) const {
    std::ofstream f(path, std::ios::trunc);
    if (!f) { if (err) *err = "cannot write " + path; return false; }
    std::string cur;
    for (auto& kv : values_) {
        size_t dot = kv.first.find('.');
        std::string sec = dot == std::string::npos ? "" : kv.first.substr(0, dot);
        std::string key = dot == std::string::npos ? kv.first : kv.first.substr(dot + 1);
        if (sec != cur) { f << "\n[" << sec << "]\n"; cur = sec; }
        f << key << " = " << kv.second << "\n";
    }
    return (bool)f;
}
std::string Config::Get(const std::string& k, const std::string& d) const {
    auto it = values_.find(k); return it == values_.end() ? d : it->second;
}
int64_t Config::GetInt(const std::string& k, int64_t d) const {
    auto it = values_.find(k);
    if (it == values_.end()) return d;
    char* end = nullptr;
    long long v = strtoll(it->second.c_str(), &end, 0);
    return (end && *end == 0 && end != it->second.c_str()) ? v : d;
}
bool Config::GetBool(const std::string& k, bool d) const {
    auto it = values_.find(k);
    if (it == values_.end()) return d;
    const std::string& s = it->second;
    if (s == "1" || s == "true" || s == "yes" || s == "on") return true;
    if (s == "0" || s == "false" || s == "no" || s == "off") return false;
    return d;
}
}
