#pragma once
#include <cstdint>
#include <map>
#include <string>
#include <vector>
namespace ps5x {
// INI-style config: [section] / key = value. Flat keys are "section.key".
// Malformed lines are NOT ignored silently: they are collected in Errors().
class Config {
public:
    static Config Defaults();
    bool Load(const std::string& path, std::string* err = nullptr);
    bool Save(const std::string& path, std::string* err = nullptr) const;
    bool ParseText(const std::string& text);
    std::string Get(const std::string& key, const std::string& def = "") const;
    int64_t GetInt(const std::string& key, int64_t def = 0) const;
    bool GetBool(const std::string& key, bool def = false) const;
    void Set(const std::string& key, const std::string& value) { values_[key] = value; }
    bool Has(const std::string& key) const { return values_.count(key) != 0; }
    const std::vector<std::string>& Errors() const { return errors_; }
    const std::map<std::string, std::string>& All() const { return values_; }
private:
    std::map<std::string, std::string> values_;
    std::vector<std::string> errors_;
};
std::string Trim(const std::string& s);
}
