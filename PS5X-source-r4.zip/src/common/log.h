#pragma once
#include <cstdarg>
#include <cstdio>
#include <deque>
#include <mutex>
#include <string>
#include <vector>
#if defined(__MINGW32__)
#define PS5X_PRINTF(a, b) __attribute__((format(gnu_printf, a, b)))
#elif defined(__GNUC__)
#define PS5X_PRINTF(a, b) __attribute__((format(printf, a, b)))
#else
#define PS5X_PRINTF(a, b)
#endif
namespace ps5x {
enum class LogLevel { Trace, Debug, Info, Warn, Error };
class Logger {
public:
    static Logger& Get();
    void SetLevel(LogLevel l) { level_ = l; }
    void SetConsole(bool on) { console_ = on; }
    bool OpenFile(const std::string& path);   // append-mode file sink
    void Write(LogLevel l, const char* fmt, ...) PS5X_PRINTF(3, 4);
    std::vector<std::string> Recent() const;  // last N lines (for a log viewer)
    ~Logger();
private:
    Logger() = default;
    mutable std::mutex mu_;
    LogLevel level_ = LogLevel::Info;
    bool console_ = true;
    FILE* file_ = nullptr;
    std::deque<std::string> ring_;
};
}
#define PS5X_LOG(lvl, ...) ::ps5x::Logger::Get().Write(::ps5x::LogLevel::lvl, __VA_ARGS__)
