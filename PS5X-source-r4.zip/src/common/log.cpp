#include "common/log.h"
namespace ps5x {
Logger& Logger::Get() { static Logger l; return l; }
Logger::~Logger() { if (file_) fclose(file_); }
bool Logger::OpenFile(const std::string& path) {
    std::lock_guard<std::mutex> g(mu_);
    if (file_) fclose(file_);
    file_ = fopen(path.c_str(), "a");
    return file_ != nullptr;
}
void Logger::Write(LogLevel l, const char* fmt, ...) {
    if (l < level_) return;
    char buf[1024];
    va_list ap; va_start(ap, fmt); vsnprintf(buf, sizeof buf, fmt, ap); va_end(ap);
    static const char* names[] = {"TRACE", "DEBUG", "INFO ", "WARN ", "ERROR"};
    std::string line = std::string("[") + names[(int)l] + "] " + buf;
    std::lock_guard<std::mutex> g(mu_);
    if (console_) fprintf(l >= LogLevel::Warn ? stderr : stdout, "%s\n", line.c_str());
    if (file_) { fprintf(file_, "%s\n", line.c_str()); fflush(file_); }
    ring_.push_back(line);
    if (ring_.size() > 2000) ring_.pop_front();
}
std::vector<std::string> Logger::Recent() const {
    std::lock_guard<std::mutex> g(mu_);
    return {ring_.begin(), ring_.end()};
}
}
