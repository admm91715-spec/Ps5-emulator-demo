// PS5X command-line frontend. (A graphical frontend is NOT implemented yet; see docs/ROADMAP.md.)
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>
#include "common/config.h"
#include "common/log.h"
#include "core/emulator.h"
#include "storage/library.h"
#include "compat/compat_db.h"
#include "core/app_paths.h"
#include "core/regress.h"
namespace fs = std::filesystem;
using namespace ps5x;

static void Usage() {
    printf("PS5X %s - experimental PS5-oriented emulator foundation (NOT a working PS5 emulator)\n\n"
           "usage: ps5x [--data DIR] [--compat FILE] [--logs DIR] <command> ...\n"
           "  identify <path>            identify a file/game dir and print compatibility status\n"
           "  add <path>                 add a file or game directory to the library\n"
           "  scan <dir>                 scan a directory for supported/known game files\n"
           "  library                    list the library with compatibility status\n"
           "  run <path> [--max N] [--frame out.ppm] [--audio out.wav]\n"
           "                             load and execute through the real pipeline\n"
           "  make-sample <out.elf>      write a tiny test program (verifies the pipeline without any game)\n"
           "  config [get K | set K V | list]\n"
           "  devices                    GPU / audio / input backends\n"
           "  compat list | show ID | validate | set ID key=value...   evidence-gated compatibility database\n"
           "  regress <manifest>         run regression manifest through the real pipeline\n"
           "  --version\n", kVersion);
}
static std::string DataDir(const std::string& d) { std::error_code ec; fs::create_directories(d, ec); return d; }

int main(int argc, char** argv) {
    AppPaths ap; int i = 1; std::string perr;
    if (!ParseAppPaths(argc, argv, i, ap, perr)) { fprintf(stderr, "%s\n", perr.c_str()); return 2; }
    const std::string data = ap.data;
    if (i >= argc) { Usage(); return 2; }
    std::string cmd = argv[i++];
    if (cmd == "--version") { printf("PS5X %s\n", kVersion); return 0; }
    DataDir(data);
    Config cfg = Config::Defaults(); std::string err;
    const std::string cfgPath = ap.Config(), libPath = ap.Library();
    if (fs::exists(cfgPath) && !cfg.Load(cfgPath, &err)) { fprintf(stderr, "warning: config problem: %s\n", err.c_str()); for (auto& e : cfg.Errors()) fprintf(stderr, "  %s\n", e.c_str()); }
    { std::error_code lec; fs::create_directories(ap.logs.empty() ? data : ap.logs, lec); }
    Logger::Get().OpenFile(ap.LogFile());

    if (cmd == "identify" && i < argc) {
        FormatInfo f = IdentifyPath(argv[i]);
        printf("format : %s\nstatus : %s\ndetail : %s\n", f.name.c_str(), CompatName(f.compat), f.detail.c_str());
        if (!f.title.empty()) printf("title  : %s (%s)\n", f.title.c_str(), f.titleId.c_str());
        return f.compat == CompatStatus::LoadsOnly ? 0 : 1;
    }
    if ((cmd == "add" || cmd == "scan" || cmd == "library")) {
        GameLibrary lib; if (fs::exists(libPath)) lib.Load(libPath);
        if (cmd == "add" && i < argc) { GameEntry e = lib.Add(argv[i]); printf("%s: %s - %s\n", e.title.c_str(), CompatName(e.compat), e.note.c_str()); lib.Save(libPath); return 0; }
        if (cmd == "scan" && i < argc) { int n = lib.Scan(argv[i]); printf("added %d entr%s\n", n, n == 1 ? "y" : "ies"); lib.Save(libPath); return 0; }
        if (cmd == "library") {
            if (lib.Entries().empty()) puts("(library is empty; use 'add' or 'scan')");
            CompatDb cdb; { std::vector<std::string> ce; if (fs::exists(ap.Compat())) cdb.Load(ap.Compat(), &ce); }
            for (auto& e : lib.Entries()) printf("%-30s %-26s %-16s tested: %s\n    %s\n", e.title.c_str(), CompatName(e.compat), FormatName(e.format), CompatLevelName(cdb.LevelFor(e.titleId)), e.note.c_str());
            return 0;
        }
    }
    if (cmd == "make-sample" && i < argc) {
        auto b = BuildSampleElf(); std::ofstream f(argv[i], std::ios::binary); f.write((const char*)b.data(), b.size());
        printf("wrote %zu bytes to %s\n", b.size(), argv[i]); return f ? 0 : 1;
    }
    if (cmd == "config") {
        std::string sub = i < argc ? argv[i++] : "list";
        if (sub == "list") { for (auto& kv : cfg.All()) printf("%s = %s\n", kv.first.c_str(), kv.second.c_str()); return 0; }
        if (sub == "get" && i < argc) { if (!cfg.Has(argv[i])) { fprintf(stderr, "unknown key\n"); return 1; } puts(cfg.Get(argv[i]).c_str()); return 0; }
        if (sub == "set" && i + 1 < argc) { cfg.Set(argv[i], argv[i + 1]); if (!cfg.Save(cfgPath, &err)) { fprintf(stderr, "%s\n", err.c_str()); return 1; } return 0; }
        Usage(); return 2;
    }
    if (cmd == "compat") {
        CompatDb db; std::vector<std::string> errs; std::string sub = i < argc ? argv[i++] : "list";
        if (fs::exists(ap.Compat())) { if (!db.Load(ap.Compat(), &errs)) { fprintf(stderr, "compat db problems (rejected entries are NOT loaded):\n"); for (auto& e : errs) fprintf(stderr, "  %s\n", e.c_str()); if (sub != "validate") return 1; } }
        if (sub == "validate") { if (errs.empty()) printf("compat db OK (%zu entries)\n", db.Entries().size()); return errs.empty() ? 0 : 1; }
        if (sub == "list") { if (db.Entries().empty()) puts("(no tested titles recorded - every title is Not Tested)");
            for (auto& e : db.Entries()) {
                printf("%-14s %-10s %-28s v%s  %s\n", e.titleId.c_str(), CompatLevelName(e.level), e.name.c_str(), e.emulatorVersion.c_str(), e.date.c_str());
            }
            return 0; }
        if (sub == "show" && i < argc) { auto* e = db.Find(argv[i]); if (!e) { printf("%s: Not Tested (no record)\n", argv[i]); return 0; }
            printf("%s - %s\nlevel: %s\nboot/menu/gameplay: %s/%s/%s\ngraphics/audio: %s/%s\nperformance: %s\nissues: %s\ntested by %s on %s, emulator %s, host: %s\nevidence: %s (sessions: %d)\n",
                e->titleId.c_str(), e->name.c_str(), CompatLevelName(e->level), e->boot.c_str(), e->menu.c_str(), e->gameplay.c_str(), e->graphics.c_str(), e->audio.c_str(),
                e->performance.empty() ? "(not measured)" : e->performance.c_str(), e->issues.c_str(), e->tester.c_str(), e->date.c_str(), e->emulatorVersion.c_str(), e->host.c_str(), e->evidence.c_str(), e->sessions); return 0; }
        if (sub == "set" && i < argc) {
            CompatEntry ce; if (auto* old = db.Find(argv[i])) ce = *old; else { ce.titleId = argv[i]; }
            for (++i; i < argc; ++i) { std::string kv = argv[i]; size_t eq = kv.find('='); std::string e2;
                if (eq == std::string::npos || !CompatSetField(ce, kv.substr(0, eq), kv.substr(eq + 1), &e2)) { fprintf(stderr, "bad argument '%s': %s\n", kv.c_str(), e2.empty() ? "expected key=value" : e2.c_str()); return 2; } }
            std::vector<std::string> probs; if (!db.Upsert(ce, &probs)) { fprintf(stderr, "refused (not enough evidence / inconsistent):\n"); for (auto& p : probs) fprintf(stderr, "  - %s\n", p.c_str()); return 1; }
            if (!db.Save(ap.Compat(), &perr)) { fprintf(stderr, "%s\n", perr.c_str()); return 1; } printf("recorded %s as %s\n", ce.titleId.c_str(), CompatLevelName(ce.level)); return 0; }
        Usage(); return 2;
    }
    if (cmd == "regress" && i < argc) {
        std::vector<uint8_t> b; if (!ReadFileAll(argv[i], b, 1 << 20, &perr)) { fprintf(stderr, "%s\n", perr.c_str()); return 2; }
        auto res = RunRegression(std::string(b.begin(), b.end()), fs::path(argv[i]).parent_path().string(), cfg); int failed = 0;
        for (auto& r : res) { printf("[%s] %-24s %s\n", r.passed ? " OK " : "FAIL", r.name.c_str(), r.detail.c_str()); failed += !r.passed; }
        printf("%zu regression test(s), %d failed\n", res.size(), failed); return res.empty() ? 2 : (failed ? 1 : 0);
    }
    if (cmd == "devices") {
        std::string rep; ProbeVulkan(rep); printf("GPU backends : software (always); Vulkan: %s\n", rep.c_str());
        printf("Audio        :"); for (auto& a : ListAudioBackends()) printf(" %s", a.c_str()); printf("  (no live OS audio device backend yet)\n");
        InputManager in; for (auto& d : in.ListDevices()) printf("Input        : %s\n", d.c_str());
        return 0;
    }
    if (cmd == "run" && i < argc) {
        std::string path = argv[i++], frame, wav; uint64_t maxI = 0;
        for (; i + 1 < argc; i += 2) {
            if (!strcmp(argv[i], "--max")) maxI = strtoull(argv[i + 1], nullptr, 0);
            else if (!strcmp(argv[i], "--frame")) frame = argv[i + 1];
            else if (!strcmp(argv[i], "--audio")) wav = argv[i + 1];
            else { fprintf(stderr, "unknown option %s\n", argv[i]); return 2; }
        }
        Emulator emu(cfg);
        if (!emu.LoadFile(path, err)) { fprintf(stderr, "cannot run: %s\n", err.c_str()); return 1; }
        RunReport r = emu.Run(maxI);
        if (!r.stdoutText.empty()) printf("--- guest stdout ---\n%s--------------------\n", r.stdoutText.c_str());
        if (!r.stderrText.empty()) printf("--- guest stderr ---\n%s--------------------\n", r.stderrText.c_str());
        printf("stop reason  : %s%s\n", r.exited ? "guest exit" : StopReasonName(r.reason), r.exited ? (" (code " + std::to_string(r.exitCode) + ")").c_str() : "");
        if (!r.error.empty()) printf("detail       : %s\n", r.error.c_str());
        printf("instructions : %llu in %.4f s (%.2f MIPS measured on this run)\nsyscalls     : %llu, frames presented: %llu\n",
               (unsigned long long)r.instructions, r.seconds, r.mips, (unsigned long long)r.syscalls, (unsigned long long)r.frames);
        for (auto& u : r.unimplementedSyscalls) printf("unimplemented syscall %llu called %llu time(s)\n", (unsigned long long)u.first, (unsigned long long)u.second);
        if (!frame.empty()) { if (WritePPM(*emu.gpu, frame, &err)) printf("framebuffer  : %s\n", frame.c_str()); else fprintf(stderr, "%s\n", err.c_str()); }
        if (!wav.empty()) {
            auto out = CreateAudioBackend("wav", wav); uint32_t rate = (uint32_t)cfg.GetInt("audio.sample_rate", 48000);
            if (out && out->Open(rate, 2, &err)) { std::vector<int16_t> t(4096); size_t n; while ((n = emu.audioRing.Pop(t.data(), t.size()))) out->Write(t.data(), n); printf("audio        : %s (%llu samples)\n", wav.c_str(), (unsigned long long)out->samplesWritten); }
            else fprintf(stderr, "audio: %s\n", err.c_str());
        }
        return r.exited ? r.exitCode : 3;
    }
    Usage(); return 2;
}
