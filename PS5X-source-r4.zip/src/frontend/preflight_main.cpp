// ps5x_preflight: verify host + game folder before using an external PS5 emulator (e.g. KytyPS5).
#include <cstdio>
#include "preflight/preflight.h"
using namespace ps5x;
int main(int argc, char** argv) {
    if (argc > 1 && std::string(argv[1]) == "--help") { puts("usage: ps5x_preflight [game-directory-or-.zar]"); return 0; }
    bool fail = false;
    auto print = [&](const char* title, const std::vector<Check>& c) {
        printf("== %s ==\n", title);
        for (auto& x : c) printf("[%s] %-22s %s\n", CheckStatusName(x.status), x.name.c_str(), x.detail.c_str());
        fail |= HasFailure(c); };
    print("Host", CheckHost());
    if (argc > 1) print("Game path", CheckGamePath(argv[1]));
    printf("\n%s\n", fail ? "RESULT: at least one blocking problem (FAIL)" : "RESULT: no blocking problems found (this is not a compatibility guarantee)");
    return fail ? 1 : 0;
}
