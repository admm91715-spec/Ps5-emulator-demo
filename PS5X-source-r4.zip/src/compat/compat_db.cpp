#include "compat/compat_db.h"
#include "common/config.h"
#include <algorithm>
#include <cctype>
#include <fstream>
#include <sstream>
namespace ps5x {
static const char* kLevels[] = {"Not Tested", "Boots", "Intro", "Menu", "In-Game", "Playable", "Stable"};
const char* CompatLevelName(CompatLevel l) { return kLevels[(int)l]; }
static std::string Norm(std::string s) {
    std::string o; for (char c : s) if (isalnum((unsigned char)c)) o += (char)tolower((unsigned char)c); return o;
}
bool ParseCompatLevel(const std::string& s, CompatLevel& out) {
    for (int i = 0; i < 7; ++i) if (Norm(kLevels[i]) == Norm(s)) { out = (CompatLevel)i; return true; }
    return false;
}
static bool OneOf(const std::string& v, std::initializer_list<const char*> l) { for (auto* x : l) if (v == x) return true; return false; }
static bool IsDate(const std::string& d) {
    if (d.size() != 10 || d[4] != '-' || d[7] != '-') return false;
    for (int i = 0; i < 10; ++i) if (i != 4 && i != 7 && !isdigit((unsigned char)d[i])) return false;
    int m = std::stoi(d.substr(5, 2)), dd = std::stoi(d.substr(8, 2)); return m >= 1 && m <= 12 && dd >= 1 && dd <= 31;
}
bool CompatSetField(CompatEntry& e, const std::string& k, const std::string& v, std::string* err) {
    auto bad = [&](const std::string& m) { if (err) *err = m; return false; };
    if (k == "title_id") e.titleId = v; else if (k == "name") e.name = v; else if (k == "exe_format") e.exeFormat = v;
    else if (k == "emulator_version") e.emulatorVersion = v;
    else if (k == "level") { if (!ParseCompatLevel(v, e.level)) return bad("unknown level '" + v + "'"); }
    else if (k == "boot") e.boot = v; else if (k == "menu") e.menu = v; else if (k == "gameplay") e.gameplay = v;
    else if (k == "graphics") e.graphics = v; else if (k == "audio") e.audio = v; else if (k == "performance") e.performance = v;
    else if (k == "issues") e.issues = v; else if (k == "tester") e.tester = v; else if (k == "date") e.date = v;
    else if (k == "host") e.host = v; else if (k == "evidence") e.evidence = v;
    else if (k == "sessions") { char* end = nullptr; long n = strtol(v.c_str(), &end, 10); if (!end || *end || n < 0 || n > 100000) return bad("sessions must be a non-negative integer"); e.sessions = (int)n; }
    else return bad("unknown field '" + k + "'");
    return true;
}
std::vector<std::string> ValidateCompat(const CompatEntry& e) {
    std::vector<std::string> p;
    if (e.titleId.empty() || e.titleId.size() > 32) p.push_back("title_id must be 1-32 characters");
    for (char c : e.titleId) if (!isalnum((unsigned char)c) && c != '-' && c != '_') { p.push_back("title_id may only contain letters, digits, '-' and '_'"); break; }
    if (e.name.empty()) p.push_back("name is required");
    for (const std::string* t : {&e.boot, &e.menu, &e.gameplay}) if (!OneOf(*t, {"unknown", "no", "partial", "yes"})) p.push_back("boot/menu/gameplay must be unknown|no|partial|yes");
    for (const std::string* t : {&e.graphics, &e.audio}) if (!OneOf(*t, {"unknown", "broken", "partial", "good"})) p.push_back("graphics/audio must be unknown|broken|partial|good");
    if (!e.date.empty() && !IsDate(e.date)) p.push_back("date must be YYYY-MM-DD");
    if (e.level == CompatLevel::NotTested) {
        if (!e.performance.empty()) p.push_back("performance cannot be recorded for a Not Tested title");
        if (e.sessions != 0) p.push_back("sessions must be 0 for a Not Tested title");
        return p;
    }
    for (auto& kv : std::vector<std::pair<const char*, const std::string*>>{{"emulator_version", &e.emulatorVersion}, {"tester", &e.tester}, {"date", &e.date}, {"host", &e.host}, {"evidence", &e.evidence}})
        if (kv.second->empty()) p.push_back(std::string(kv.first) + " is required for any level above Not Tested (evidence-based classification)");
    if (e.date.empty() == false && !IsDate(e.date)) { /* already reported */ }
    if (e.sessions < 1) p.push_back("sessions must be >= 1");
    const bool bootOk = e.boot == "yes" || e.boot == "partial";
    switch (e.level) {
        case CompatLevel::Boots: if (!bootOk) p.push_back("Boots requires boot = partial|yes"); break;
        case CompatLevel::Intro: if (e.boot != "yes") p.push_back("Intro requires boot = yes"); break;
        case CompatLevel::Menu: if (e.boot != "yes" || !(e.menu == "yes" || e.menu == "partial")) p.push_back("Menu requires boot = yes and menu = partial|yes"); break;
        case CompatLevel::InGame: case CompatLevel::Playable: case CompatLevel::Stable:
            if (e.boot != "yes" || e.menu == "no" || e.menu == "unknown") p.push_back("this level requires boot = yes and a recorded menu result");
            if (!(e.gameplay == "yes" || e.gameplay == "partial")) p.push_back("In-Game and above require gameplay = partial|yes");
            break;
        default: break;
    }
    if (e.level >= CompatLevel::Playable) {
        if (e.gameplay != "yes") p.push_back("Playable/Stable require gameplay = yes");
        if (e.performance.empty()) p.push_back("Playable/Stable require a measured performance note (with method)");
        if (e.graphics == "broken" || e.audio == "broken" || e.graphics == "unknown" || e.audio == "unknown") p.push_back("Playable/Stable require graphics and audio to be assessed and not broken");
    }
    if (e.level == CompatLevel::Stable && e.sessions < 5) p.push_back("Stable requires >= 5 independent test sessions");
    return p;
}
static std::string FieldDump(const CompatEntry& e) {
    std::ostringstream o;
    o << "title_id: " << e.titleId << "\nname: " << e.name << "\nexe_format: " << e.exeFormat << "\nemulator_version: " << e.emulatorVersion
      << "\nlevel: " << CompatLevelName(e.level) << "\nboot: " << e.boot << "\nmenu: " << e.menu << "\ngameplay: " << e.gameplay
      << "\ngraphics: " << e.graphics << "\naudio: " << e.audio << "\nperformance: " << e.performance << "\nissues: " << e.issues
      << "\ntester: " << e.tester << "\ndate: " << e.date << "\nhost: " << e.host << "\nevidence: " << e.evidence << "\nsessions: " << e.sessions << "\n";
    return o.str();
}
bool CompatDb::ParseText(const std::string& text, std::vector<std::string>* errors) {
    entries_.clear(); bool ok = true; std::istringstream in(text); std::string line; int n = 0, startLine = 0;
    CompatEntry cur; bool open = false; std::vector<std::string> fieldErrs;
    auto err = [&](const std::string& m) { ok = false; if (errors) errors->push_back(m); };
    auto flush = [&]() {
        if (!open) return;
        open = false;
        for (auto& f : fieldErrs) err("entry at line " + std::to_string(startLine) + ": " + f);
        bool hadFieldErr = !fieldErrs.empty(); fieldErrs.clear();
        auto v = ValidateCompat(cur);
        for (auto& m : v) err("entry '" + cur.titleId + "' (line " + std::to_string(startLine) + "): " + m);
        if (find_if(entries_.begin(), entries_.end(), [&](const CompatEntry& x) { return x.titleId == cur.titleId; }) != entries_.end()) { err("duplicate title_id '" + cur.titleId + "'"); return; }
        if (v.empty() && !hadFieldErr) entries_.push_back(cur);   // invalid entries are rejected, never silently accepted
    };
    while (std::getline(in, line)) {
        ++n; line = Trim(line);
        if (line.empty()) { flush(); continue; }
        if (line[0] == '#') continue;
        size_t c = line.find(':');
        if (c == std::string::npos) { err("line " + std::to_string(n) + ": expected 'key: value'"); continue; }
        std::string k = Trim(line.substr(0, c)), v = Trim(line.substr(c + 1));
        if (k == "title_id") { flush(); cur = CompatEntry(); open = true; startLine = n; }
        if (!open) { err("line " + std::to_string(n) + ": field before title_id"); continue; }
        std::string fe; if (!CompatSetField(cur, k, v, &fe)) fieldErrs.push_back("line " + std::to_string(n) + ": " + fe);
    }
    flush(); return ok;
}
bool CompatDb::Load(const std::string& path, std::vector<std::string>* errors) {
    std::ifstream f(path); if (!f) { if (errors) errors->push_back("cannot open " + path); return false; }
    std::stringstream ss; ss << f.rdbuf(); return ParseText(ss.str(), errors);
}
bool CompatDb::Save(const std::string& path, std::string* err) const {
    std::ofstream f(path, std::ios::trunc); if (!f) { if (err) *err = "cannot write " + path; return false; }
    f << "# PS5X compatibility database. Every level above 'Not Tested' needs evidence; see docs/COMPATIBILITY_DB.md\n\n";
    for (auto& e : entries_) f << FieldDump(e) << "\n";
    return (bool)f;
}
bool CompatDb::Upsert(const CompatEntry& e, std::vector<std::string>* problems) {
    auto v = ValidateCompat(e); if (!v.empty()) { if (problems) *problems = v; return false; }
    for (auto& x : entries_) if (x.titleId == e.titleId) { x = e; return true; }
    entries_.push_back(e); return true;
}
const CompatEntry* CompatDb::Find(const std::string& id) const { for (auto& e : entries_) if (e.titleId == id) return &e; return nullptr; }
CompatLevel CompatDb::LevelFor(const std::string& id) const { auto* e = Find(id); return e ? e->level : CompatLevel::NotTested; }
}
