#pragma once
#include <string>
#include <vector>
namespace ps5x {
enum class CompatLevel { NotTested, Boots, Intro, Menu, InGame, Playable, Stable };
const char* CompatLevelName(CompatLevel l);
bool ParseCompatLevel(const std::string& s, CompatLevel& out);   // accepts "In-Game", "ingame", "in_game", ...

// One tested title on one emulator version. A level above NotTested is only accepted with evidence
// (tester, date, version, host, evidence reference) and with sub-fields that actually support the level.
struct CompatEntry {
    std::string titleId, name, exeFormat, emulatorVersion;
    CompatLevel level = CompatLevel::NotTested;
    std::string boot = "unknown", menu = "unknown", gameplay = "unknown";      // unknown|no|partial|yes
    std::string graphics = "unknown", audio = "unknown";                         // unknown|broken|partial|good
    std::string performance;   // MEASURED result incl. method (e.g. "avg 41 fps over 60 s, built-in counter"); empty = unmeasured
    std::string issues, tester, date, host, evidence;
    int sessions = 0;          // number of independent test sessions behind the classification
};
bool CompatSetField(CompatEntry& e, const std::string& key, const std::string& value, std::string* err);
std::vector<std::string> ValidateCompat(const CompatEntry& e);   // empty = valid

class CompatDb {
public:
    bool ParseText(const std::string& text, std::vector<std::string>* errors);   // invalid/duplicate entries are rejected AND reported
    bool Load(const std::string& path, std::vector<std::string>* errors);
    bool Save(const std::string& path, std::string* err) const;
    bool Upsert(const CompatEntry& e, std::vector<std::string>* problems);        // refuses invalid entries
    const CompatEntry* Find(const std::string& titleId) const;
    CompatLevel LevelFor(const std::string& titleId) const;                       // NotTested when absent
    const std::vector<CompatEntry>& Entries() const { return entries_; }
private:
    std::vector<CompatEntry> entries_;
};
}
