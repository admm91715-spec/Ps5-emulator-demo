#include "storage/format.h"
#include "loader/elf.h"
#include <cstring>
#include <filesystem>
#include <fstream>
namespace fs = std::filesystem;
namespace ps5x {
const char* CompatName(CompatStatus c) {
    switch (c) { case CompatStatus::Invalid: return "Invalid"; case CompatStatus::Unsupported: return "Unsupported";
                 case CompatStatus::LoadsOnly: return "Loads only (not playable)"; }
    return "?";
}
const char* FormatName(FileFormat f) {
    switch (f) { case FileFormat::Unknown: return "Unknown"; case FileFormat::ElfX64: return "ELF64 x86-64";
                 case FileFormat::ElfOther: return "ELF (other)"; case FileFormat::SelfPS4: return "SELF (PS4 magic)";
                 case FileFormat::SelfPS5: return "SELF (PS5 magic)"; case FileFormat::Pkg: return "PKG container";
                 case FileFormat::Directory: return "Game directory"; case FileFormat::Missing: return "Missing"; }
    return "?";
}
bool ReadFileAll(const std::string& path, std::vector<uint8_t>& out, uint64_t maxBytes, std::string* err) {
    std::ifstream f(path, std::ios::binary | std::ios::ate);
    if (!f) { if (err) *err = "cannot open " + path; return false; }
    uint64_t sz = (uint64_t)f.tellg();
    if (sz > maxBytes) { if (err) *err = "file larger than the supported limit"; return false; }
    out.resize(sz); f.seekg(0);
    f.read((char*)out.data(), sz);
    return (bool)f;
}
std::string JsonFindString(const std::string& t, const std::string& key) {
    std::string pat = "\"" + key + "\"";
    size_t p = t.find(pat); if (p == std::string::npos) return "";
    p = t.find(':', p + pat.size()); if (p == std::string::npos) return "";
    p = t.find('"', p); if (p == std::string::npos) return "";
    size_t e = t.find('"', p + 1); if (e == std::string::npos) return "";
    return t.substr(p + 1, e - p - 1);
}
FormatInfo IdentifyBuffer(const std::vector<uint8_t>& h, uint64_t fileSize) {
    FormatInfo r;
    auto is = [&](std::initializer_list<uint8_t> m) { if (h.size() < m.size()) return false; size_t i = 0; for (uint8_t b : m) if (h[i++] != b) return false; return true; };
    if (fileSize == 0) { r.format = FileFormat::Unknown; r.compat = CompatStatus::Invalid; r.name = FormatName(r.format); r.detail = "file is empty"; return r; }
    if (is({0x7f, 'E', 'L', 'F'})) {
        std::vector<uint8_t> full = h; ElfInfo ei; std::string err;
        if (ParseElf(full, ei, err)) {
            r.format = FileFormat::ElfX64; r.compat = CompatStatus::LoadsOnly;
            r.detail = "plain x86-64 ELF; PS5X can map it and run the supported integer-instruction subset";
            for (auto& w : ei.warnings) r.detail += "; " + w;
        } else { r.format = FileFormat::ElfOther; r.compat = CompatStatus::Invalid; r.detail = err; }
    } else if (is({0x4f, 0x15, 0x3d, 0x1d})) {
        r.format = FileFormat::SelfPS4; r.detail = "signed/encrypted SELF container; PS5X does not decrypt console executables";
    } else if (is({0x54, 0x14, 0xf5, 0xee})) {
        r.format = FileFormat::SelfPS5; r.detail = "signed/encrypted SELF container; PS5X does not decrypt console executables";
    } else if (is({0x7f, 'C', 'N', 'T'})) {
        r.format = FileFormat::Pkg; r.detail = "PKG container; package parsing is not implemented";
    } else { r.format = FileFormat::Unknown; r.compat = CompatStatus::Invalid; r.detail = "unrecognised file format"; }
    r.name = FormatName(r.format);
    return r;
}
FormatInfo IdentifyPath(const std::string& path) {
    FormatInfo r; std::error_code ec;
    if (!fs::exists(path, ec)) { r.format = FileFormat::Missing; r.compat = CompatStatus::Invalid; r.name = "Missing"; r.detail = "path does not exist"; return r; }
    if (fs::is_directory(path, ec)) {
        r.format = FileFormat::Directory; r.name = FormatName(r.format);
        fs::path pj = fs::path(path) / "sce_sys" / "param.json", eboot = fs::path(path) / "eboot.bin";
        if (fs::exists(pj, ec)) {
            std::vector<uint8_t> b; if (ReadFileAll(pj.string(), b, 1 << 20, nullptr)) {
                std::string t(b.begin(), b.end()); r.titleId = JsonFindString(t, "titleId"); r.title = JsonFindString(t, "titleName");
            }
        }
        if (!fs::exists(eboot, ec)) { r.compat = CompatStatus::Invalid; r.detail = "directory has no eboot.bin; not a recognised game layout"; return r; }
        FormatInfo inner = IdentifyPath(eboot.string());
        r.compat = inner.compat == CompatStatus::LoadsOnly ? CompatStatus::LoadsOnly : CompatStatus::Unsupported;
        r.detail = "eboot.bin: " + inner.name + " - " + inner.detail;
        return r;
    }
    std::vector<uint8_t> all; std::string err;
    uint64_t sz = fs::file_size(path, ec);
    if (!ReadFileAll(path, all, 512ull << 20, &err)) { r.compat = CompatStatus::Invalid; r.name = "Unreadable"; r.detail = err; return r; }
    return IdentifyBuffer(all, sz);
}
}
