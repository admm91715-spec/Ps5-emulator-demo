#pragma once
#include <string>
#include <vector>
#include <cstdint>
namespace ps5x {
enum class FileFormat { Unknown, ElfX64, ElfOther, SelfPS4, SelfPS5, Pkg, Directory, Missing };
// Only statuses that PS5X can actually justify. There is deliberately no "Playable".
enum class CompatStatus { Invalid, Unsupported, LoadsOnly };
struct FormatInfo {
    FileFormat format = FileFormat::Unknown;
    CompatStatus compat = CompatStatus::Unsupported;
    std::string name, detail;
    std::string titleId, title;   // from sce_sys/param.json if present
};
const char* CompatName(CompatStatus c);
const char* FormatName(FileFormat f);
FormatInfo IdentifyBuffer(const std::vector<uint8_t>& head, uint64_t fileSize);
FormatInfo IdentifyPath(const std::string& path);   // file or game directory
std::string JsonFindString(const std::string& text, const std::string& key);  // heuristic extractor
bool ReadFileAll(const std::string& path, std::vector<uint8_t>& out, uint64_t maxBytes, std::string* err);
}
