#include "storage/library.h"
#include <filesystem>
#include <fstream>
#include <sstream>
namespace fs = std::filesystem;
namespace ps5x {
GameEntry GameLibrary::Add(const std::string& path) {
    FormatInfo f = IdentifyPath(path);
    GameEntry e; e.path = path; e.format = f.format; e.compat = f.compat; e.note = f.detail; e.titleId = f.titleId;
    e.title = f.title.empty() ? fs::path(path).filename().string() : f.title;
    for (auto& x : entries_) if (x.path == path) { x = e; return e; }
    entries_.push_back(e); return e;
}
int GameLibrary::Scan(const std::string& dir, int maxDepth) {
    int added = 0; std::error_code ec;
    if (!fs::is_directory(dir, ec)) return 0;
    fs::recursive_directory_iterator it(dir, fs::directory_options::skip_permission_denied, ec), end;
    for (; !ec && it != end; it.increment(ec)) {
        if (it.depth() >= maxDepth) { it.disable_recursion_pending(); }
        const fs::path& p = it->path();
        if (it->is_directory(ec)) {
            if (fs::exists(p / "eboot.bin", ec) || fs::exists(p / "sce_sys" / "param.json", ec)) { size_t n = entries_.size(); Add(p.string()); added += entries_.size() > n; it.disable_recursion_pending(); }
        } else {
            std::string ext = p.extension().string();
            for (auto& c : ext) c = (char)tolower(c);
            if (ext == ".elf" || ext == ".self" || ext == ".pkg" || ext == ".bin" || ext == ".prx") { size_t n = entries_.size(); Add(p.string()); added += entries_.size() > n; }
        }
    }
    return added;
}
bool GameLibrary::Remove(const std::string& path) {
    for (size_t i = 0; i < entries_.size(); ++i) if (entries_[i].path == path) { entries_.erase(entries_.begin() + i); return true; }
    return false;
}
bool GameLibrary::Save(const std::string& file, std::string* err) const {
    std::ofstream f(file, std::ios::trunc);
    if (!f) { if (err) *err = "cannot write " + file; return false; }
    for (auto& e : entries_) f << e.path << "\n";   // metadata is re-derived on load so it can never go stale
    return (bool)f;
}
bool GameLibrary::Load(const std::string& file, std::string* err) {
    std::ifstream f(file);
    if (!f) { if (err) *err = "cannot open " + file; return false; }
    std::string line; entries_.clear();
    while (std::getline(f, line)) if (!line.empty()) Add(line);
    return true;
}
}
