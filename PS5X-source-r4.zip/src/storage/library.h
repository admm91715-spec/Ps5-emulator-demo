#pragma once
#include <string>
#include <vector>
#include "storage/format.h"
namespace ps5x {
struct GameEntry { std::string path, title, titleId; FileFormat format = FileFormat::Unknown; CompatStatus compat = CompatStatus::Invalid; std::string note; };
class GameLibrary {
public:
    GameEntry Add(const std::string& path);                         // identify + insert (dedupes by path)
    int Scan(const std::string& dir, int maxDepth = 4);             // returns number of entries added
    bool Remove(const std::string& path);
    bool Load(const std::string& file, std::string* err = nullptr);
    bool Save(const std::string& file, std::string* err = nullptr) const;
    const std::vector<GameEntry>& Entries() const { return entries_; }
private:
    std::vector<GameEntry> entries_;
};
}
