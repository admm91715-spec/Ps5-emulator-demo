#include "gpu/gpu.h"
#include <algorithm>
#include <cstdio>
namespace ps5x {
namespace {
class SoftGpu : public GpuBackend {
public:
    const char* Name() const override { return "software (CPU framebuffer)"; }
    bool Init(uint32_t w, uint32_t h, std::string* err) override {
        if (!w || !h || w > 16384 || h > 16384) { if (err) *err = "invalid framebuffer size"; return false; }
        w_ = w; h_ = h; fb_.assign((size_t)w * h, 0xFF000000u); frames = 0; return true;
    }
    void Execute(const GpuCommand& c) override {
        switch (c.type) {
            case GpuCmdType::Clear: std::fill(fb_.begin(), fb_.end(), c.color); break;
            case GpuCmdType::FillRect: {
                int x0 = std::max(0, c.x), y0 = std::max(0, c.y);
                int x1 = (int)std::min<int64_t>(w_, (int64_t)c.x + c.w), y1 = (int)std::min<int64_t>(h_, (int64_t)c.y + c.h);
                for (int y = y0; y < y1; ++y) for (int x = x0; x < x1; ++x) fb_[(size_t)y * w_ + x] = c.color;
                break; }
            case GpuCmdType::Present: ++frames; break;
        }
    }
    const std::vector<uint32_t>& Framebuffer() const override { return fb_; }
    uint32_t Width() const override { return w_; }
    uint32_t Height() const override { return h_; }
private:
    uint32_t w_ = 0, h_ = 0; std::vector<uint32_t> fb_;
};
}
std::unique_ptr<GpuBackend> CreateSoftwareGpu() { return std::unique_ptr<GpuBackend>(new SoftGpu()); }
bool WritePPM(const GpuBackend& g, const std::string& path, std::string* err) {
    FILE* f = fopen(path.c_str(), "wb");
    if (!f) { if (err) *err = "cannot write " + path; return false; }
    fprintf(f, "P6\n%u %u\n255\n", g.Width(), g.Height());
    for (uint32_t px : g.Framebuffer()) { unsigned char rgb[3] = {(unsigned char)(px >> 16), (unsigned char)(px >> 8), (unsigned char)px}; fwrite(rgb, 1, 3, f); }
    fclose(f); return true;
}
}
