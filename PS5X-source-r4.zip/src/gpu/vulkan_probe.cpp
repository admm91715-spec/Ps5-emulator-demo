#include "gpu/gpu.h"
#ifdef PS5X_HAS_VULKAN
#include <vulkan/vulkan.h>
namespace ps5x {
bool ProbeVulkan(std::string& report) {
    VkApplicationInfo app{VK_STRUCTURE_TYPE_APPLICATION_INFO}; app.pApplicationName = "PS5X"; app.apiVersion = VK_API_VERSION_1_1;
    VkInstanceCreateInfo ci{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO}; ci.pApplicationInfo = &app;
    VkInstance inst = VK_NULL_HANDLE;
    if (vkCreateInstance(&ci, nullptr, &inst) != VK_SUCCESS) { report = "vkCreateInstance failed (no Vulkan loader/driver?)"; return false; }
    uint32_t n = 0; vkEnumeratePhysicalDevices(inst, &n, nullptr);
    std::vector<VkPhysicalDevice> devs(n); vkEnumeratePhysicalDevices(inst, &n, devs.data());
    report = std::to_string(n) + " Vulkan device(s):";
    for (auto d : devs) { VkPhysicalDeviceProperties p; vkGetPhysicalDeviceProperties(d, &p); report += std::string("\n  ") + p.deviceName; }
    vkDestroyInstance(inst, nullptr); return n > 0;
}
}
#else
namespace ps5x {
bool ProbeVulkan(std::string& report) { report = "Vulkan support not compiled in (configure with -DPS5X_ENABLE_VULKAN=ON and the Vulkan SDK)"; return false; }
}
#endif
