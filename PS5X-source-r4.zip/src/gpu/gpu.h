#pragma once
#include <cstdint>
#include <memory>
#include <string>
#include <vector>
namespace ps5x {
enum class GpuCmdType { Clear, FillRect, Present };
struct GpuCommand { GpuCmdType type; int32_t x = 0, y = 0, w = 0, h = 0; uint32_t color = 0; };  // color 0xAARRGGBB

// Backend interface. The command stream here is PS5X's own simplified format -
// real PS5 (AMD GFX10.x/PM4) command-buffer processing is NOT implemented.
class GpuBackend {
public:
    virtual ~GpuBackend() = default;
    virtual const char* Name() const = 0;
    virtual bool Init(uint32_t w, uint32_t h, std::string* err) = 0;
    virtual void Execute(const GpuCommand& c) = 0;
    virtual const std::vector<uint32_t>& Framebuffer() const = 0;
    virtual uint32_t Width() const = 0;
    virtual uint32_t Height() const = 0;
    uint64_t frames = 0;
};
std::unique_ptr<GpuBackend> CreateSoftwareGpu();
bool WritePPM(const GpuBackend& g, const std::string& path, std::string* err);
// Vulkan: lists physical devices. Compiled only when PS5X_HAS_VULKAN is defined (untested in CI here).
bool ProbeVulkan(std::string& report);
}
