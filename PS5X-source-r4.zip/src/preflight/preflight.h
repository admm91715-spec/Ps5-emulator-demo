#pragma once
#include <string>
#include <vector>
namespace ps5x {
enum class CheckStatus { Pass, Warn, Fail, Info };
struct Check { std::string name; CheckStatus status; std::string detail; };
const char* CheckStatusName(CheckStatus s);
// Host checks against the published requirements of KytyPS5 Windows packages (x86-64-v3 CPU, enough RAM).
std::vector<Check> CheckHost();
// Layout checks for a game directory / .zar archive as expected by KytyPS5 forks (eboot.bin + sce_sys next to each other).
// This never decrypts or modifies anything; it cannot tell whether an eboot.bin is in a form the emulator accepts.
std::vector<Check> CheckGamePath(const std::string& path);
bool HasFailure(const std::vector<Check>& c);
}
