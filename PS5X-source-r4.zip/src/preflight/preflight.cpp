#include "preflight/preflight.h"
#include "storage/format.h"
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>
#ifdef _WIN32
#include <windows.h>
#endif
namespace fs = std::filesystem;
namespace ps5x {
const char* CheckStatusName(CheckStatus s) {
    switch (s) { case CheckStatus::Pass: return "PASS"; case CheckStatus::Warn: return "WARN"; case CheckStatus::Fail: return "FAIL"; default: return "INFO"; }
}
bool HasFailure(const std::vector<Check>& c) { for (auto& x : c) if (x.status == CheckStatus::Fail) return true; return false; }

static uint64_t TotalRamBytes() {
#ifdef _WIN32
    MEMORYSTATUSEX m{}; m.dwLength = sizeof m; return GlobalMemoryStatusEx(&m) ? m.ullTotalPhys : 0;
#else
    std::ifstream f("/proc/meminfo"); std::string k; unsigned long long kb = 0;
    while (f >> k) { if (k == "MemTotal:") { f >> kb; return kb * 1024ull; } f.ignore(1 << 16, '\n'); }
    return 0;
#endif
}
std::vector<Check> CheckHost() {
    std::vector<Check> r;
#if defined(__x86_64__) || defined(_M_X64)
    struct F { const char* n; bool ok; } feats[] = {
#if defined(__GNUC__)
        {"AVX2", __builtin_cpu_supports("avx2") != 0}, {"FMA", __builtin_cpu_supports("fma") != 0}, {"BMI2", __builtin_cpu_supports("bmi2") != 0}
#else
        {"AVX2", false}, {"FMA", false}, {"BMI2", false}
#endif
    };
    for (auto& f : feats)
        r.push_back({std::string("CPU ") + f.n, f.ok ? CheckStatus::Pass : CheckStatus::Fail,
                     f.ok ? "supported" : "missing - KytyPS5 Windows packages state an x86-64-v3 CPU (AVX2, FMA, BMI2) is required"});
#else
    r.push_back({"CPU architecture", CheckStatus::Fail, "not x86-64; PS5 software is x86-64 and current PS5 emulators target x86-64 hosts"});
#endif
    uint64_t ram = TotalRamBytes();
    if (!ram) r.push_back({"System RAM", CheckStatus::Info, "could not be determined on this platform"});
    else {
        double gb = ram / 1073741824.0; char b[96]; snprintf(b, sizeof b, "%.1f GiB installed", gb);
        // Heuristic only: one KytyPS5 fork's notes describe special low-memory behaviour below 24 GB and list 32 GB as its requirement.
        CheckStatus s = gb < 16 ? CheckStatus::Warn : (gb < 24 ? CheckStatus::Info : CheckStatus::Pass);
        std::string d = b; if (s != CheckStatus::Pass) d += " (published notes from KytyPS5 forks suggest 24-32 GB for demanding titles; heuristic, not a hard rule)";
        r.push_back({"System RAM", s, d});
    }
    r.push_back({"Vulkan 1.3 GPU/driver", CheckStatus::Info, "not probed by this tool; verify with `vulkaninfo --summary`. KytyPS5 states a Vulkan 1.3 renderer"});
    return r;
}
std::vector<Check> CheckGamePath(const std::string& path) {
    std::vector<Check> r; std::error_code ec;
    if (!fs::exists(path, ec)) { r.push_back({"Path", CheckStatus::Fail, "does not exist"}); return r; }
    if (path.find('[') != std::string::npos || path.find(']') != std::string::npos)
        r.push_back({"Path characters", CheckStatus::Warn, "contains [ or ]; KytyPS5 package scripts are documented to stop in such folders"});
    if (path.size() > 100) r.push_back({"Path length", CheckStatus::Warn, "long path; KytyPS5 docs recommend short writable folders (heuristic threshold: 100 chars)"});
    if (fs::is_regular_file(path, ec)) {
        std::string ext = fs::path(path).extension().string(); for (auto& c : ext) c = (char)tolower(c);
        if (ext == ".zar") r.push_back({"Archive", CheckStatus::Info, "ZArchive file; KytyPS5 forks document support when its root contains eboot.bin. Contents were NOT inspected"});
        else r.push_back({"Path", CheckStatus::Fail, "a single file other than .zar; select the game directory (the one directly containing eboot.bin and sce_sys)"});
        return r;
    }
    fs::path eboot = fs::path(path) / "eboot.bin", sys = fs::path(path) / "sce_sys";
    bool hasEboot = fs::is_regular_file(eboot, ec), hasSys = fs::is_directory(sys, ec);
    r.push_back({"eboot.bin", hasEboot ? CheckStatus::Pass : CheckStatus::Fail, hasEboot ? "present" : "missing: select the directory that directly contains eboot.bin"});
    r.push_back({"sce_sys/", hasSys ? CheckStatus::Pass : CheckStatus::Fail, hasSys ? "present" : "missing"});
    if (hasEboot) {
        std::ifstream f(eboot, std::ios::binary); unsigned char m[4] = {};
        f.read((char*)m, 4);
        if (f.gcount() < 4) r.push_back({"eboot.bin format", CheckStatus::Fail, "file is shorter than 4 bytes"});
        else if (!memcmp(m, "\x7f""ELF", 4)) r.push_back({"eboot.bin format", CheckStatus::Info, "plain ELF header"});
        else if (!memcmp(m, "\x54\x14\xf5\xee", 4)) r.push_back({"eboot.bin format", CheckStatus::Info, "SELF container (PS5 magic). PS5X cannot tell whether the emulator will accept it, and does not decrypt anything"});
        else if (!memcmp(m, "\x4f\x15\x3d\x1d", 4)) r.push_back({"eboot.bin format", CheckStatus::Warn, "PS4 SELF magic; PS4 titles are not what PS5 emulators target"});
        else r.push_back({"eboot.bin format", CheckStatus::Warn, "unrecognised header"});
    }
    fs::path pj = sys / "param.json";
    if (fs::is_regular_file(pj, ec)) {
        std::vector<uint8_t> b; if (ReadFileAll(pj.string(), b, 1 << 20, nullptr)) {
            std::string t(b.begin(), b.end()), id = JsonFindString(t, "titleId"), name = JsonFindString(t, "titleName");
            r.push_back({"param.json", id.empty() ? CheckStatus::Warn : CheckStatus::Pass, id.empty() ? "readable but no titleId found" : "titleId " + id + (name.empty() ? "" : " (" + name + ")")});
        } else r.push_back({"param.json", CheckStatus::Warn, "present but unreadable"});
    } else if (hasSys) r.push_back({"param.json", CheckStatus::Warn, "sce_sys/param.json not found; title metadata unavailable"});
    r.push_back({"Compatibility", CheckStatus::Info, "layout checks say nothing about whether this title runs. Check the emulator project's own compatibility reports"});
    return r;
}
}
