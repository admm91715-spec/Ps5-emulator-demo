#include "input/input.h"
#ifdef _WIN32
#include <windows.h>
#include <xinput.h>
namespace {
// Loaded at runtime so the exe has no link-time dependency on any XInput DLL (xinput1_3.dll is not on a clean Windows 10).
typedef DWORD(WINAPI* XInputGetStateFn)(DWORD, XINPUT_STATE*);
XInputGetStateFn LoadXInput() {
    static XInputGetStateFn fn = nullptr; static bool tried = false;
    if (!tried) {
        tried = true;
        const char* names[] = {"xinput1_4.dll", "xinput1_3.dll", "xinput9_1_0.dll"};
        for (const char* n : names) {
            HMODULE m = LoadLibraryA(n);
            if (!m) continue;
            fn = (XInputGetStateFn)(void*)GetProcAddress(m, "XInputGetState");
            if (fn) break;
        }
    }
    return fn;
}
}
#endif
namespace ps5x {
bool InputManager::ButtonFromName(const std::string& n, uint32_t& out) {
    static const std::map<std::string, uint32_t> m = {{"cross", BTN_CROSS}, {"circle", BTN_CIRCLE}, {"square", BTN_SQUARE},
        {"triangle", BTN_TRIANGLE}, {"up", BTN_UP}, {"down", BTN_DOWN}, {"left", BTN_LEFT}, {"right", BTN_RIGHT},
        {"options", BTN_OPTIONS}, {"l1", BTN_L1}, {"r1", BTN_R1}};
    auto it = m.find(n); if (it == m.end()) return false; out = it->second; return true;
}
bool InputManager::LoadMapping(const Config& c, std::vector<std::string>* errors) {
    keymap_.clear(); bool ok = true; const std::string pre = "input.map.";
    for (auto& kv : c.All()) {
        if (kv.first.compare(0, pre.size(), pre) != 0) continue;
        uint32_t b; std::string name = kv.first.substr(pre.size());
        if (!ButtonFromName(name, b)) { ok = false; if (errors) errors->push_back("unknown pad button '" + name + "'"); continue; }
        if (kv.second.empty()) { ok = false; if (errors) errors->push_back("empty key for '" + name + "'"); continue; }
        keymap_[kv.second] = b;
    }
    return ok;
}
void InputManager::KeyEvent(const std::string& key, bool down) {
    auto it = keymap_.find(key); if (it == keymap_.end()) return;
    if (down) state_.buttons |= it->second; else state_.buttons &= ~it->second;
}
bool InputManager::PollGamepad() {
#ifdef _WIN32
    XInputGetStateFn getState = LoadXInput();
    if (!getState) { gamepadPresent_ = false; return false; }
    XINPUT_STATE xs{};
    if (getState(0, &xs) != ERROR_SUCCESS) { gamepadPresent_ = false; return false; }   // polled each call: hot-plug works
    gamepadPresent_ = true;
    const WORD b = xs.Gamepad.wButtons;
    static const struct { WORD mask; uint32_t pad; } kMap[] = {
        {XINPUT_GAMEPAD_A, BTN_CROSS}, {XINPUT_GAMEPAD_B, BTN_CIRCLE}, {XINPUT_GAMEPAD_X, BTN_SQUARE}, {XINPUT_GAMEPAD_Y, BTN_TRIANGLE},
        {XINPUT_GAMEPAD_DPAD_UP, BTN_UP}, {XINPUT_GAMEPAD_DPAD_DOWN, BTN_DOWN}, {XINPUT_GAMEPAD_DPAD_LEFT, BTN_LEFT},
        {XINPUT_GAMEPAD_DPAD_RIGHT, BTN_RIGHT}, {XINPUT_GAMEPAD_START, BTN_OPTIONS},
        {XINPUT_GAMEPAD_LEFT_SHOULDER, BTN_L1}, {XINPUT_GAMEPAD_RIGHT_SHOULDER, BTN_R1}};
    uint32_t o = 0;                                   // an attached gamepad replaces the keyboard-driven pad state
    for (const auto& m : kMap) {
        if (b & m.mask) { o |= m.pad; }
    }
    state_.buttons = o;
    state_.lx = xs.Gamepad.sThumbLX; state_.ly = xs.Gamepad.sThumbLY;
    state_.rx = xs.Gamepad.sThumbRX; state_.ry = xs.Gamepad.sThumbRY;
    return true;
#else
    return false;
#endif
}
std::vector<std::string> InputManager::ListDevices() const {
    std::vector<std::string> d = {"keyboard (virtual pad via KeyEvent)"};
#ifdef _WIN32
    d.push_back(gamepadPresent_ ? "XInput gamepad 0 (connected)" : "XInput gamepad 0 (not connected)");
#else
    d.push_back("XInput gamepad: unavailable on this platform");
#endif
    return d;
}
}
