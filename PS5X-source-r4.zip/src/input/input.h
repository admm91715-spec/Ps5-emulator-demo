#pragma once
#include <cstdint>
#include <map>
#include <string>
#include <vector>
#include "common/config.h"
namespace ps5x {
enum PadButton : uint32_t { BTN_CROSS = 1, BTN_CIRCLE = 2, BTN_SQUARE = 4, BTN_TRIANGLE = 8, BTN_UP = 16, BTN_DOWN = 32,
                            BTN_LEFT = 64, BTN_RIGHT = 128, BTN_OPTIONS = 256, BTN_L1 = 512, BTN_R1 = 1024 };
struct PadState { uint32_t buttons = 0; int16_t lx = 0, ly = 0, rx = 0, ry = 0; };
class InputManager {
public:
    // Reads keys from config "input.map.<button>" = <KeyName>. Returns false (and lists errors) on unknown button names.
    bool LoadMapping(const Config& c, std::vector<std::string>* errors = nullptr);
    void KeyEvent(const std::string& keyName, bool down);   // keyboard -> virtual pad
    bool PollGamepad();     // XInput on Windows builds; always false elsewhere
    PadState State() const { return state_; }
    std::vector<std::string> ListDevices() const;
    static bool ButtonFromName(const std::string& n, uint32_t& out);
private:
    std::map<std::string, uint32_t> keymap_; PadState state_; bool gamepadPresent_ = false;
};
}
