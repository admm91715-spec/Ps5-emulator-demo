#pragma once
#include <cstdint>
#include <functional>
#include <map>
#include <string>
#include "cpu/x86_cpu.h"
#include "gpu/gpu.h"
#include "audio/audio.h"
#include "input/input.h"
namespace ps5x {
// System-call layer. Numbers < 0x1000 follow the publicly documented FreeBSD amd64 ABI
// (rax = number, args rdi,rsi,rdx,r10,r8,r9; error = CF set + errno in rax).
// Numbers >= 0x1000 are the "PS5X test ABI": homebrew-style helpers to exercise the
// GPU/audio/input subsystems from guest code. They are NOT part of any PS5 software interface.
// Real PS5 titles reach the OS through Sony system libraries; those are NOT implemented.
struct KernelServices { GpuBackend* gpu = nullptr; AudioRing* audio = nullptr; InputManager* input = nullptr; };
class Kernel {
public:
    using Handler = std::function<void(Kernel&)>;
    Kernel(GuestMemory& m, X86Cpu& c, KernelServices s);
    void Register(uint64_t num, const std::string& name, Handler h);
    void Dispatch();                         // called when the CPU stops with StopReason::Syscall
    uint64_t Arg(int i) const;
    void Return(uint64_t v);                 // success
    void Error(uint64_t errnoVal);           // failure: CF set, rax = errno
    GuestMemory& mem; X86Cpu& cpu; KernelServices svc;
    bool exited = false; int exitCode = 0;
    std::string stdoutBuf, stderrBuf;
    std::map<uint64_t, uint64_t> unimplemented;    // syscall number -> count
    uint64_t syscallCount = 0;
private:
    struct Entry { std::string name; Handler fn; };
    std::map<uint64_t, Entry> table_;
};
}
