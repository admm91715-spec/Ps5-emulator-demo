#include "kernel/kernel.h"
#include "common/log.h"
namespace ps5x {
enum { K_ENOMEM = 12, K_EFAULT = 14, K_EINVAL = 22, K_EBADF = 9, K_ENODEV = 19, K_ENOSYS = 78 };
uint64_t Kernel::Arg(int i) const {
    static const int order[6] = {RDI, RSI, RDX, R10, R8, R9};
    return cpu.st.gpr[order[i]];
}
void Kernel::Return(uint64_t v) { cpu.st.gpr[RAX] = v; cpu.st.rflags &= ~FLAG_CF; }
void Kernel::Error(uint64_t e) { cpu.st.gpr[RAX] = e; cpu.st.rflags |= FLAG_CF; }
void Kernel::Register(uint64_t num, const std::string& name, Handler h) { table_[num] = Entry{name, std::move(h)}; }
void Kernel::Dispatch() {
    ++syscallCount;
    uint64_t n = cpu.st.gpr[RAX];
    auto it = table_.find(n);
    if (it == table_.end()) {
        if (++unimplemented[n] == 1) PS5X_LOG(Warn, "unimplemented syscall %llu at rip=0x%llx -> ENOSYS", (unsigned long long)n, (unsigned long long)cpu.st.rip);
        Error(K_ENOSYS); return;
    }
    it->second.fn(*this);
}
static uint64_t RoundPage(uint64_t v) { return (v + kPageSize - 1) & ~(kPageSize - 1); }

Kernel::Kernel(GuestMemory& m, X86Cpu& c, KernelServices s) : mem(m), cpu(c), svc(s) {
    Register(1, "exit", [](Kernel& k) { k.exited = true; k.exitCode = (int)k.Arg(0); k.Return(0); });
    Register(4, "write", [](Kernel& k) {
        uint64_t fd = k.Arg(0), buf = k.Arg(1), n = k.Arg(2);
        if (fd != 1 && fd != 2) return k.Error(K_EBADF);
        if (n > (1u << 20)) return k.Error(K_EINVAL);
        std::string s(n, '\0');
        if (n && !k.mem.Read(buf, &s[0], n)) return k.Error(K_EFAULT);
        (fd == 1 ? k.stdoutBuf : k.stderrBuf) += s; k.Return(n); });
    Register(20, "getpid", [](Kernel& k) { k.Return(1000); });
    Register(477, "mmap", [](Kernel& k) {
        uint64_t addr = k.Arg(0), len = k.Arg(1), prot = k.Arg(2), flags = k.Arg(3);
        if (!(flags & 0x1000)) return k.Error(K_ENODEV);          // only MAP_ANON
        if (len == 0) return k.Error(K_EINVAL);
        len = RoundPage(len);
        if (!(flags & 0x10)) addr = k.mem.FindFree(len);          // not MAP_FIXED
        if (!addr) return k.Error(K_ENOMEM);
        std::string e;
        if (!k.mem.Map(addr, len, (uint8_t)(prot & 7), "mmap", &e)) return k.Error(e.find("limit") != std::string::npos ? K_ENOMEM : K_EINVAL);
        k.Return(addr); });
    Register(73, "munmap", [](Kernel& k) { if (!k.mem.Unmap(k.Arg(0), RoundPage(k.Arg(1)))) return k.Error(K_EINVAL); k.Return(0); });

    // ---- PS5X test ABI ----
    Register(0x1000, "ps5x_gpu_clear", [](Kernel& k) { if (!k.svc.gpu) return k.Error(K_ENOSYS);
        GpuCommand c{GpuCmdType::Clear}; c.color = (uint32_t)k.Arg(0); k.svc.gpu->Execute(c); k.Return(0); });
    Register(0x1001, "ps5x_gpu_fillrect", [](Kernel& k) { if (!k.svc.gpu) return k.Error(K_ENOSYS);
        GpuCommand c{GpuCmdType::FillRect}; c.x = (int32_t)k.Arg(0); c.y = (int32_t)k.Arg(1); c.w = (int32_t)k.Arg(2); c.h = (int32_t)k.Arg(3);
        c.color = (uint32_t)k.Arg(4); k.svc.gpu->Execute(c); k.Return(0); });
    Register(0x1002, "ps5x_gpu_present", [](Kernel& k) { if (!k.svc.gpu) return k.Error(K_ENOSYS);
        GpuCommand c{GpuCmdType::Present}; k.svc.gpu->Execute(c); k.Return(k.svc.gpu->frames); });
    Register(0x1003, "ps5x_audio_write", [](Kernel& k) {   // (ptr to s16 samples, sample count) -> samples accepted
        if (!k.svc.audio) return k.Error(K_ENOSYS);
        uint64_t p = k.Arg(0), n = k.Arg(1); if (n > (1u << 20)) return k.Error(K_EINVAL);
        std::vector<int16_t> tmp(n); if (n && !k.mem.Read(p, tmp.data(), n * 2)) return k.Error(K_EFAULT);
        k.Return(k.svc.audio->Push(tmp.data(), n)); });
    Register(0x1004, "ps5x_pad_read", [](Kernel& k) { if (!k.svc.input) return k.Error(K_ENOSYS); k.Return(k.svc.input->State().buttons); });
}
}
