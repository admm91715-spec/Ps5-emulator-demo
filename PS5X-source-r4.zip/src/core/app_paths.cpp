#include "core/app_paths.h"
#include <cstring>
namespace ps5x {
bool ParseAppPaths(int argc, char** argv, int& i, AppPaths& p, std::string& err) {
    while (i < argc && (!strcmp(argv[i], "--data") || !strcmp(argv[i], "--compat") || !strcmp(argv[i], "--logs"))) {
        if (i + 1 >= argc) { err = std::string(argv[i]) + " needs a value"; return false; }
        std::string v = argv[i + 1];
        if (!strcmp(argv[i], "--data")) p.data = v; else if (!strcmp(argv[i], "--compat")) p.compat = v; else p.logs = v;
        i += 2;
    }
    return true;
}
}
