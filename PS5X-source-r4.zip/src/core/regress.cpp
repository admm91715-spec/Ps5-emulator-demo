#include "core/regress.h"
#include "core/emulator.h"
#include "storage/format.h"
#include <cstdio>
#include <sstream>
namespace ps5x {
uint64_t Fnv1a64(const std::vector<uint32_t>& px) {
    uint64_t h = 1469598103934665603ull;
    for (uint32_t v : px) for (int i = 0; i < 4; ++i) { h ^= (uint8_t)(v >> (8 * i)); h *= 1099511628211ull; }
    return h;
}
static std::vector<std::string> Split(const std::string& s) {
    std::vector<std::string> o; std::string cur; for (char c : s) { if (c == '|') { o.push_back(Trim(cur)); cur.clear(); } else cur += c; } o.push_back(Trim(cur)); return o;
}
std::vector<RegressResult> RunRegression(const std::string& text, const std::string& baseDir, const Config& cfgIn) {
    std::vector<RegressResult> out; std::istringstream in(text); std::string line;
    Config cfg = cfgIn; cfg.Set("graphics.width", "64"); cfg.Set("graphics.height", "32");
    while (std::getline(in, line)) {
        line = Trim(line); if (line.empty() || line[0] == '#') continue;
        RegressResult r; auto f = Split(line);
        if (f.size() != 6) { r.name = f.empty() ? "?" : f[0]; r.detail = "malformed manifest line (need 6 '|'-separated fields)"; out.push_back(r); continue; }
        r.name = f[0]; std::string path = f[1];
        if (path.empty() || (path[0] != '/' && path.find(':') == std::string::npos)) path = baseDir + "/" + path;
        char* e1 = nullptr; long expectExit = strtol(f[2].c_str(), &e1, 0);
        char* e2 = nullptr; unsigned long long maxI = strtoull(f[5].c_str(), &e2, 0);
        if (!e1 || *e1 || f[2].empty() || !e2 || *e2 || f[5].empty()) { r.detail = "expect_exit/max_instructions are not numbers"; out.push_back(r); continue; }
        uint64_t wantHash = 0; bool checkHash = f[4] != "-";
        if (checkHash) { char* e3 = nullptr; wantHash = strtoull(f[4].c_str(), &e3, 16); if (!e3 || *e3 || f[4].empty()) { r.detail = "bad frame hash"; out.push_back(r); continue; } }
        Emulator emu(cfg); std::string err;
        if (!emu.LoadFile(path, err)) { r.detail = "load failed: " + err; out.push_back(r); continue; }
        RunReport rr = emu.Run(maxI);
        r.frameHash = Fnv1a64(emu.gpu->Framebuffer());
        char b[256];
        if (!rr.exited) { r.detail = std::string("did not exit cleanly: ") + StopReasonName(rr.reason) + " " + rr.error; }
        else if (rr.exitCode != (int)expectExit) { snprintf(b, sizeof b, "exit code %d, expected %ld", rr.exitCode, expectExit); r.detail = b; }
        else if (!f[3].empty() && f[3] != "-" && rr.stdoutText.find(f[3]) == std::string::npos) r.detail = "stdout does not contain expected text";
        else if (checkHash && r.frameHash != wantHash) { snprintf(b, sizeof b, "frame hash %016llx, expected %016llx", (unsigned long long)r.frameHash, (unsigned long long)wantHash); r.detail = b; }
        else { r.passed = true; snprintf(b, sizeof b, "ok (%llu instr, frame %016llx)", (unsigned long long)rr.instructions, (unsigned long long)r.frameHash); r.detail = b; }
        out.push_back(r);
    }
    return out;
}
}
