#include "core/emulator.h"
#include "common/log.h"
#include "storage/format.h"
#include <chrono>
#include <cstring>
#include <system_error>
namespace ps5x {
static const uint64_t kStackTop = 0x7ffff000, kStackSize = 0x100000;
Emulator::Emulator(const Config& cfg) : cpu(mem), audioRing(48000 * 2 * 4), cfg_(cfg) {
    mem.SetLimit((uint64_t)cfg.GetInt("memory.max_mb", 1024) << 20);
    if (cfg.GetBool("cpu.trace", false)) cpu.trace = true;
    input.LoadMapping(cfg);
}
bool Emulator::LoadFile(const std::string& path, std::string& err) {
    FormatInfo fi = IdentifyPath(path);
    if (fi.compat != CompatStatus::LoadsOnly) { err = std::string(fi.name) + ": " + fi.detail; return false; }
    std::string p = path;
    std::error_code ec;
    if (fi.format == FileFormat::Directory) p += "/eboot.bin";
    std::vector<uint8_t> data;
    if (!ReadFileAll(p, data, 512ull << 20, &err)) return false;
    return LoadBuffer(data, err);
}
bool Emulator::LoadBuffer(const std::vector<uint8_t>& elf, std::string& err) {
    if (ready_) { err = "emulator instance already has a program loaded"; return false; }
    gpu = CreateSoftwareGpu();
    if (!gpu->Init((uint32_t)cfg_.GetInt("graphics.width", 1280), (uint32_t)cfg_.GetInt("graphics.height", 720), &err)) return false;
    if (!LoadElf(mem, elf, image, err)) return false;
    std::string e;
    if (!mem.Map(kStackTop - kStackSize, kStackSize, PERM_R | PERM_W, "stack", &e)) { err = "stack: " + e; return false; }
    cpu.st = CpuState();
    cpu.st.rip = image.entry; entry = image.entry;
    cpu.st.gpr[RSP] = kStackTop - 0x100;
    for (auto& w : image.warnings) PS5X_LOG(Warn, "loader: %s", w.c_str());
    KernelServices s; s.gpu = gpu.get(); s.audio = &audioRing; s.input = &input;
    kernel.reset(new Kernel(mem, cpu, s));
    ready_ = true; return true;
}
RunReport Emulator::Run(uint64_t maxInstr) {
    RunReport r;
    if (!ready_) { r.error = "no program loaded"; return r; }
    r.started = true;
    if (!maxInstr) maxInstr = (uint64_t)cfg_.GetInt("cpu.max_instructions", 2000000000);
    auto t0 = std::chrono::steady_clock::now();
    uint64_t budget = maxInstr;
    for (;;) {
        uint64_t before = cpu.instructionCount;
        r.reason = cpu.Run(budget);
        budget -= std::min(budget, cpu.instructionCount - before);
        if (r.reason == StopReason::Syscall) {
            kernel->Dispatch();
            if (kernel->exited) { r.exited = true; r.exitCode = kernel->exitCode; break; }
            if (budget == 0) { r.reason = StopReason::StepLimit; cpu.lastError = "instruction limit reached"; break; }
            continue;
        }
        break;
    }
    r.seconds = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
    r.instructions = cpu.instructionCount; r.syscalls = kernel->syscallCount; r.frames = gpu->frames;
    r.mips = r.seconds > 0 ? r.instructions / r.seconds / 1e6 : 0;
    r.stdoutText = kernel->stdoutBuf; r.stderrText = kernel->stderrBuf; r.unimplementedSyscalls = kernel->unimplemented;
    if (!r.exited) r.error = cpu.lastError;
    return r;
}

std::vector<uint8_t> BuildSampleElf() {
    const uint64_t base = 0x400000; const uint32_t hdr = 64 + 56;
    std::vector<uint8_t> code;
    auto emit = [&](std::initializer_list<int> b) { for (int x : b) code.push_back((uint8_t)x); };
    auto imm32 = [&](uint32_t v) { for (int i = 0; i < 4; ++i) code.push_back((uint8_t)(v >> (8 * i))); };
    const std::string msg = "Hello from PS5X guest code\n";
    emit({0xB8}); imm32(4);                       // mov eax, 4 (write)
    emit({0xBF}); imm32(1);                       // mov edi, 1
    emit({0x48, 0x8D, 0x35}); size_t leaPatch = code.size(); imm32(0);   // lea rsi,[rip+msg]
    size_t leaEnd = code.size();
    emit({0xBA}); imm32((uint32_t)msg.size());    // mov edx, len
    emit({0x0F, 0x05});                           // syscall
    emit({0xB8}); imm32(0x1000);                  // mov eax, gpu_clear
    emit({0xBF}); imm32(0xFF202020);              // mov edi, colour
    emit({0x0F, 0x05});
    emit({0x31, 0xDB});                           // xor ebx, ebx
    size_t loop = code.size();
    emit({0xB8}); imm32(0x1001);                  // mov eax, gpu_fillrect
    emit({0x48, 0x89, 0xDF});                     // mov rdi, rbx
    emit({0x48, 0xC1, 0xE7, 0x04});               // shl rdi, 4
    emit({0xBE}); imm32(8);                       // mov esi, 8
    emit({0xBA}); imm32(12);                      // mov edx, 12
    emit({0x41, 0xBA}); imm32(12);                // mov r10d, 12
    emit({0x41, 0xB8}); imm32(0xFF00FF00);        // mov r8d, colour
    emit({0x0F, 0x05});
    emit({0x48, 0xFF, 0xC3});                     // inc rbx
    emit({0x48, 0x83, 0xFB, 0x04});               // cmp rbx, 4
    emit({0x72, 0x00}); code.back() = (uint8_t)(int8_t)(loop - code.size());   // jb loop
    emit({0xB8}); imm32(0x1002); emit({0x0F, 0x05});   // present
    emit({0x31, 0xFF});                           // xor edi, edi
    emit({0xB8}); imm32(1); emit({0x0F, 0x05});   // exit(0)
    size_t msgOff = code.size();
    for (char c : msg) code.push_back((uint8_t)c);
    uint32_t rel = (uint32_t)(msgOff - leaEnd);
    for (int i = 0; i < 4; ++i) code[leaPatch + i] = (uint8_t)(rel >> (8 * i));

    std::vector<uint8_t> f(hdr, 0);
    auto w16 = [&](size_t o, uint16_t v) { f[o] = v; f[o + 1] = v >> 8; };
    auto w32 = [&](size_t o, uint32_t v) { for (int i = 0; i < 4; ++i) f[o + i] = v >> (8 * i); };
    auto w64 = [&](size_t o, uint64_t v) { for (int i = 0; i < 8; ++i) f[o + i] = v >> (8 * i); };
    memcpy(&f[0], "\x7f""ELF\2\1\1", 7);
    w16(16, 2); w16(18, 62); w32(20, 1); w64(24, base + hdr); w64(32, 64); w16(52, 64); w16(54, 56); w16(56, 1);
    size_t ph = 64; uint64_t total = hdr + code.size();
    w32(ph, 1); w32(ph + 4, 5); w64(ph + 8, 0); w64(ph + 16, base); w64(ph + 24, base); w64(ph + 32, total); w64(ph + 40, total); w64(ph + 48, 0x1000);
    f.insert(f.end(), code.begin(), code.end());
    return f;
}
}
