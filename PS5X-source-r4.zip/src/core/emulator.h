#pragma once
#include <memory>
#include <string>
#include "common/config.h"
#include "cpu/x86_cpu.h"
#include "gpu/gpu.h"
#include "audio/audio.h"
#include "input/input.h"
#include "kernel/kernel.h"
#include "loader/elf.h"
#include "memory/guest_memory.h"
namespace ps5x {
constexpr const char* kVersion = "0.1.0-foundation";
struct RunReport {
    bool started = false;
    std::string error;                  // loader/environment error, or fault/unsupported-instruction description
    StopReason reason = StopReason::Running;
    bool exited = false; int exitCode = 0;
    uint64_t instructions = 0, syscalls = 0, frames = 0;
    double seconds = 0, mips = 0;       // measured wall-clock throughput (this host, this run)
    std::string stdoutText, stderrText;
    std::map<uint64_t, uint64_t> unimplementedSyscalls;
};
class Emulator {
public:
    explicit Emulator(const Config& cfg);
    bool LoadFile(const std::string& path, std::string& err);   // plain ELF64 x86-64 only
    bool LoadBuffer(const std::vector<uint8_t>& elf, std::string& err);
    RunReport Run(uint64_t maxInstructions = 0);                // 0 = config cpu.max_instructions
    GuestMemory mem;
    X86Cpu cpu;
    std::unique_ptr<GpuBackend> gpu;
    AudioRing audioRing;
    InputManager input;
    std::unique_ptr<Kernel> kernel;
    std::unique_ptr<AudioBackend> audioOut;
    uint64_t entry = 0;
    LoadedImage image;
private:
    Config cfg_;
    bool ready_ = false;
};
std::vector<uint8_t> BuildSampleElf();   // tiny hand-assembled program exercising loader+CPU+kernel+GPU
}
