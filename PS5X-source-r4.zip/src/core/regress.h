#pragma once
#include <cstdint>
#include <string>
#include <vector>
#include "common/config.h"
namespace ps5x {
// Regression manifest, one test per line, '|' separated, '#' comments:
//   name | path | expect_exit | expect_stdout_contains | expect_frame_fnv1a_hex_or_- | max_instructions
// Paths are relative to the manifest's directory. Each test runs the REAL pipeline (loader+CPU+kernel+GPU).
struct RegressResult { std::string name; bool passed = false; std::string detail; uint64_t frameHash = 0; };
uint64_t Fnv1a64(const std::vector<uint32_t>& px);
std::vector<RegressResult> RunRegression(const std::string& manifestText, const std::string& baseDir, const Config& cfg);
}
