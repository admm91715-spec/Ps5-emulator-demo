#pragma once
#include <string>
namespace ps5x {
// Portable-layout paths. Defaults: everything under <data>. Options: --data DIR, --compat FILE, --logs DIR.
struct AppPaths { std::string data = "ps5x_data", compat, logs; std::string Config() const { return data + "/config.ini"; }
                  std::string Library() const { return data + "/library.txt"; }
                  std::string Compat() const { return compat.empty() ? data + "/compat.db" : compat; }
                  std::string LogFile() const { return (logs.empty() ? data : logs) + "/ps5x.log"; } };
// Consumes leading --data/--compat/--logs options starting at argv[i]; advances i. Returns false with err on a missing value.
bool ParseAppPaths(int argc, char** argv, int& i, AppPaths& p, std::string& err);
}
