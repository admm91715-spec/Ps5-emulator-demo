#pragma once
#include <cstdint>
#include <memory>
#include <mutex>
#include <string>
#include <vector>
namespace ps5x {
// Thread-safe fixed-capacity ring buffer of interleaved s16 samples.
class AudioRing {
public:
    explicit AudioRing(size_t capacity) : buf_(capacity) {}
    size_t Push(const int16_t* s, size_t n);   // returns samples accepted
    size_t Pop(int16_t* d, size_t n);          // returns samples delivered
    size_t Size() const { std::lock_guard<std::mutex> g(mu_); return count_; }
    size_t Capacity() const { return buf_.size(); }
private:
    mutable std::mutex mu_; std::vector<int16_t> buf_; size_t head_ = 0, count_ = 0;
};
class AudioBackend {
public:
    virtual ~AudioBackend() = default;
    virtual const char* Name() const = 0;
    virtual bool Open(uint32_t rate, uint16_t channels, std::string* err) = 0;
    virtual void Write(const int16_t* s, size_t n) = 0;
    virtual void Close() = 0;
    uint64_t samplesWritten = 0;
};
// "wav" writes a real PCM WAV file; "null" discards. No live OS audio device backend yet.
std::unique_ptr<AudioBackend> CreateAudioBackend(const std::string& name, const std::string& wavPath);
std::vector<std::string> ListAudioBackends();
void GenerateSine(int16_t* out, size_t frames, uint16_t channels, uint32_t rate, double hz, double& phase);
}
