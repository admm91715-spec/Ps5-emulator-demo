#include "audio/audio.h"
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <cstdio>
#include <cstring>
namespace ps5x {
size_t AudioRing::Push(const int16_t* s, size_t n) {
    std::lock_guard<std::mutex> g(mu_);
    size_t k = std::min(n, buf_.size() - count_);
    for (size_t i = 0; i < k; ++i) buf_[(head_ + count_ + i) % buf_.size()] = s[i];
    count_ += k; return k;
}
size_t AudioRing::Pop(int16_t* d, size_t n) {
    std::lock_guard<std::mutex> g(mu_);
    size_t k = std::min(n, count_);
    for (size_t i = 0; i < k; ++i) d[i] = buf_[(head_ + i) % buf_.size()];
    head_ = (head_ + k) % buf_.size(); count_ -= k; return k;
}
namespace {
class NullBackend : public AudioBackend {
public:
    const char* Name() const override { return "null"; }
    bool Open(uint32_t, uint16_t, std::string*) override { return true; }
    void Write(const int16_t*, size_t n) override { samplesWritten += n; }
    void Close() override {}
};
class WavBackend : public AudioBackend {
public:
    explicit WavBackend(std::string p) : path_(std::move(p)) {}
    ~WavBackend() override { Close(); }
    const char* Name() const override { return "wav-file"; }
    bool Open(uint32_t rate, uint16_t ch, std::string* err) override {
        f_ = fopen(path_.c_str(), "wb");
        if (!f_) { if (err) *err = "cannot write " + path_; return false; }
        rate_ = rate; ch_ = ch; WriteHeader(0); return true;
    }
    void Write(const int16_t* s, size_t n) override { if (f_) { fwrite(s, 2, n, f_); samplesWritten += n; } }
    void Close() override { if (f_) { WriteHeader((uint32_t)(samplesWritten * 2)); fclose(f_); f_ = nullptr; } }
private:
    void WriteHeader(uint32_t dataBytes) {
        fseek(f_, 0, SEEK_SET);
        auto u32 = [&](uint32_t v) { fwrite(&v, 4, 1, f_); }; auto u16 = [&](uint16_t v) { fwrite(&v, 2, 1, f_); };
        fwrite("RIFF", 1, 4, f_); u32(36 + dataBytes); fwrite("WAVEfmt ", 1, 8, f_); u32(16); u16(1); u16(ch_); u32(rate_);
        u32(rate_ * ch_ * 2); u16(ch_ * 2); u16(16); fwrite("data", 1, 4, f_); u32(dataBytes);
        fseek(f_, 0, SEEK_END);
    }
    std::string path_; FILE* f_ = nullptr; uint32_t rate_ = 48000; uint16_t ch_ = 2;
};
}
std::unique_ptr<AudioBackend> CreateAudioBackend(const std::string& name, const std::string& wavPath) {
    if (name == "wav") return std::unique_ptr<AudioBackend>(new WavBackend(wavPath));
    if (name == "null") return std::unique_ptr<AudioBackend>(new NullBackend());
    return nullptr;
}
std::vector<std::string> ListAudioBackends() { return {"wav", "null"}; }
void GenerateSine(int16_t* out, size_t frames, uint16_t ch, uint32_t rate, double hz, double& phase) {
    const double kPi = 3.14159265358979323846, inc = 2.0 * kPi * hz / rate;
    for (size_t i = 0; i < frames; ++i) {
        int16_t v = (int16_t)(std::sin(phase) * 12000.0); phase += inc; if (phase > 2.0 * kPi) phase -= 2.0 * kPi;
        for (uint16_t c = 0; c < ch; ++c) out[i * ch + c] = v;
    }
}
}
