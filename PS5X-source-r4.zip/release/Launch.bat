@echo off
setlocal
cd /d "%~dp0"
if not exist "PS5X.exe" (
  echo PS5X.exe ^(the GUI^) is not part of this package. It is a CLI-only build.
  echo Starting the command-line launcher instead...
  call "%~dp0Launch_CLI.bat"
  exit /b
)
start "" "%~dp0PS5X.exe" --data "%~dp0Config" --compat "%~dp0Compatibility\compat.db" --logs "%~dp0Logs"
