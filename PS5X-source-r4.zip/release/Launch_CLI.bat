@echo off
setlocal
cd /d "%~dp0"
echo PS5X command line. Examples:
echo   ps5x-cli.exe make-sample sample.elf
echo   ps5x-cli.exe run sample.elf --frame out.ppm
echo   ps5x-cli.exe identify "path\to\file-or-folder"
echo   ps5x-cli.exe compat list
echo In this window the command "ps5x" is a shortcut for ps5x-cli.exe with the portable Config/Compatibility/Logs paths already set.
doskey ps5x="%~dp0ps5x-cli.exe" --data "%~dp0Config" --compat "%~dp0Compatibility\compat.db" --logs "%~dp0Logs" $*
cmd /k
