@echo off
setlocal
cd /d "%~dp0"
set D=%~dp0Config
set FAIL=0
echo === PS5X smoke test on this PC ===
"%~dp0ps5x-cli.exe" --version || set FAIL=1
"%~dp0ps5x-cli.exe" --data "%D%" make-sample "%TEMP%\ps5x_sample.elf" || set FAIL=1
"%~dp0ps5x-cli.exe" --data "%D%" run "%TEMP%\ps5x_sample.elf" --frame "%TEMP%\ps5x_frame.ppm" | find "Hello from PS5X guest code" >nul && (echo PASS run sample) || (echo FAIL run sample & set FAIL=1)
"%~dp0ps5x-cli.exe" --data "%D%" --compat "%~dp0Compatibility\compat.db" compat validate || set FAIL=1
if exist "%~dp0ps5x_preflight.exe" "%~dp0ps5x_preflight.exe"
if "%FAIL%"=="0" (echo SMOKE TEST: ALL PASSED) else (echo SMOKE TEST: FAILURES)
pause
