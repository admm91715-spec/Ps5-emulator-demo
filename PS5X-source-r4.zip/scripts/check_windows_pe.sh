#!/bin/sh
# usage: check_windows_pe.sh <file>...   Exit 0 only if EVERY file is a Windows x86-64 PE executable (MZ + PE\0\0 + machine 0x8664).
# This is what stops a Linux ELF (or a 32-bit exe) from ever being packaged as a Windows binary.
rc=0
for f in "$@"; do
  if [ ! -f "$f" ]; then echo "check_windows_pe: $f: no such file"; rc=1; continue; fi
  if [ "$(head -c 2 "$f")" != "MZ" ]; then echo "check_windows_pe: $f: NOT a Windows executable (no MZ header; magic: $(head -c 4 "$f" | od -An -c | tr -s ' '))"; rc=1; continue; fi
  off=$(od -An -t u4 -j 60 -N 4 "$f" 2>/dev/null | tr -d ' \n')
  sig=$(od -An -t x1 -j "${off:-0}" -N 4 "$f" 2>/dev/null | tr -d ' \n')
  if [ "$sig" != "50450000" ]; then echo "check_windows_pe: $f: MZ but no PE signature"; rc=1; continue; fi
  mach=$(od -An -t x2 -j $((off + 4)) -N 2 "$f" 2>/dev/null | tr -d ' \n')
  if [ "$mach" != "8664" ]; then echo "check_windows_pe: $f: PE machine 0x$mach is not x86-64 (0x8664)"; rc=1; continue; fi
  echo "check_windows_pe: $f: OK (Windows x86-64 PE)"
done
exit $rc
