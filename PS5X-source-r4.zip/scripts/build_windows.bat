@echo off
rem Local Windows build (alternative to GitHub Actions). Run from an MSYS2 UCRT64-enabled environment, e.g. after
rem   pacman -S mingw-w64-ucrt-x86_64-gcc mingw-w64-ucrt-x86_64-cmake mingw-w64-ucrt-x86_64-ninja
rem and with C:\msys64\ucrt64\bin on PATH. Plain MSVC cl.exe is NOT supported.
rem NOTE: not executed by the author. The authoritative Windows build is .github/workflows/windows.yml.
setlocal
cd /d "%~dp0\.."
where cmake >nul 2>nul || (echo CMake not found on PATH & exit /b 1)
where gcc >nul 2>nul || (echo GCC (MinGW-w64) not found on PATH & exit /b 1)
cmake -S . -B build -G Ninja -DCMAKE_BUILD_TYPE=Release -DPS5X_BUILD_GUI=OFF || exit /b 1
cmake --build build || exit /b 1
ctest --test-dir build --output-on-failure || exit /b 1
cmake -S . -B build-gui -G Ninja -DCMAKE_BUILD_TYPE=Release -DPS5X_BUILD_GUI=ON -DPS5X_BUILD_TESTS=OFF || exit /b 1
cmake --build build-gui --target ps5x_gui || (echo GUI build FAILED - PS5X.exe is unavailable & exit /b 1)
echo.
echo Built: build\ps5x-cli.exe  build\ps5x_preflight.exe  build-gui\PS5X.exe
echo Package with:  sh scripts/package_release.sh PS5X-Ultimate-Windows.zip build/ps5x-cli.exe build-gui/PS5X.exe build/ps5x_preflight.exe
