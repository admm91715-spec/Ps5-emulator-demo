#!/bin/sh
# usage: package_release.sh <out.zip> <ps5x-cli.exe> <PS5X.exe | -> <ps5x_preflight.exe | ->
# Assembles the portable Windows package. Every binary must be a Windows x64 PE (checked); a Linux binary is refused.
# Required DLLs: the build is meant to be static (no extra DLLs). If an exe still imports a DLL that exists in the MSYS2
# prefix (MINGW_PREFIX/bin), it is bundled next to the exes (Windows only searches the exe folder) and listed in
# Dependencies/dll_report.txt.  PS5X_LAYOUT_CHECK=1 (local testing only) skips the PE check but marks the zip NOT-WINDOWS.
set -e
OUT=$1; CLI=$2; GUI=${3:--}; PRE=${4:--}
[ -n "$OUT" ] && [ -n "$CLI" ] || { echo "usage: $0 out.zip ps5x-cli.exe [PS5X.exe|-] [ps5x_preflight.exe|-]"; exit 2; }
ROOT=$(cd "$(dirname "$0")/.." && pwd)
BINS="$CLI"; [ "$GUI" != "-" ] && [ -n "$GUI" ] && BINS="$BINS $GUI"; [ "$PRE" != "-" ] && [ -n "$PRE" ] && BINS="$BINS $PRE"
LAYOUT_ONLY=0
if [ "${PS5X_LAYOUT_CHECK:-0}" = "1" ]; then
  case "$OUT" in *LAYOUT-CHECK*NOT-WINDOWS*) LAYOUT_ONLY=1;; *) echo "PS5X_LAYOUT_CHECK needs an output name containing LAYOUT-CHECK and NOT-WINDOWS"; exit 2;; esac
else
  # shellcheck disable=SC2086
  sh "$ROOT/scripts/check_windows_pe.sh" $BINS || { echo "REFUSING to package: not all binaries are Windows x64 executables."; exit 3; }
fi
STAGE=$(mktemp -d); P=$STAGE/PS5X
mkdir -p "$P/Dependencies" "$P/Config" "$P/GameLibrary" "$P/Compatibility" "$P/Documentation" "$P/Logs"
if [ "$LAYOUT_ONLY" = "1" ]; then EXT=""; else EXT=".exe"; fi
cp "$CLI" "$P/ps5x-cli$EXT"
HAVE_GUI=no; if [ "$GUI" != "-" ] && [ -n "$GUI" ]; then cp "$GUI" "$P/PS5X$EXT"; HAVE_GUI=yes; fi
if [ "$PRE" != "-" ] && [ -n "$PRE" ]; then cp "$PRE" "$P/ps5x_preflight$EXT"; fi
if [ "$HAVE_GUI" = yes ]; then GS="GUI (PS5X.exe) INCLUDED. It was compiled by CI; check the CI summary for whether its launch smoke test passed."; else GS="GUI NOT INCLUDED: the GUI target did not build. Use ps5x-cli.exe. This is a CLI-ONLY package."; fi

# ---- DLL bundling + report (fallback; the intended state is "no DLLs needed") ----
REPORT="$P/Dependencies/dll_report.txt"; : > "$REPORT"
imports() { command -v objdump >/dev/null 2>&1 && objdump -p "$1" 2>/dev/null | sed -n 's/^[[:space:]]*DLL Name:[[:space:]]*//p' | tr -d '\r'; }
if [ "$LAYOUT_ONLY" = "0" ]; then
  for pass in 1 2 3 4; do
    for f in "$P"/*.exe "$P"/*.dll; do
      [ -f "$f" ] || continue
      for d in $(imports "$f"); do
        lc=$(echo "$d" | tr 'A-Z' 'a-z')
        if [ -n "${MINGW_PREFIX:-}" ] && [ -f "$MINGW_PREFIX/bin/$lc" ] && [ ! -f "$P/$lc" ]; then cp "$MINGW_PREFIX/bin/$lc" "$P/$lc"; echo "bundled: $lc (imported by $(basename "$f"))" >> "$REPORT"; fi
      done
    done
  done
  echo "--- imports per binary (case-insensitive; 'system' = expected to be provided by Windows) ---" >> "$REPORT"
  for f in "$P"/*.exe "$P"/*.dll; do
    [ -f "$f" ] || continue
    echo "$(basename "$f"):" >> "$REPORT"
    for d in $(imports "$f"); do
      lc=$(echo "$d" | tr 'A-Z' 'a-z')
      if [ -f "$P/$lc" ]; then echo "    $lc  [bundled]" >> "$REPORT"; else
        case "$lc" in kernel32.dll|user32.dll|gdi32.dll|shell32.dll|ole32.dll|comdlg32.dll|advapi32.dll|msvcrt.dll|ucrtbase.dll|api-ms-win-*|ntdll.dll|ws2_32.dll|shlwapi.dll|comctl32.dll|oleaut32.dll|version.dll|imm32.dll|bcrypt.dll|rpcrt4.dll|combase.dll|win32u.dll|sechost.dll)
            echo "    $lc  [system]" >> "$REPORT";;
          *) echo "    $lc  [NOT bundled and not a known system DLL - may be missing on a clean PC!]" >> "$REPORT"; echo "WARNING: $(basename "$f") imports $lc which is neither bundled nor a known system DLL";;
        esac; fi
    done
  done
else echo "layout check only - not a Windows build" > "$REPORT"; echo "NOT A WINDOWS BUILD: this archive only checks the folder layout. Its binaries are not Windows executables." > "$P/NOT_A_WINDOWS_BUILD.txt"; fi

cp "$ROOT/config/ps5x.example.ini" "$P/Config/ps5x.example.ini"
cp "$ROOT/release/compat.db" "$P/Compatibility/compat.db"
cp "$ROOT/LICENSE" "$P/Documentation/LICENSE.txt"
for f in "$ROOT"/docs/*.md; do cp "$f" "$P/Documentation/"; done
cp "$ROOT/README.md" "$P/Documentation/README_project.md"
printf 'PS5X is linked statically (-static) so no third-party DLLs are expected next to the executables.\nIf any DLL was needed it was copied next to the .exe files and listed in dll_report.txt.\nNo firmware, keys, games or proprietary SDK files are or must be placed anywhere in this package.\n' > "$P/Dependencies/NOTICE.txt"
printf 'Put your own files/folders here if you like. PS5X executes only plain x86-64 ELF programs;\ncommercial PS5 titles are listed as Unsupported by PS5X.\n' > "$P/GameLibrary/README.txt"
crlf() { tr -d '\r' < "$1" | sed 's/$/\r/' > "$2"; }
for b in Launch.bat Launch_CLI.bat Smoke_Test.bat; do crlf "$ROOT/release/$b" "$P/$b"; done
sed "s|@GUI_STATUS@|$GS|" "$ROOT/release/README.txt.in" > "$STAGE/README.tmp"; crlf "$STAGE/README.tmp" "$P/README.txt"; rm -f "$STAGE/README.tmp"

case "$OUT" in /*) ABS=$OUT;; *) ABS=$(pwd)/$OUT;; esac
rm -f "$ABS"; (cd "$STAGE" && zip -r -q "$ABS" PS5X)
# sanity: the archive really contains what the status line claims
unzip -l "$ABS" | grep -q "PS5X/ps5x-cli$EXT" || { echo "internal error: CLI missing from archive"; exit 4; }
if [ "$HAVE_GUI" = yes ]; then unzip -l "$ABS" | grep -q "PS5X/PS5X$EXT" || { echo "internal error: GUI missing from archive"; exit 4; }; fi
rm -rf "$STAGE"; echo "wrote $ABS - gui=$HAVE_GUI"
