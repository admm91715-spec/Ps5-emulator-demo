#!/bin/sh
# Create a source-release ZIP (no binaries, no games, no firmware, no keys).
set -e
cd "$(dirname "$0")/.."
OUT=${1:-../PS5X-source.zip}
rm -f "$OUT"
zip -r -q "$OUT" . -x 'build/*' '*.o' 'ps5x_data/*' '*.ppm' '*.wav' '.git/*'
echo "wrote $OUT"
