#!/bin/sh
set -e
cd "$(dirname "$0")/.."
[ -x build/ps5x_tests ] || sh scripts/build_linux.sh
build/ps5x_tests "$@"
