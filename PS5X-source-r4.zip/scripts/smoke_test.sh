#!/bin/sh
# usage: smoke_test.sh <ps5x-cli[.exe]> [ps5x_preflight[.exe]]  - end-to-end checks of the CLI binary itself. Exit 1 on any failure.
CLI=$1; PRE=$2; fail=0
[ -n "$CLI" ] || { echo "usage: $0 cli [preflight]"; exit 2; }
T=$(mktemp -d); D="$T/data"
ok()  { echo "  PASS  $1"; }
bad() { echo "  FAIL  $1"; fail=1; }
"$CLI" --version | grep -q "^PS5X " && ok "--version" || bad "--version"
"$CLI" --data "$D" make-sample "$T/sample.elf" >/dev/null && [ -s "$T/sample.elf" ] && ok "make-sample" || bad "make-sample"
OUT=$("$CLI" --data "$D" run "$T/sample.elf" --frame "$T/f.ppm"); rc=$?
[ $rc -eq 0 ] && echo "$OUT" | grep -q "Hello from PS5X guest code" && echo "$OUT" | grep -q "guest exit (code 0)" && ok "run sample (loader+CPU+kernel+GPU)" || bad "run sample (rc=$rc)"
[ -s "$T/f.ppm" ] && ok "framebuffer written" || bad "framebuffer written"
mkdir -p "$T/r"; cp "$T/sample.elf" "$T/r/"; printf 'p | sample.elf | 0 | Hello | - | 1000000\n' > "$T/r/p.txt"
H=$("$CLI" --data "$D" regress "$T/r/p.txt" | sed -n 's/.*frame \([0-9a-f]*\).*/\1/p')
printf 'sample | sample.elf | 0 | Hello from PS5X | %s | 1000000\n' "$H" > "$T/r/m.txt"
"$CLI" --data "$D" regress "$T/r/m.txt" >/dev/null && ok "regress manifest" || bad "regress manifest"
printf 'bad | sample.elf | 9 | - | - | 1000000\n' > "$T/r/neg.txt"
"$CLI" --data "$D" regress "$T/r/neg.txt" >/dev/null 2>&1 && bad "regress detects wrong expectation" || ok "regress detects wrong expectation"
printf '\124\024\365\356\0\0\0\0' > "$T/fake.self"
"$CLI" --data "$D" identify "$T/fake.self" 2>&1 | grep -q "Unsupported" && ok "SELF reported Unsupported" || bad "SELF reported Unsupported"
"$CLI" --data "$D" compat set X1 name=n level=Playable >/dev/null 2>&1 && bad "compat refuses unevidenced Playable" || ok "compat refuses unevidenced Playable"
"$CLI" --data "$D" compat validate >/dev/null && ok "compat validate" || bad "compat validate"
if [ -n "$PRE" ]; then "$PRE" "$T" | grep -q "RESULT:" && ok "preflight runs" || bad "preflight runs"; fi
rm -rf "$T"; [ $fail -eq 0 ] && echo "SMOKE TEST: ALL PASSED" || echo "SMOKE TEST: FAILURES"; exit $fail
