# PS5X — experimental PS5-oriented emulator *foundation*

> **Status: early foundation. PS5X cannot run any commercial PlayStation 5 game.**
> No game (GTA VI or otherwise) has been tested or is claimed to work. See [docs/COMPATIBILITY.md](docs/COMPATIBILITY.md).

PS5X is a small, real, tested C++17 codebase containing the first building blocks of a console emulator, wired
together into an actual load → execute → render pipeline. What runs today is **plain x86-64 ELF programs** (such as the
built-in sample) on an interpreter for a documented integer subset of x86-64. PS5 titles are encrypted/signed, use
SSE/AVX, Sony system libraries and the AMD GPU command stream; none of that is implemented here.

> **Update (r4):** Windows pipeline hardened (docs/WINDOWS_BUILD_AUDIT.md, docs/GITHUB_WINDOWS_BUILD.md). No Windows build has been verified yet.
>
> **Update (r3):** adds an evidence-gated compatibility DB, regression harness, Win32 GUI source and a GitHub Actions Windows pipeline (docs/COMPATIBILITY_DB.md, .github/workflows/windows.yml). The Windows .exe has NOT been built by the author.
>
> **Update (r2):** see docs/FOUNDATION_EVALUATION.md - KytyPS5 is the recommended primary foundation; PS5X is now a test harness + `ps5x_preflight`.

Before extending this, look at the existing open-source PS5 efforts (KytyPS5, SharpEmu; both GPL-2.0). They are far
ahead of this foundation; contributing there is the practical route to real compatibility. See [docs/ROADMAP.md](docs/ROADMAP.md).

## What is implemented (all covered by `tests/`)

| Area | Implemented | Not implemented |
|---|---|---|
| Memory | Region-based guest address space, permissions (R/W/X), bounds/overlap/limit checks, fault reporting | 16 KiB pages, direct memory, host page-protection tricks |
| CPU | x86-64 interpreter: ALU+flags, mov/lea, push/pop, call/ret/jmp/jcc, shifts, movzx/movsx/movsxd, imul, setcc/cmov, 8/16/32/64-bit + REX, RIP-relative, syscall | SSE/AVX/x87, div/mul, string ops, atomics, segments/TLS, rotates, most 0F opcodes. Unsupported opcodes stop with an explicit error |
| Loader | Validating ELF64 x86-64 parser/mapper (EXEC and DYN) | SELF/PKG/PFS decryption or parsing, relocations, dynamic linking, PS5 modules (PRX) |
| Kernel | Syscall table + registration, FreeBSD-ABI `exit/write/getpid/mmap(anon)/munmap`, unknown syscalls reported as ENOSYS | Threads, mutexes, files, Sony kernel/library interfaces |
| GPU | Backend interface, software framebuffer (clear/fill/present), PPM dump, optional Vulkan device probe (untested) | AMD GFX10 command processing, shader recompiler, real Vulkan renderer |
| Audio | Ring buffer, WAV-file backend, null backend, tone generator | Live OS audio output (WASAPI), PS5 audio engine |
| Input | Keyboard→virtual pad mapping from config, XInput polling (Windows code path, untested) | DualSense features, hot-plug, UI for remapping |
| Storage | Format identification (ELF/SELF/PKG/directories), `param.json` title extraction, game library with honest status | PKG/PFS parsing, save data |
| Frontend | **Command-line only** | **No GUI yet** |

PS5X never decrypts console executables and contains no keys, firmware, or DRM circumvention.

## Build

Needs a C++17 compiler that supports GCC/Clang extensions (GCC ≥ 9, Clang, MinGW-w64, clang-cl). Plain MSVC `cl.exe` is unsupported.

* **Linux/macOS (verified by the author with GCC 13):** `sh scripts/build_linux.sh && sh scripts/run_tests.sh`
* **CMake (not run by the author — no CMake in the build sandbox):** `cmake -S . -B build && cmake --build build -j && ctest --test-dir build`
* **Windows (script written, NOT executed — no Windows machine was available):** install MSYS2 (UCRT64 GCC) or LLVM,
  CMake and Ninja, then run `scripts\build_windows.bat`. Windows-only code (XInput) has never been compiled.

## Use

```
ps5x make-sample sample.elf           # writes a tiny hand-assembled test program
ps5x run sample.elf --frame out.ppm   # real pipeline: load → CPU → syscalls → software GPU
ps5x identify <file-or-game-dir>      # format + honest compatibility status
ps5x add <path> | scan <dir> | library
ps5x config list | get K | set K V    # settings live in ps5x_data/config.ini (see config/ps5x.example.ini)
ps5x devices
```
Adding a game file/directory only *identifies* it. Commercial PS5 dumps will show **Unsupported**.
Exit code of `run` is the guest's exit code, or 3 if execution stopped for any other reason.

## Tests
`build/ps5x_tests [name-filter]` — 33 tests covering memory, config, CPU, ELF loading, format detection, library,
kernel, GPU, audio, input, and end-to-end execution including failure reporting.

## Layout
`src/{common,memory,cpu,loader,kernel,gpu,audio,input,storage,core,frontend}` · `tests/` · `docs/` · `scripts/` · `config/`

License: MIT (own code). If you merge with GPL-2.0 projects, the combined work is GPL-2.0.
